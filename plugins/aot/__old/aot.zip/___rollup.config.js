
export default {
  input: './helpers/compiler.js',
  output: {
    file: './helpers/compiler.bundled.js',
    format: 'es'
  }
};
