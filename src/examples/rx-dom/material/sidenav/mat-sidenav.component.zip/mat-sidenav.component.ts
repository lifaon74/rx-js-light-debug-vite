import { IObservable, IObserver, map$$ } from '@lirx/core';
import {
  compileReactiveCSSAsComponentStyle, compileReactiveHTMLAsComponentTemplate, Component, HTMLElementWithInputs,
  IComponentInput, OnCreate, setReactiveClassList,
} from '@lirx/dom';
// @ts-ignore
import html from './mat-sidenav.component.html?raw';
// @ts-ignore
import style from './mat-sidenav.component.scss?inline';


/** TYPES **/

// https://material.angular.io/components/sidenav/examples

export type IMatSidenavComponentState = 'opened' | 'closed' | 'static';

function dispatchCustomEvent<GData>(
  node: HTMLElement,
  type: string,
  detail: GData,
): void {
  node.dispatchEvent(new CustomEvent('close', { bubbles: false, detail }));
}

/** COMPONENT **/

interface IData {
  readonly onClickBackdrop: IObserver<MouseEvent>;
  readonly onClickDrag: IObserver<MouseEvent>;
}

type IComponentInputs = [
  IComponentInput<'state', IMatSidenavComponentState>,
];

@Component({
  name: 'mat-sidenav',
  template: compileReactiveHTMLAsComponentTemplate({ html }),
  styles: [compileReactiveCSSAsComponentStyle(style)],
})
export class MatSidenavComponent extends HTMLElementWithInputs<IComponentInputs>(['state']) implements OnCreate<IData> {
  protected readonly _data: IData;

  constructor() {
    super();
    // this.state = 'closed';
    this.state = 'opened';

    const classList$ = map$$(this.state$, (state: IMatSidenavComponentState) => new Set([state]));

    setReactiveClassList(classList$, this);

    const onClickBackdrop = (): void => {
      this.state = 'closed';
      dispatchCustomEvent(this, 'close', void 0);
    };

    const onClickDrag = (): void => {
      this.state = 'opened';
      dispatchCustomEvent(this, 'open', void 0);
    };

    this._data = {
      onClickBackdrop,
      onClickDrag,
    };
  }

  public onCreate(): IData {
    return this._data;
  }
}
