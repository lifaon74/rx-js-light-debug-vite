import { IObservable, single } from '@lifaon/rx-js-light';

export const MAT_CLEAR_ICON_TITLE: IObservable<string> = single('Clear');

