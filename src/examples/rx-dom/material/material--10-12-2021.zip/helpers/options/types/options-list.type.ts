export type IOptionsList<GOption> = Iterable<GOption>;
