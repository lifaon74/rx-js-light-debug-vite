export type IReadonlyOptionsSet<GOption> = ReadonlySet<GOption>;
