export const POSITION_AND_SIZE_OUT_OF_WINDOW = {
  left: '-10000px',
  top: '-10000px',
  width: '0',
  height: '0',
};
