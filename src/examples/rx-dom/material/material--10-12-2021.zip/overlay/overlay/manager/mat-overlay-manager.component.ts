import {
  bootstrap,
  compileReactiveCSSAsComponentStyle, compileReactiveHTMLAsGenericComponentTemplate, Component, createDocumentFragment,
  getDocument, IReactiveContent, nodeAppendChild, OnCreate, querySelectorOrThrow, subscribeOnNodeConnectedTo,
} from '@lifaon/rx-dom';
import {
  IMulticastReplayLastSource, IObservable, let$$, map$$, mutateReadonlyReplayLastSourceArray, single
} from '@lifaon/rx-js-light';
import { MatOverlayComponent } from '../component/mat-overlay.component';

// @ts-ignore
import style from './mat-overlay-manager.component.scss?inline';
// @ts-ignore
import html from './mat-overlay-manager.component.html?raw';
import { IMatOverlayComponentConstructor } from '../component/mat-overlay-component-constructor.type';

/** INTERFACES **/

interface IOverlay {
  readonly component: HTMLElement;
  readonly content$: IReactiveContent;
}

interface IData {
  readonly overlays$: IObservable<readonly IOverlay[]>;
}

/** COMPONENT **/

@Component({
  name: 'mat-overlay-manager',
  template: compileReactiveHTMLAsGenericComponentTemplate({ html }),
  styles: [compileReactiveCSSAsComponentStyle(style)],
})
export class MatOverlayManagerComponent extends HTMLElement implements OnCreate<IData> {

  static init(): void {
    queueMicrotask(() => {
      this.bootstrap();
    });
  }

  static bootstrap(): MatOverlayManagerComponent {
    try {
      return this.getInstance();
    } catch(error) {
      const manager = new this();
      bootstrap(manager);
      return manager;
    }
  }

  static getInstance(): MatOverlayManagerComponent {
    return querySelectorOrThrow(getDocument(), 'mat-overlay-manager');
  }

  static open<GOverlayComponent extends MatOverlayComponent, GArguments extends any[]>(
    componentConstructor: IMatOverlayComponentConstructor<GOverlayComponent, GArguments>,
    args: GArguments,
  ): GOverlayComponent {
    return this.getInstance()
      .open_legacy<GOverlayComponent, GArguments>(
        componentConstructor,
        args,
      );
  }

  static close(
    component: MatOverlayComponent,
  ): void {
    return this.getInstance().close(component);
  }

  static isClosed(
    component: MatOverlayComponent,
  ): boolean {
    return this.getInstance().isClosed(component);
  }

  protected readonly _data: IData;
  protected readonly _$overlays$: IMulticastReplayLastSource<readonly IOverlay[]>;

  constructor() {
    super();
    this._$overlays$ = let$$<readonly IOverlay[]>([]);
    const overlays$ = this._$overlays$.subscribe;

    this._data = {
      overlays$,
    };

    subscribeOnNodeConnectedTo(
      this,
      map$$<readonly IOverlay[], boolean>(overlays$, (overlays: readonly IOverlay[]) => (overlays.length > 0)),
      (isVisible: boolean) => {
        this.classList.toggle('visible', isVisible);
      },
    );
  }

  /**
   * @deprecated
   */
  open_legacy<GOverlayComponent extends MatOverlayComponent, GArguments extends any[]>(
    componentConstructor: IMatOverlayComponentConstructor<GOverlayComponent, GArguments>,
    args: GArguments,
  ): GOverlayComponent {
    const component: GOverlayComponent = new componentConstructor(this, ...args);

    const fragment: DocumentFragment = createDocumentFragment();
    nodeAppendChild(fragment, component);

    const overlay: IOverlay = {
      component,
      content$: single(fragment),
    };

    mutateReadonlyReplayLastSourceArray(this._$overlays$, (overlays: IOverlay[]): void => {
      overlays.push(overlay);
    });

    return component;
  }

  open<GOverlayComponent extends MatOverlayComponent, GArguments extends any[]>(
    componentConstructor: IMatOverlayComponentConstructor<GOverlayComponent, GArguments>,
    args: GArguments,
  ): GOverlayComponent {
    const component: GOverlayComponent = new componentConstructor(this, ...args);

    const fragment: DocumentFragment = createDocumentFragment();
    nodeAppendChild(fragment, component);

    const overlay: IOverlay = {
      component,
      content$: single(fragment),
    };

    mutateReadonlyReplayLastSourceArray(this._$overlays$, (overlays: IOverlay[]): void => {
      overlays.push(overlay);
    });

    return component;
  }

  close(
    component: MatOverlayComponent,
  ): void {
    const index: number = this._$overlays$.getValue().findIndex((overlay: IOverlay): boolean => {
      return overlay.component === component;
    });

    if (index === -1) {
      throw new Error(
        (component.manager === this)
          ? `Overlay already closed`
          : `Not a overlay of this manager`
      );
    } else {
      mutateReadonlyReplayLastSourceArray(this._$overlays$, (overlays: IOverlay[]): void => {
        overlays.splice(index, 1);
      });
    }
  }

  isClosed(
    component: MatOverlayComponent,
  ): boolean {
    return !this._$overlays$.getValue().some((overlay: IOverlay): boolean => {
      return overlay.component === component;
    });
  }

  onCreate(): IData {
    return this._data;
  }
}

