import { createHSVAColor } from '../../../../../../../misc/css/color/colors/hsva/create-hsva-color';

export const DEFAULT_MAT_COLOR_INPUT_COLOR = createHSVAColor(0, 0, 0, 1);
