import { createHSLAColor } from '../../../../../misc/css/color/colors/hsla/create-hsla-color';

// const DEFAULT_COLOR_STRING = '#000000';
// const DEFAULT_COLOR = createHSLAColorFromStringOrThrow(DEFAULT_COLOR_STRING);
export const DEFAULT_MAT_COLOR_INPUT_COLOR = createHSLAColor(0, 0, 0, 1);
