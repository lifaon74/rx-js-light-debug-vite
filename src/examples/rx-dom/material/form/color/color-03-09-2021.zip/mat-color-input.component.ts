import {
  compileAndEvaluateReactiveHTMLAsComponentTemplate, compileReactiveCSSAsComponentStyle, Component,
  DEFAULT_CONSTANTS_TO_IMPORT, generateGetNodeModifierFunctionFromArray, HTMLElementConstructor, OnCreate,
} from '@lifaon/rx-dom';
// @ts-ignore
import html from './mat-color-input.component.html?raw';
// @ts-ignore
import style from './mat-color-input.component.scss';
import { havingMultipleSubscribeFunctionProperties } from '../../../../misc/having-multiple-subscribe-function-properties';
import { createHigherOrderVariable } from '../../../../misc/create-higher-order-variable';
import { INPUT_VALUE_MODIFIER } from '../modifiers/input-value.modifier';
import { ISource, ISubscribeFunction } from '@lifaon/rx-js-light';
import { $$map, letU$$, map$$, shareR$$ } from '@lifaon/rx-js-light-shortcuts';
import { MatColorInputOverlayComponent } from './overlay/mat-color-input-overlay.component';
import { createOpenCloseTuple } from '../../overlay/overlay/component/helpers/create-open-close-tuple';
import { MatOverlayManagerComponent } from '../../overlay/overlay/manager/mat-overlay-manager.component';
import { IHSLAColor, IReadonlyHSLAColor } from '../../../../misc/css/color/colors/hsla/hsla-color.type';
import { hslaColorToString } from '../../../../misc/css/color/colors/hsla/to/hsla-color-to-string';
import { DEFAULT_MAT_COLOR_INPUT_COLOR } from './misc/default-mat-color-input-color.constant';
import { parseCSSColor } from '../../../../misc/css/color/parse-css-color';
import { colorToHSLAColor } from '../../../../misc/css/color/to/color-to-hsla-color';
import { IColor } from '../../../../misc/css/color/color.type';


/** TYPES **/

export type IColorInputValue = IReadonlyHSLAColor | null;

/** CONSTANTS **/

/** COMPONENT **/


type IMatColorInputComponentInputs<GValue> = [
  ['readonly', boolean],
];

interface IData {
  readonly previewColor$: ISubscribeFunction<string>;
  readonly $inputValue$: ISource<string>;
}

const MAT_COLOR_INPUT_MODIFIERS = [
  INPUT_VALUE_MODIFIER,
];

const CONSTANTS_TO_IMPORT = {
  ...DEFAULT_CONSTANTS_TO_IMPORT,
  getNodeModifier: generateGetNodeModifierFunctionFromArray(MAT_COLOR_INPUT_MODIFIERS)
};

@Component({
  name: 'mat-color-input',
  template: compileAndEvaluateReactiveHTMLAsComponentTemplate(html, CONSTANTS_TO_IMPORT),
  style: compileReactiveCSSAsComponentStyle(style),
})
export class MatColorInputComponent<GValue> extends havingMultipleSubscribeFunctionProperties<IMatColorInputComponentInputs<any>, HTMLElementConstructor>(HTMLElement) implements OnCreate<IData> {

  // protected readonly _$value: IEmitFunction<string>;
  protected readonly _data: IData;

  constructor() {
    // const $value$ = let$$<string>('');

    // const [$value$, value$] = createHigherOrderVariable<IReadonlyColor>(DEFAULT_COLOR);
    // const [$rawValue$, rawValue$] = createHigherOrderVariable<string>(DEFAULT_COLOR_STRING);

    const $rawValue$ = letU$$<string>();
    const $rawValue = $rawValue$.emit, rawValue$ = $rawValue$.subscribe;
    // const { emit: $rawValue, subscribe: rawValue$ } = $rawValue$;

    const [$readonly$, readonly$] = createHigherOrderVariable<boolean>(false);

    super([
      ['readonly', $readonly$],
    ]);

    // COLOR
    const color$ = map$$(rawValue$, (colorString: string): IColor => {
      const color: IColor | null = parseCSSColor(colorString);
      return (color === null)
        ? DEFAULT_MAT_COLOR_INPUT_COLOR
        : color;
    });

    const hslaColor$ = shareR$$(map$$(color$, colorToHSLAColor));

    // const $hslaColor = $$map($rawValue, (color: IReadonlyHSLAColor): string => hslaColorToHexString(color));
    const $hslaColor = $$map($rawValue, (color: IReadonlyHSLAColor): string => hslaColorToString(color));
    // hslaColor$(_ => console.log(_, hslaColorToString(_)));


    const previewColor$ = map$$(hslaColor$, hslaColorToString);

    // INPUT
    const inputValue$ = rawValue$;
    const $inputValue = $rawValue;

    const $inputValue$ = {
      subscribe: inputValue$,
      emit: $inputValue,
    };

    /** BINDS **/

    const [open, close] = createOpenCloseTuple<[HTMLElement]>((targetElement: HTMLElement): MatColorInputOverlayComponent => {
      return MatOverlayManagerComponent.getInstance()
        .open(MatColorInputOverlayComponent, [{
          targetElement,
          hslaColor$,
          $hslaColor,
        }]);
    });

    open(this);

    // INIT
    $hslaColor(DEFAULT_MAT_COLOR_INPUT_COLOR);

    this._data = {
      previewColor$,
      $inputValue$,
    };
  }

  onCreate(): IData {
    return this._data;
  }
}
