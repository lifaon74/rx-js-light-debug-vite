import {
  compileAndEvaluateReactiveHTMLAsComponentTemplate, compileReactiveCSSAsComponentStyle, Component,
  DEFAULT_CONSTANTS_TO_IMPORT, generateGetNodeModifierFunctionFromArray, OnCreate, querySelector,
  subscribeOnNodeConnectedTo,
} from '@lifaon/rx-dom';
import { fromAnimationFrame, fromEventTarget, IEmitFunction, ISubscribeFunction } from '@lifaon/rx-js-light';
// @ts-ignore
import style from './mat-color-input-overlay.component.scss';
// @ts-ignore
import html from './mat-color-input-overlay.component.html?raw';
import { ICSSPositionAndSize } from '../../../../../misc/types/position-and-size/css-position-and-size.type';
import { MatSimpleOverlayComponent } from '../../../overlay/overlay/built-in/simple/mat-simple-overlay.component';
import { MatOverlayManagerComponent } from '../../../overlay/overlay/manager/mat-overlay-manager.component';
import { map$$ } from '../../../../../../../../rx-js-light-shortcuts/dist';
import { IPositionAndSize } from '../../../../../misc/types/position-and-size/position-and-size.type';
import { getElementPositionAndSize } from '../../../../../misc/types/position-and-size/get-element-position-and-size';
import { ISize } from '../../../../../misc/types/size/size.type';
import { positionAndSizeToCSSPositionAndSize } from '../../../../../misc/types/position-and-size/position-and-size-to-css-position-and-size';
import { POSITION_AND_SIZE_OUT_OF_WINDOW } from '../../../overlay/overlay/built-in/simple/helper/position-and-size-out-of-window.constant';
import { getFittingBoxForContainer$Target$ContentElements } from '../../../overlay/overlay/built-in/simple/helper/get-fitting-box-for-container-target-content-elements';
import { IHSLAColor, IReadonlyHSLAColor } from '../../../../../misc/css/color/colors/hsla/hsla-color.type';
import { DEFAULT_MAT_COLOR_INPUT_COLOR } from '../misc/default-mat-color-input-color.constant';
import { NODE_REFERENCE_MODIFIER } from '../../modifiers/node-reference.modifier';
import { createHSLAColor } from '../../../../../misc/css/color/colors/hsla/create-hsla-color';
import { hslaColorToHexString } from '../../../../../misc/css/color/colors/hsla/to/hsla-color-to-hex-string';
import { hslaColorToString } from '../../../../../misc/css/color/colors/hsla/to/hsla-color-to-string';


/** FUNCTION **/

function generateHueGradient(
  steps: number = 16,
): string {
  const colorStops: string[] = [];
  const color: IHSLAColor = createHSLAColor(0, 1, 0.5, 1);

  for (let i = 0; i <= steps; i++) {
    const h: number = i / steps;
    color.h = h;
    colorStops.push(`${ hslaColorToHexString(color).slice(0, -2) } ${ (h * 100) }%`);
  }

  return `linear-gradient(to bottom, ${ colorStops.join(', ') })`;
}

// console.log(generateHueGradient());

/** COMPONENT **/


export interface IMatColorInputOverlayComponentOptions {
  readonly targetElement: HTMLElement;
  readonly $hslaColor: IEmitFunction<IReadonlyHSLAColor>;
  readonly hslaColor$: ISubscribeFunction<IReadonlyHSLAColor>;
}


interface IData {
  readonly saturationAndLuminositySelectElementBackgroundColor$: ISubscribeFunction<string>;
  readonly saturationAndLuminositySelectCursorElementLeft$: ISubscribeFunction<string>;
  readonly saturationAndLuminositySelectCursorElementTop$: ISubscribeFunction<string>;
  readonly hueSelectCursorElementTop$: ISubscribeFunction<string>;
  readonly alphaSelectElementBackgroundGradient$: ISubscribeFunction<string>;
  readonly alphaSelectCursorElementTop$: ISubscribeFunction<string>;
  readonly $mouseDownHueSelect: IEmitFunction<MouseEvent>;
  readonly $mouseDownAlphaSelect: IEmitFunction<MouseEvent>;
}

const MAT_COLOR_INPUT_OVERLAY_MODIFIERS = [
  NODE_REFERENCE_MODIFIER,
];

const CONSTANTS_TO_IMPORT = {
  ...DEFAULT_CONSTANTS_TO_IMPORT,
  getNodeModifier: generateGetNodeModifierFunctionFromArray(MAT_COLOR_INPUT_OVERLAY_MODIFIERS)
};

@Component({
  name: 'mat-color-input-overlay',
  template: compileAndEvaluateReactiveHTMLAsComponentTemplate(html, CONSTANTS_TO_IMPORT),
  style: compileReactiveCSSAsComponentStyle(style),
})
export class MatColorInputOverlayComponent extends MatSimpleOverlayComponent implements OnCreate<IData> {
  protected readonly data: IData;

  constructor(
    manager: MatOverlayManagerComponent,
    {
      targetElement,
      $hslaColor,
      hslaColor$,
    }: IMatColorInputOverlayComponentOptions,
  ) {
    const positionAndSize$: ISubscribeFunction<ICSSPositionAndSize> = getPositionAndSizeSubscribeFunctionForColorInputOverlay(
      () => this,
      targetElement,
    );

    super(manager, positionAndSize$);

    let hslaColor: IReadonlyHSLAColor = DEFAULT_MAT_COLOR_INPUT_COLOR;
    hslaColor$((_hslaColor: IReadonlyHSLAColor) => (hslaColor = _hslaColor));


    const saturationAndLuminositySelectElementBackgroundColor$ = map$$(
      hslaColor$,
      (hslaColor: IReadonlyHSLAColor): string => hslaColorToString(createHSLAColor(hslaColor.h, 1, 0.5, 1)),
    );

    // c = c || g.event;
    // c = v(c);
    // var d = b.offsetHeight;
    // a.s = c.x / b.offsetWidth;
    // a.v = (d - c.y) / d;
    // d = h(a);
    // a.callback && a.callback(d.hex, {
    //   h: a.h - s,
    //   s: a.s,
    //   v: a.v
    // }, {
    //   r: d.r,
    //   g: d.g,
    //   b: d.b
    // }, c)

    const saturationAndLuminositySelectCursorElementLeft$ = map$$(
      hslaColor$,
      (hslaColor: IReadonlyHSLAColor): string => `50%`,
    );

    const saturationAndLuminositySelectCursorElementTop$ = map$$(
      hslaColor$,
      (hslaColor: IReadonlyHSLAColor): string => `50%`,
    );


    const hueSelectCursorElementTop$ = map$$(
      hslaColor$,
      (hslaColor: IReadonlyHSLAColor) => `${ (hslaColor.h * 100) }%`,
    );

    const alphaSelectElementBackgroundGradient$ = map$$(
      hslaColor$,
      (hslaColor: IReadonlyHSLAColor): string => {
        const color: string = hslaColorToString({
          ...hslaColor,
          a: 1,
        });
        return `linear-gradient(to bottom, ${ color } 0%, transparent 100%)`;
      },
    );

    const alphaSelectCursorElementTop$ = map$$(
      hslaColor$,
      (hslaColor: IReadonlyHSLAColor) => `${ ((1 - hslaColor.a) * 100) }%`,
    );


    const $mouseDownHueSelect = (event: MouseEvent): void => {
      event.stopPropagation();
      const element: HTMLElement = event.currentTarget as HTMLElement;

      const update = (event: MouseEvent): void => {
        $hslaColor({
          ...hslaColor,
          h: getHueFromMouseEvent(event, element),
        });
      };

      update(event);

      const unsubscribeMouseMove = subscribeOnNodeConnectedTo(
        this,
        fromEventTarget<'mousemove', MouseEvent>(window, 'mousemove'),
        update,
      );

      const unsubscribeMouseUp = subscribeOnNodeConnectedTo(
        this,
        fromEventTarget<'mouseup', MouseEvent>(window, 'mouseup'),
        (event: MouseEvent): void => {
          update(event);
          unsubscribeMouseMove();
          unsubscribeMouseUp();
        },
      );
    };

    const $mouseDownAlphaSelect = (event: MouseEvent): void => {
      event.stopPropagation();
      const element: HTMLElement = event.currentTarget as HTMLElement;

      const update = (event: MouseEvent): void => {
        $hslaColor({
          ...hslaColor,
          a: getAlphaFromMouseEvent(event, element),
        });
      };

      update(event);

      const unsubscribeMouseMove = subscribeOnNodeConnectedTo(
        this,
        fromEventTarget<'mousemove', MouseEvent>(window, 'mousemove'),
        update,
      );

      const unsubscribeMouseUp = subscribeOnNodeConnectedTo(
        this,
        fromEventTarget<'mouseup', MouseEvent>(window, 'mouseup'),
        (event: MouseEvent): void => {
          update(event);
          unsubscribeMouseMove();
          unsubscribeMouseUp();
        },
      );
    };

    this.data = {
      saturationAndLuminositySelectElementBackgroundColor$,
      saturationAndLuminositySelectCursorElementLeft$,
      saturationAndLuminositySelectCursorElementTop$,
      hueSelectCursorElementTop$,
      alphaSelectElementBackgroundGradient$,
      alphaSelectCursorElementTop$,
      $mouseDownHueSelect,
      $mouseDownAlphaSelect,
    };
  }

  onCreate(): IData {
    return this.data;
  }
}


/** FUNCTIONS **/

function getHueFromMouseEvent(event: MouseEvent, element: HTMLElement): number {
  const elementPositionAndSize: IPositionAndSize = getElementPositionAndSize(element);
  return Math.min(Math.max(((event.clientY - elementPositionAndSize.top) / elementPositionAndSize.height), 0), 359 / 360);
}

function getAlphaFromMouseEvent(event: MouseEvent, element: HTMLElement): number {
  const elementPositionAndSize: IPositionAndSize = getElementPositionAndSize(element);
  return 1 - Math.min(Math.max(((event.clientY - elementPositionAndSize.top) / elementPositionAndSize.height), 0), 1);
}

/** FUNCTIONS **/

const elementMargin: number = 5;
const containerHorizontalMargin: number = 5;
const containerVerticalMargin: number = 5;

export function getPositionAndSizeSubscribeFunctionForColorInputOverlay(
  getContainerElement: () => MatColorInputOverlayComponent,
  targetElement: HTMLElement,
): ISubscribeFunction<ICSSPositionAndSize> {
  return map$$<void, ICSSPositionAndSize>(fromAnimationFrame(), () => {
    const containerElement: HTMLElement = getContainerElement();
    const contentElement: HTMLElement | null = querySelector(containerElement, `:scope > .content`);

    if (contentElement === null) {
      return POSITION_AND_SIZE_OUT_OF_WINDOW;
    } else {
      const containerElementPositionAndSize: IPositionAndSize = getElementPositionAndSize(containerElement);
      const targetElementPositionAndSize: IPositionAndSize = getElementPositionAndSize(targetElement);

      const contentElementSize: ISize = {
        width: 200,
        height: 100,
      };

      return positionAndSizeToCSSPositionAndSize(
        getFittingBoxForContainer$Target$ContentElements({
          containerElementPositionAndSize,
          targetElementPositionAndSize,
          contentElementSize,
          // extra
          elementMargin,
          containerHorizontalMargin,
          containerVerticalMargin,
        }),
      );
    }
  });
}

