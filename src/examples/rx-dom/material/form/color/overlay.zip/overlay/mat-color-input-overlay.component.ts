import {
  compileAndEvaluateReactiveHTMLAsComponentTemplate, compileReactiveCSSAsComponentStyle, Component,
  DEFAULT_CONSTANTS_TO_IMPORT, generateGetNodeModifierFunctionFromArray, OnCreate, querySelector,
  subscribeOnNodeConnectedTo,
} from '@lifaon/rx-dom';
import { combineLatest, fromAnimationFrame, IEmitFunction, ISubscribeFunction } from '@lifaon/rx-js-light';
// @ts-ignore
import style from './mat-color-input-overlay.component.scss';
// @ts-ignore
import html from './mat-color-input-overlay.component.html?raw';
import { ICSSPositionAndSize } from '../../../../../misc/types/position-and-size/css-position-and-size.type';
import { MatSimpleOverlayComponent } from '../../../overlay/overlay/built-in/simple/mat-simple-overlay.component';
import { MatOverlayManagerComponent } from '../../../overlay/overlay/manager/mat-overlay-manager.component';
import { letU$$, map$$ } from '../../../../../../../../rx-js-light-shortcuts/dist';
import { IPositionAndSize } from '../../../../../misc/types/position-and-size/position-and-size.type';
import { getElementPositionAndSize } from '../../../../../misc/types/position-and-size/get-element-position-and-size';
import { ISize } from '../../../../../misc/types/size/size.type';
import { positionAndSizeToCSSPositionAndSize } from '../../../../../misc/types/position-and-size/position-and-size-to-css-position-and-size';
import { POSITION_AND_SIZE_OUT_OF_WINDOW } from '../../../overlay/overlay/built-in/simple/helper/position-and-size-out-of-window.constant';
import { getFittingBoxForContainer$Target$ContentElements } from '../../../overlay/overlay/built-in/simple/helper/get-fitting-box-for-container-target-content-elements';
import { IHSLAColor, IReadonlyHSLAColor } from '../../../../../misc/color/hsla/hsla-color.type';
import { DEFAULT_MAT_COLOR_INPUT_COLOR } from '../misc/default-mat-color-input-color.constant';
import { NODE_REFERENCE_MODIFIER } from '../../modifiers/node-reference.modifier';
import { createHSLAColor } from '../../../../../misc/color/hsla/create/create-hsla-color';
import { hslaColorToHexString } from '../../../../../misc/color/hsla/to/hsla-color-to-hex-string';
import { hslaColorToString } from '../../../../../misc/color/hsla/to/hsla-color-to-string';


/** FUNCTION **/

function generateHueGradient(
  steps: number = 16,
): string {
  const colorStops: string[] = [];
  const color: IHSLAColor = createHSLAColor(0, 1, 0.5, 1);

  for (let i = 0; i <= steps; i++) {
    const h: number = i / steps;
    color.h = h;
    colorStops.push(`${ hslaColorToHexString(color).slice(0, -2) } ${ (h * 100) }%`);
  }

  return `linear-gradient(to bottom, ${ colorStops.join(', ') })`;
}

// console.log(generateHueGradient());

/** COMPONENT **/


export interface IMatColorInputOverlayComponentOptions {
  readonly targetElement: HTMLElement;
  readonly $hslaColor: IEmitFunction<IReadonlyHSLAColor>;
  readonly hslaColor$: ISubscribeFunction<IReadonlyHSLAColor>;
}


interface IData {
  readonly $saturationAndLuminositySelectElement: IEmitFunction<HTMLElement>;
  readonly $saturationAndLuminositySelectCursorElement: IEmitFunction<HTMLElement>;
  readonly $alphaSelectElement: IEmitFunction<HTMLElement>;
  readonly $hueSelectCursorElement: IEmitFunction<HTMLElement>;
  readonly $alphaSelectCursorElement: IEmitFunction<HTMLElement>;

  readonly $mouseDownHueSelect: IEmitFunction<MouseEvent>;

}

const MAT_COLOR_INPUT_OVERLAY_MODIFIERS = [
  NODE_REFERENCE_MODIFIER,
];

const CONSTANTS_TO_IMPORT = {
  ...DEFAULT_CONSTANTS_TO_IMPORT,
  getNodeModifier: generateGetNodeModifierFunctionFromArray(MAT_COLOR_INPUT_OVERLAY_MODIFIERS)
};

@Component({
  name: 'mat-color-input-overlay',
  template: compileAndEvaluateReactiveHTMLAsComponentTemplate(html, CONSTANTS_TO_IMPORT),
  style: compileReactiveCSSAsComponentStyle(style),
})
export class MatColorInputOverlayComponent extends MatSimpleOverlayComponent implements OnCreate<IData> {
  protected readonly data: IData;

  constructor(
    manager: MatOverlayManagerComponent,
    {
      targetElement,
      $hslaColor,
      hslaColor$,
    }: IMatColorInputOverlayComponentOptions,
  ) {
    const positionAndSize$: ISubscribeFunction<ICSSPositionAndSize> = getPositionAndSizeSubscribeFunctionForColorInputOverlay(
      () => this,
      targetElement,
    );

    super(manager, positionAndSize$);

    /** HUE SELECT **/

      // const $mouseDownHueSelect$ = letU$$<MouseEvent>();
      // const $mouseDownHueSelect = $mouseDownHueSelect$.emit, mouseDownHueSelect$ = $mouseDownHueSelect$.subscribe;

      // TODO continue here
    let hslaColor: IReadonlyHSLAColor = DEFAULT_MAT_COLOR_INPUT_COLOR;
    hslaColor$((_hslaColor: IReadonlyHSLAColor) => (hslaColor = _hslaColor));

    // hslaColor$((_hslaColor: IReadonlyHSLAColor) => {
    //   hslaColor = _hslaColor;
    // });

    const { emit: $saturationAndLuminositySelectElement, subscribe: saturationAndLuminositySelectElement$ } = letU$$<HTMLElement>();
    const { emit: $saturationAndLuminositySelectCursorElement, subscribe: saturationAndLuminositySelectCursorElement$ } = letU$$<HTMLElement>();
    const { emit: $hueSelectCursorElement, subscribe: hueSelectCursorElement$ } = letU$$<HTMLElement>();
    const { emit: $alphaSelectElement, subscribe: alphaSelectElement$ } = letU$$<HTMLElement>();
    const { emit: $alphaSelectCursorElement, subscribe: alphaSelectCursorElement$ } = letU$$<HTMLElement>();

    subscribeOnNodeConnectedTo(
      this,
      combineLatest(
        [
          hslaColor$,
          saturationAndLuminositySelectElement$,
          saturationAndLuminositySelectCursorElement$,
          hueSelectCursorElement$,
          alphaSelectElement$,
          alphaSelectCursorElement$,
        ] as [
          typeof hslaColor$,
          typeof saturationAndLuminositySelectElement$,
          typeof saturationAndLuminositySelectCursorElement$,
          typeof hueSelectCursorElement$,
          typeof alphaSelectElement$,
          typeof alphaSelectCursorElement$,
        ],
      ),
      ([
         hslaColor,
         saturationAndLuminositySelectElement,
         saturationAndLuminositySelectCursorElement,
         hueSelectCursorElement,
         alphaSelectElement,
         alphaSelectCursorElement$
       ]) => {
        hueSelectCursorElement.style.top = `${ (hslaColor.h * 100) }%`;
        alphaSelectCursorElement$.style.top = `${ ((1 - hslaColor.a) * 100) }%`;

        saturationAndLuminositySelectElement.style.backgroundColor = hslaColorToString(createHSLAColor(hslaColor.h, 1, 0.5, 1));
        alphaSelectElement.style.backgroundColor = hslaColorToString(hslaColor);
      },
    );

    // const $hueSelectCursorElement = () => {
    //
    // };

    const $mouseDownHueSelect = (event: MouseEvent): void => {
      event.stopPropagation();
      const alphaSelectElement: HTMLElement = event.currentTarget as HTMLElement;
      const cursorElement: HTMLElement = alphaSelectElement.querySelector(':scope > .cursor') as HTMLElement;
      const alphaSelectElementPositionAndSize: IPositionAndSize = getElementPositionAndSize(alphaSelectElement);
      console.log(event.currentTarget);
    };


    this.data = {
      $saturationAndLuminositySelectElement,
      $saturationAndLuminositySelectCursorElement,
      $alphaSelectElement,
      $hueSelectCursorElement,
      $alphaSelectCursorElement,

      $mouseDownHueSelect,
    };
  }

  onCreate(): IData {
    return this.data;
  }
}


/** FUNCTIONS **/

const elementMargin: number = 5;
const containerHorizontalMargin: number = 5;
const containerVerticalMargin: number = 5;

export function getPositionAndSizeSubscribeFunctionForColorInputOverlay(
  getContainerElement: () => MatColorInputOverlayComponent,
  targetElement: HTMLElement,
): ISubscribeFunction<ICSSPositionAndSize> {
  return map$$<void, ICSSPositionAndSize>(fromAnimationFrame(), () => {
    const containerElement: HTMLElement = getContainerElement();
    const contentElement: HTMLElement | null = querySelector(containerElement, `:scope > .content`);

    if (contentElement === null) {
      return POSITION_AND_SIZE_OUT_OF_WINDOW;
    } else {
      const containerElementPositionAndSize: IPositionAndSize = getElementPositionAndSize(containerElement);
      const targetElementPositionAndSize: IPositionAndSize = getElementPositionAndSize(targetElement);

      const contentElementSize: ISize = {
        width: 200,
        height: 100,
      };

      return positionAndSizeToCSSPositionAndSize(
        getFittingBoxForContainer$Target$ContentElements({
          containerElementPositionAndSize,
          targetElementPositionAndSize,
          contentElementSize,
          // extra
          elementMargin,
          containerHorizontalMargin,
          containerVerticalMargin,
        }),
      );
    }
  });
}

