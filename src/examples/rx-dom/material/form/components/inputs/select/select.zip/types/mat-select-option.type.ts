/** TYPES **/

export interface IMatSelectOption {
  label: string;
  value: any;
  selected: boolean;
}

// export type IMatSelectOptions = IMatSelectOption[];

/* READONLY */

export type IReadonlyMatSelectOption = Readonly<IMatSelectOption>;
export type IReadonlyMatSelectOptions = readonly IReadonlyMatSelectOption[];

