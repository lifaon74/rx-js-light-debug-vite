import {
  compileAndEvaluateReactiveHTMLAsComponentTemplate, compileReactiveCSSAsComponentStyle, Component,
  DEFAULT_CONSTANTS_TO_IMPORT, generateGetNodeModifierFunctionFromArray, HTMLElementConstructor, OnCreate,
  onNodeConnectedToWithImmediateCached, subscribeOnNodeConnectedTo,
} from '@lifaon/rx-dom';
// @ts-ignore
import html from './mat-select.component.html?raw';
// @ts-ignore
import style from './mat-select.component.scss';
import { havingMultipleSubscribeFunctionProperties } from '../../../../misc/having-multiple-subscribe-function-properties';
import { createHigherOrderVariable } from '../../../../misc/create-higher-order-variable';
import { let$$, letU$$, mergeMapS$$ } from '@lifaon/rx-js-light-shortcuts';
import { INPUT_VALUE_MODIFIER } from '../modifiers/input-value.modifier';
import {
  combineLatest, IEmitFunction, IMulticastReplayLastSource, ISubscribeFunction, mutateReadonlyReplayLastSourceArray
} from '@lifaon/rx-js-light';
import { NODE_REFERENCE_MODIFIER } from '../modifiers/node-reference.modifier';
import { focusSubscribeFunction } from '../../helpers/focus-subscribe-function';
import { MatOverlayManagerComponent } from '../../overlay/overlay/manager/mat-overlay-manager.component';
import { MatSelectOverlayComponent } from './overlay/mat-select-overlay.component';
import { createOpenCloseTuple } from '../../overlay/overlay/component/helpers/create-open-close-tuple';
import { IMatSelectOption, IMatSelectOptions, IReadonlyMatSelectOptions } from './types/mat-select-option.type';


/** COMPONENT **/

type IMatSelectComponentInputs = [
  // ['options', IMatSelectOptions],
];


interface IData {
  $inputValue$: IMulticastReplayLastSource<string>;
  $input: IEmitFunction<HTMLInputElement>;
}

const MAT_SELECT_MODIFIERS = [
  INPUT_VALUE_MODIFIER,
  NODE_REFERENCE_MODIFIER,
];

const CONSTANTS_TO_IMPORT = {
  ...DEFAULT_CONSTANTS_TO_IMPORT,
  getNodeModifier: generateGetNodeModifierFunctionFromArray(MAT_SELECT_MODIFIERS)
};

@Component({
  name: 'mat-select',
  template: compileAndEvaluateReactiveHTMLAsComponentTemplate(html, CONSTANTS_TO_IMPORT),
  style: compileReactiveCSSAsComponentStyle(style),
})
export class MatSelectComponent extends havingMultipleSubscribeFunctionProperties<IMatSelectComponentInputs, HTMLElementConstructor>(HTMLElement) implements OnCreate<IData> {
  protected readonly _$options$: IMulticastReplayLastSource<IMatSelectOptions>;
  protected readonly _data: IData;

  constructor() {
    // const [$options$, options$] = createHigherOrderVariable<IMatSelectOptions>([]);

    super([
      // ['options', $options$],
    ]);

    const $options$ = let$$<IMatSelectOption[]>([]);
    this._$options$ = $options$;
    const options$ = $options$.subscribe;

    const $inputValue$ = let$$<string>('');

    const { emit: $input, subscribe: input$ } = letU$$<HTMLInputElement>();

    const focused$ = mergeMapS$$(input$, focusSubscribeFunction);
    // TODO share ?
    // TODO debounce ?

    /** OPTIONS **/


    const onClickOption = (option: IMatSelectOption, index: number): void => {
      const options: IMatSelectOption[] = $options$.getValue();
      // options[index].selected
    };


    /** BINDS **/

    const [open, close] = createOpenCloseTuple<[HTMLInputElement]>((targetElement: HTMLInputElement): MatSelectOverlayComponent => {
      return MatOverlayManagerComponent.getInstance()
        .open(MatSelectOverlayComponent, [{ targetElement, options$, onClickOption }]);
    });

    subscribeOnNodeConnectedTo(
      this,
      combineLatest([input$, focused$] as [ISubscribeFunction<HTMLInputElement>, ISubscribeFunction<boolean>]),
      ([input, focused]: readonly [HTMLInputElement, boolean]) => {
        if (focused) {
          open(input);
        } else {
          // close();
        }
      },
    );

    onNodeConnectedToWithImmediateCached(this)((connected: boolean) => {
      if (!connected) {
        close();
      }
    });


    this._data = {
      $inputValue$,
      $input,
    };
  }

  get options(): IReadonlyMatSelectOptions {
    return this._$options$.getValue();
  }

  set options(value: IReadonlyMatSelectOptions) {
    this._$options$.emit(value);
  }

  get options$(): ISubscribeFunction<IReadonlyMatSelectOptions> {
    return this._$options$.subscribe;
  }

  onCreate(): IData {
    return this._data;
  }

}
