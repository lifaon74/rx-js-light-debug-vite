/** TYPES **/

export interface IMatSelectOption<GValue> {
  readonly id?: string;
  readonly disabled: string;
  readonly label: string;
  readonly value: GValue;
  readonly selected: boolean;
}

export type IMatSelectOptions<GValue> = readonly IMatSelectOption<GValue>[];
