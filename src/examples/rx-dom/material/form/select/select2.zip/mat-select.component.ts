import {
  compileAndEvaluateReactiveHTMLAsComponentTemplate, compileReactiveCSSAsComponentStyle, Component,
  DEFAULT_CONSTANTS_TO_IMPORT, generateGetNodeModifierFunctionFromArray, HTMLElementConstructor, OnCreate,
  onNodeConnectedToWithImmediateCached, subscribeOnNodeConnectedTo,
} from '@lifaon/rx-dom';
// @ts-ignore
import html from './mat-select.component.html?raw';
// @ts-ignore
import style from './mat-select.component.scss';
import { havingMultipleSubscribeFunctionProperties } from '../../../../misc/having-multiple-subscribe-function-properties';
import { createHigherOrderVariable } from '../../../../misc/create-higher-order-variable';
import { let$$, letU$$, mergeMapS$$ } from '@lifaon/rx-js-light-shortcuts';
import { INPUT_VALUE_MODIFIER } from '../modifiers/input-value.modifier';
import {
  combineLatest, IEmitFunction, IMulticastReplayLastSource, ISubscribeFunction, readSubscribeFunctionValue
} from '@lifaon/rx-js-light';
import { NODE_REFERENCE_MODIFIER } from '../modifiers/node-reference.modifier';
import { focusSubscribeFunction } from '../../helpers/focus-subscribe-function';
import { MatOverlayManagerComponent } from '../../overlay/overlay/manager/mat-overlay-manager.component';
import { MatSelectOverlayComponent } from './overlay/mat-select-overlay.component';
import { createOpenCloseTuple } from '../../overlay/overlay/component/helpers/create-open-close-tuple';
import { IMatSelectOption, IMatSelectOptions } from './types/mat-select-option.type';


// function toggleMatSelectOptionSelected(
//   $options$: IReplayLastSource<ISubscribeFunction<IMatSelectOptions>, IGenericSource>,
//   index: number,
//   selected?: boolean,
// ): void {
//   const options: IMatSelectOptions = readSubscribeFunctionValue($options$.getValue(), (): IMatSelectOptions => {
//     throw new Error(`Unable to read options`);
//   });
//
//   if (selected === void 0) {
//     selected = !options[index].selected;
//   }
//
//   $options$.emit(single([
//     ...options.slice(0, index),
//     {
//       ...options[index],
//       selected,
//     },
//     ...options.slice(index + 1),
//   ]));
// }
//
// function toggleMatSelectOptionSelectedInPlace(
//   $options$: IReplayLastSource<ISubscribeFunction<IMatSelectOptions>, IGenericSource>,
//   index: number,
//   selected?: boolean,
// ): void {
//   const options: IMatSelectOptions = readSubscribeFunctionValue($options$.getValue(), (): IMatSelectOptions => {
//     throw new Error(`Unable to read options`);
//   });
//
//   (options[index] as any).selected = (selected === void 0)
//     ? !options[index].selected
//     : selected;
//   $options$.emit(single(options));
// }

// function toggleMatSelectOptionSelected<GValue>(
//   options: IMatSelectOptions<GValue>,
//   index: number,
//   selected: boolean = !options[index].selected,
// ): IMatSelectOptions<GValue> {
//   return [
//     ...options.slice(0, index),
//     {
//       ...options[index],
//       selected,
//     },
//     ...options.slice(index + 1),
//   ];
// }
//
// function toggleMatSelectOptionSelectedInPlace<GValue>(
//   options: IMatSelectOptions<GValue>,
//   index: number,
//   selected: boolean = !options[index].selected,
// ): IMatSelectOptions<GValue> {
//   (options[index] as any).selected = (selected === void 0)
//     ? !options[index].selected
//     : selected;
//   return options;
// }


/** COMPONENT **/

type IMatSelectComponentInputs<GValue> = [
  ['options', IMatSelectOptions<GValue>],
  ['multiple', boolean],
];


interface IData {
  $inputValue$: IMulticastReplayLastSource<string>;
  $input: IEmitFunction<HTMLInputElement>;
}

const MAT_SELECT_MODIFIERS = [
  INPUT_VALUE_MODIFIER,
  NODE_REFERENCE_MODIFIER,
];

const CONSTANTS_TO_IMPORT = {
  ...DEFAULT_CONSTANTS_TO_IMPORT,
  getNodeModifier: generateGetNodeModifierFunctionFromArray(MAT_SELECT_MODIFIERS)
};

@Component({
  name: 'mat-select',
  template: compileAndEvaluateReactiveHTMLAsComponentTemplate(html, CONSTANTS_TO_IMPORT),
  style: compileReactiveCSSAsComponentStyle(style),
})
export class MatSelectComponent<GValue> extends havingMultipleSubscribeFunctionProperties<IMatSelectComponentInputs<any>, HTMLElementConstructor>(HTMLElement) implements OnCreate<IData> {
  protected readonly _data: IData;

  constructor() {
    const [$options$, options$] = createHigherOrderVariable<IMatSelectOptions<GValue>>([]);
    const [$multiple$, multiple$] = createHigherOrderVariable<boolean>(false);

    super([
      ['options', $options$],
      ['multiple', $multiple$],
    ]);

    const $inputValue$ = let$$<string>('');

    const { emit: $input, subscribe: input$ } = letU$$<HTMLInputElement>();

    const focused$ = mergeMapS$$(input$, focusSubscribeFunction);
    // TODO share ?
    // TODO debounce ?

    /** OPTIONS **/

    const onClickOption = (option: IMatSelectOption<GValue>): void => {
      const options: IMatSelectOptions<GValue> = readSubscribeFunctionValue($options$.getValue(), (): IMatSelectOptions<GValue> => {
        throw new Error(`Unable to read options`);
      });

      const newOptions: IMatSelectOptions<GValue> = options.map((option: IMatSelectOptions<GValue>): IMatSelectOptions<GValue> => {
        return {

        };
      });

      toggleMatSelectOptionSelectedInPlace($options$, index);
    };


    /** BINDS **/

    const [open, close] = createOpenCloseTuple<[HTMLInputElement]>((targetElement: HTMLInputElement): MatSelectOverlayComponent<GValue> => {
      return MatOverlayManagerComponent.getInstance()
        .open(MatSelectOverlayComponent, [{ targetElement, options$, onClickOption }]);
    });

    subscribeOnNodeConnectedTo(
      this,
      combineLatest([input$, focused$] as [ISubscribeFunction<HTMLInputElement>, ISubscribeFunction<boolean>]),
      ([input, focused]: readonly [HTMLInputElement, boolean]) => {
        if (focused) {
          open(input);
        } else {
          // close();
        }
      },
    );

    onNodeConnectedToWithImmediateCached(this)((connected: boolean) => {
      if (!connected) {
        close();
      }
    });


    this._data = {
      $inputValue$,
      $input,
    };
  }

  onCreate(): IData {
    return this._data;
  }

}
