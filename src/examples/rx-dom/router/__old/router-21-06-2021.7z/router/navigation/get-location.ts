export function getLocation(): Location {
  return window.location;
}

