import { IRoute } from './route.type';
import { IRouteParams } from './route-params/route-params.type';
import { IResolvedRoute } from './resolved/resolved-route.type';
import { NOT_MATCHING_RESOLVED_ROUTE } from './resolved/not-matching-resolved-route.constant';
import { normalizeRoutePath } from './functions/normalize-route-path';
import { IRoutesList } from './list/routes-list.type';
import { ICanActivateFunctionReturn } from './can-activate/can-activate-function.type';
import { DEFAULT_ABORTED_PROMISE_FACTORY, wrapFunctionWithAbortSignalAndThrow } from '@lifaon/rx-js-light';


export interface IResolveRouteOptions<GExtra> {
  route: IRoute<GExtra>;
  path: string; // normalized
  params: IRouteParams;
  signal: AbortSignal;
}

export function resolveRoute<GExtra>(
  {
    route,
    path: pathToResolve,
    params,
    signal,
  }: IResolveRouteOptions<GExtra>,
): Promise<IResolvedRoute<GExtra>> {
  if (signal.aborted) {
    return DEFAULT_ABORTED_PROMISE_FACTORY(signal);
  }

  const {
    path: routePath,
    canActivate,
    loadChildren,
    extra,
  } = route;

  const match: RegExpExecArray | null = routePath.exec(pathToResolve);

  if (match === null) {
    return Promise.resolve<IResolvedRoute<GExtra>>(NOT_MATCHING_RESOLVED_ROUTE);
  } else {
    const routeParams: IRouteParams = {
      ...params,
      ...match.groups,
    };

    return canActivate(routeParams, signal)
      .then(wrapFunctionWithAbortSignalAndThrow((isRouteActivable: ICanActivateFunctionReturn): Promise<IResolvedRoute<GExtra>> | IResolvedRoute<GExtra> => {
        if (isRouteActivable !== true) {
          return {
            state: 'redirect',
            to: isRouteActivable,
          };
        } else {
          return loadChildren(signal)
            .then(wrapFunctionWithAbortSignalAndThrow((childRoutes: IRoutesList<GExtra>): Promise<IResolvedRoute<GExtra>> | IResolvedRoute<GExtra> => {
              const remainingPath: string = normalizeRoutePath(pathToResolve.slice(match[0].length));

              if (childRoutes.length === 0) {
                if (remainingPath === '/') {
                  return {
                    state: 'matching',
                    params: routeParams,
                    childRoute: null,
                    extra,
                  };
                } else {
                  return NOT_MATCHING_RESOLVED_ROUTE;
                }
              } else {
                return resolveRoutes<GExtra>({
                  routes: childRoutes,
                  path: remainingPath,
                  params: routeParams,
                  signal,
                })
                  .then(wrapFunctionWithAbortSignalAndThrow((resolvedRoute: IResolvedRoute<GExtra>): Promise<IResolvedRoute<GExtra>> | IResolvedRoute<GExtra> => {
                    if (resolvedRoute.state === 'matching') {
                      return {
                        state: 'matching',
                        params: routeParams,
                        childRoute: resolvedRoute,
                        extra,
                      };
                    } else {
                      return resolvedRoute;
                    }
                  }, signal));
              }
            }, signal));
        }
      }, signal));
  }
}


/*----*/

export interface IResolveRoutesOptions<GExtra> extends Omit<IResolveRouteOptions<GExtra>, 'route'> {
  routes: IRoutesList<GExtra>,
}


export function resolveRoutes<GExtra>(
  {
    routes,
    signal,
    ...options
  }: IResolveRoutesOptions<GExtra>,
): Promise<IResolvedRoute<GExtra>> {
  return routes.reduce<Promise<IResolvedRoute<GExtra>>>(
    (
      promise: Promise<IResolvedRoute<GExtra>>,
      route: IRoute<GExtra>,
    ): Promise<IResolvedRoute<GExtra>> => {
      return promise
        .then(wrapFunctionWithAbortSignalAndThrow((resolvedRoute: IResolvedRoute<GExtra>): Promise<IResolvedRoute<GExtra>> | IResolvedRoute<GExtra> => {
          if (resolvedRoute.state === 'not-matching') {
            return resolveRoute<GExtra>({
              ...options,
              route,
              signal,
            });
          } else {
            return resolvedRoute;
          }
        }, signal));
    },
    signal.aborted
      ? DEFAULT_ABORTED_PROMISE_FACTORY(signal)
      : Promise.resolve<IResolvedRoute<GExtra>>(NOT_MATCHING_RESOLVED_ROUTE),
  );
}
