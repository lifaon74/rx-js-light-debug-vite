import { IClickType } from '../click/click-type.type';
import { ILinkType } from '../link/link-type.type';


export type IClickOrLinkType = IClickType | ILinkType;

