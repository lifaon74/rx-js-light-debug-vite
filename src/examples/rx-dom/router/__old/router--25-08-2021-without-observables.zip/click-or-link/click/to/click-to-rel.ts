import { IClickType } from '../click-type.type';

export function clickToRel(
  value?: IClickType,
): string {
  return '';
}
