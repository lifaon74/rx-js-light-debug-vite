import { IMatchingResolvedRXRoute, IRXRouteComponent, IRXRouterOutletElement } from '../rx-route/rx-route';
import { nodeAppendChild } from '@lifaon/rx-dom';
import { createMulticastReplayLastSource, IMulticastReplayLastSource, IObservable } from '@lifaon/rx-js-light';
import { IRouteParams } from '../route/route-params/route-params.type';


/*--------------------------*/



export interface IInjectMatchingResolvedRXRouteOptions {
  resolvedRoute: IMatchingResolvedRXRoute;
  routerOutletElement: IRXRouterOutletElement;
  signal: AbortSignal;
}

export type IInjectedComponentState =
  'new'
  | 'recycled'
  ;

export interface IInjectedComponent {
  state: IInjectedComponentState;
  element: Element;
}

export type IOptionalInjectedComponent = IInjectedComponent | null;
export type IOptionalInjectedComponentList = readonly IOptionalInjectedComponent[];


export async function injectMatchingResolvedRXRoute(
  {
    resolvedRoute,
    routerOutletElement,
    signal, // TODO support signal
  }: IInjectMatchingResolvedRXRouteOptions,
): Promise<IOptionalInjectedComponentList> {

  const {
    params,
    childRoute,
    extra,
  } = resolvedRoute;

  const {
    locateRXRouterOutletElement,
    loadComponent,
    forceComponentReload,
  } = extra;

  let injectedComponent: IInjectedComponent | null;

  if (loadComponent === null) {
    injectedComponent = null;
  } else {
    const component: IRXRouteComponent = await loadComponent(signal);
    const routerOutletFirstElementChild: Element | null = routerOutletElement.firstElementChild;

    if (
      forceComponentReload
      || (routerOutletFirstElementChild === null)
      || (routerOutletFirstElementChild.constructor !== component)
    ) {
      const element: Element = nodeAppendChild(routerOutletElement, new component());
      injectedComponent = {
        state: 'new',
        element,
      };
      setRouteParams(element, params);
    } else {
      injectedComponent = {
        state: 'recycled',
        element: routerOutletFirstElementChild,
      };
      setRouteParams(routerOutletFirstElementChild, params);
    }
  }

  if (childRoute === null) {
    return [
      injectedComponent,
    ];
  } else {
    const childRouterOutletElement: IRXRouterOutletElement = (loadComponent === null)
      ? routerOutletElement
      : await locateRXRouterOutletElement(routerOutletElement, signal);

    const injectedChildComponents: IOptionalInjectedComponentList = await injectMatchingResolvedRXRoute({
      resolvedRoute: childRoute,
      routerOutletElement: childRouterOutletElement,
      signal,
    });

    return [
      injectedComponent,
      ...injectedChildComponents,
    ];
  }
}


/* PARAMS */

const COMPONENT_PARAMS = new WeakMap<Element, IMulticastReplayLastSource<IRouteParams>>();

function getRouteParamsSource(
  component: Element,
): IMulticastReplayLastSource<IRouteParams> {
  let $routeParams$: IMulticastReplayLastSource<IRouteParams> | undefined = COMPONENT_PARAMS.get(component);
  if ($routeParams$ === void 0) {
    $routeParams$ = createMulticastReplayLastSource<IRouteParams>();
    COMPONENT_PARAMS.set(component, $routeParams$);
  }
  return $routeParams$;
}

function setRouteParams(
  component: Element,
  params: IRouteParams,
): void {
  return getRouteParamsSource(component).emit(params);
}

export function getRouteParams(
  component: Element,
): IObservable<IRouteParams> {
  return getRouteParamsSource(component).subscribe;
}
