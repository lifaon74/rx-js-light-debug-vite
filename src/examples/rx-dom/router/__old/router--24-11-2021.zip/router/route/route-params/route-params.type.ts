
export interface IRouteParams {
  readonly [key: string]: string;
}
