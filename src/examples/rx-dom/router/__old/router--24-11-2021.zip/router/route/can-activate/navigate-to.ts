import { INavigateTo } from '../navigate-to/navigate-to.type';
import { ICanActivateFunction } from './can-activate-function.type';

export function navigateTo(
  url: INavigateTo,
): ICanActivateFunction {
  return () => Promise.resolve(url);
}
