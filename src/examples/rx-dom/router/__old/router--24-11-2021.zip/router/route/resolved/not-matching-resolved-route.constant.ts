import { INotMatchingResolvedRoute } from './not-matching-resolved-route.type';

export const NOT_MATCHING_RESOLVED_ROUTE: INotMatchingResolvedRoute = {
  state: 'not-matching',
};
