import { IStringOrURL } from '@lifaon/rx-dom';

export type INavigateTo = IStringOrURL;
