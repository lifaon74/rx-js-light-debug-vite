export interface INotMatchingResolvedRoute {
  state: 'not-matching';
}
