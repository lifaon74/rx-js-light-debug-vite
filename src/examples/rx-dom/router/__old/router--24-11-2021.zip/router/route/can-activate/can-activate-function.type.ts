import { IRouteParams } from '../route-params/route-params.type';
import { INavigateTo } from '../navigate-to/navigate-to.type';

export type ICanActivateFunctionReturn = INavigateTo | true;

export interface ICanActivateFunction {
  (
    params: IRouteParams,
    signal: AbortSignal,
  ): Promise<ICanActivateFunctionReturn>;
}
