import { ICanActivateFunction, ICanActivateFunctionReturn } from './can-activate-function.type';
import { DEFAULT_ABORTED_PROMISE_FACTORY } from '@lifaon/rx-js-light';
import { IRouteParams } from '../route-params/route-params.type';

export const DEFAULT_CAN_ACTIVATE_FUNCTION: ICanActivateFunction = (
  params: IRouteParams,
  signal: AbortSignal,
): Promise<ICanActivateFunctionReturn> => {
  return signal.aborted
    ? DEFAULT_ABORTED_PROMISE_FACTORY(signal)
    : Promise.resolve(true);
};
