import { IRoutesList } from './routes-list.type';

export interface ILoadRoutesListFunction<GExtra> {
  (
    signal: AbortSignal,
  ): Promise<IRoutesList<GExtra>>;
}
