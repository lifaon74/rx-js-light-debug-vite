import { HTMLElementConstructor } from '@lifaon/rx-dom';

import { locateRouterOutletElement, ROUTER_OUTLET_ATTRIBUTE_NAME } from '../router-outlet/rx-router-outlet';
import { convertRoutePathToRegExp } from '../route/functions/convert-route-path-to-reg-exp';
import { normalizeRoutePath } from '../route/functions/normalize-route-path';
import { ICanActivateFunction } from '../route/can-activate/can-activate-function.type';
import { DEFAULT_CAN_ACTIVATE_FUNCTION } from '../route/can-activate/default-can-activate-function.constant';
import { IRoute } from '../route/route.type';
import { IRoutesList } from '../route/list/routes-list.type';
import { ILoadRoutesListFunction } from '../route/list/load-routes-list-function.type';
import { IResolvedRoute } from '../route/resolved/resolved-route.type';
import { IMatchingResolvedRoute } from '../route/resolved/matching-resolved-route.type';
import {
  DEFAULT_ABORTED_PROMISE_FACTORY, isAbortError, wrapFunctionWithAbortSignalAndThrow,
} from '@lifaon/rx-js-light';

/** GENERIC ROUTE **/

/* ROUTE */

export interface IRXRoute {
  path: string;
  children?: IRXRoutesListOrLoadRXRoutesListFunction;
  canActivate?: ICanActivateFunction;
  component?: IRXRouteComponentOrLoadRXRouteComponentFunction;
  locateRXRouterOutletElement?: ILocateRXRouterOutletFunction;
  forceComponentReload?: boolean;
}

// LIST

export type IRXRoutesList = readonly IRXRoute[];

export interface ILoadRXRoutesListFunction {
  (
    signal: AbortSignal,
  ): Promise<IRXRoutesList>;
}

export type IRXRoutesListOrLoadRXRoutesListFunction =
  IRXRoutesList
  | ILoadRXRoutesListFunction
  ;

// COMPONENT

export type IRXRouteComponent = HTMLElementConstructor;

export interface ILoadRXRouteComponentFunction {
  (
    signal: AbortSignal,
  ): Promise<IRXRouteComponent>;
}

export type IRXRouteComponentOrLoadRXRouteComponentFunction =
  IRXRouteComponent
  | ILoadRXRouteComponentFunction
  ;

export type ILoadRXRouteComponentFunctionOrNull = ILoadRXRouteComponentFunction | null;


// LOCATE ROUTER OUTLET

export type IRXRouterOutletElement = Element;
export type IOptionalRXRouterOutletElement = IRXRouterOutletElement | null;

export interface ILocateRXRouterOutletFunction {
  (
    parentElement: Element,
    signal: AbortSignal,
  ): Promise<IRXRouterOutletElement>;
}

export const DEFAULT_LOCATE_ROUTER_OUTLET: ILocateRXRouterOutletFunction = (
  parentElement: Element,
  signal: AbortSignal,
): Promise<IRXRouterOutletElement> => {
  return locateRouterOutletElement(`[${ROUTER_OUTLET_ATTRIBUTE_NAME}]`, parentElement, signal);
};


/** TO RESOLVABLE **/

export interface IRXRouteExtra {
  loadComponent: ILoadRXRouteComponentFunctionOrNull;
  locateRXRouterOutletElement: ILocateRXRouterOutletFunction;
  forceComponentReload: boolean;
}

export type IResolvableRXRoute = IRoute<IRXRouteExtra>;
export type IResolvedRXRoute = IResolvedRoute<IRXRouteExtra>;
export type IMatchingResolvedRXRoute = IMatchingResolvedRoute<IRXRouteExtra>;


export function rxRouteToResolvableRoute(
  {
    path,
    children,
    canActivate = DEFAULT_CAN_ACTIVATE_FUNCTION,
    component,
    locateRXRouterOutletElement = DEFAULT_LOCATE_ROUTER_OUTLET,
    forceComponentReload = false,
  }: IRXRoute,
): IResolvableRXRoute {
  return {
    path: convertRoutePathToRegExp(normalizeRoutePath(path)),
    canActivate,
    loadChildren: createLoadAndCacheRXRouteChildrenAsResolvableRouteFunction(children),

    extra: {
      loadComponent: createLoadAndCacheRXRouteComponentFunction(component),
      locateRXRouterOutletElement,
      forceComponentReload,
    },
  };
}

export function genericRoutesListToResolvableRoutesList(
  routes: IRXRoutesList,
): IResolvableRXRoute[] {
  return routes.map(rxRouteToResolvableRoute);
}

// CHILDREN

function createLoadRXRouteChildrenFunction(
  children: IRXRoutesListOrLoadRXRoutesListFunction | undefined,
): ILoadRXRoutesListFunction {
  return (children === void 0)
    ? (signal: AbortSignal): Promise<IRXRoutesList> => {
      return signal.aborted
        ? DEFAULT_ABORTED_PROMISE_FACTORY(signal)
        : Promise.resolve<IRXRoutesList>([]);
    }
    : (
      (typeof children === 'function')
        ? children
        : (signal: AbortSignal): Promise<IRXRoutesList> => {
          return signal.aborted
            ? DEFAULT_ABORTED_PROMISE_FACTORY(signal)
            : Promise.resolve<IRXRoutesList>(children);
        }
    );
}

export type IRXResolvableRoutesList = IRoutesList<IRXRouteExtra>;
export type ILoadRXResolvableRoutesListFunction = ILoadRoutesListFunction<IRXRouteExtra>;

function createLoadRXRouteChildrenAsResolvableRouteFunction(
  children: IRXRoutesListOrLoadRXRoutesListFunction | undefined,
): ILoadRXResolvableRoutesListFunction {
  const loadChildren: ILoadRXRoutesListFunction = createLoadRXRouteChildrenFunction(children);
  return (
    signal: AbortSignal,
  ): Promise<IRXResolvableRoutesList> => {
    return loadChildren(signal)
      .then(wrapFunctionWithAbortSignalAndThrow((children: IRXRoutesList): IRXResolvableRoutesList => {
        return children.map(rxRouteToResolvableRoute);
      }, signal));
  };
}

function createLoadAndCacheRXRouteChildrenAsResolvableRouteFunction(
  children: IRXRoutesListOrLoadRXRoutesListFunction | undefined,
): ILoadRXResolvableRoutesListFunction {
  const loadChildren: ILoadRXResolvableRoutesListFunction = createLoadRXRouteChildrenAsResolvableRouteFunction(children);
  let promise: Promise<IRXResolvableRoutesList> | undefined;
  return (
    signal: AbortSignal,
  ): Promise<IRXResolvableRoutesList> => {
    if (promise === void 0) {
      promise = loadChildren(signal)
        .catch((error: unknown): never => {
          if (isAbortError(error)) {
            promise = void 0;
          }
          throw error;
        });
    }
    return promise;
  };
}


// COMPONENT

function createLoadRXRouteComponentFunction(
  component: IRXRouteComponentOrLoadRXRouteComponentFunction | undefined,
): ILoadRXRouteComponentFunctionOrNull {
  return (component === void 0)
    ? null
    : (
      (typeof component === 'function')
        ? component as ILoadRXRouteComponentFunction
        : (signal: AbortSignal): Promise<IRXRouteComponent> => {
          return signal.aborted
            ? DEFAULT_ABORTED_PROMISE_FACTORY(signal)
            : Promise.resolve<IRXRouteComponent>(component);
        }
    );
}

function createLoadAndCacheRXRouteComponentFunction(
  component: IRXRouteComponentOrLoadRXRouteComponentFunction | undefined,
): ILoadRXRouteComponentFunctionOrNull {
  const loadComponent: ILoadRXRouteComponentFunctionOrNull = createLoadRXRouteComponentFunction(component);
  if (loadComponent === null) {
    return null;
  } else {
    let promise: Promise<IRXRouteComponent> | undefined;
    return (
      signal: AbortSignal,
    ): Promise<IRXRouteComponent> => {
      if (promise === void 0) {
        promise = loadComponent(signal)
          .catch((error: unknown): never => {
            if (isAbortError(error)) {
              promise = void 0;
            }
            throw error;
          });
      }
      return promise;
    };
  }
}

/** LOAD COMPONENTS **/

// export interface IRXRouteWithLoadedComponentExtra extends Omit<IRXRouteExtra, 'loadComponent'> {
//   component: IRXRouteComponent | null;
// }
//
// export type IResolvedRXRouteWithLoadedComponent = IResolvedRoute<IRXRouteWithLoadedComponentExtra>;
// export type IMatchingResolvedRXRouteWithLoadedComponent = IMatchingResolvedRoute<IRXRouteWithLoadedComponentExtra>;
//
//
// export function loadResolvedRXRouteComponents(
//   route: IResolvedRXRoute,
//   signal: AbortSignal,
// ): Promise<IResolvedRXRouteWithLoadedComponent> {
//   return (route.state === 'matching')
//     ? loadMatchingResolvedRXRouteComponents(route, signal)
//     : (
//       signal.aborted
//         ? DEFAULT_ABORTED_PROMISE_FACTORY(signal)
//         : Promise.resolve<IResolvedRXRouteWithLoadedComponent>(route)
//     );
// }
//
// export function loadMatchingResolvedRXRouteComponents(
//   {
//     childRoute,
//     extra,
//     ...route
//   }: IMatchingResolvedRXRoute,
//   signal: AbortSignal,
// ): Promise<IMatchingResolvedRXRouteWithLoadedComponent> {
//   const {
//     loadComponent,
//   } = extra;
//
//   return Promise.all([
//     (loadComponent === null)
//       ? null
//       : loadComponent(signal),
//     (childRoute === null)
//       ? null
//       : loadMatchingResolvedRXRouteComponents(childRoute, signal),
//   ])
//     .then(wrapFunctionWithAbortSignalAndThrow(([component, childRoute]): IMatchingResolvedRXRouteWithLoadedComponent => {
//       return {
//         ...route,
//         childRoute,
//         extra: {
//           ...extra,
//           component,
//         },
//       };
//     }, signal));
// }
