export function getHistory(): History {
  return window.history;
}
