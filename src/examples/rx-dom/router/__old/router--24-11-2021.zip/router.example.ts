import { normalizeRoutePath } from './router/route/functions/normalize-route-path';
import {
  genericRoutesListToResolvableRoutesList, IResolvableRXRoute, IRXRouterOutletElement, IRXRoutesList,
} from './router/rx-route/rx-route';
import { navigateTo } from './router/route/can-activate/navigate-to';
import { resolveRoutes } from './router/route/resolve-route';
import { injectMatchingResolvedRXRoute } from './router/inject/inject';
import { createNotAValidPathForThisRouteError } from './router/errors/not-a-valid-path-for-this-route-error/not-a-valid-path-for-this-route-error';
import { getBaseURI, getDocumentBody, stringOrURLToString } from '@lifaon/rx-dom';
import { NAVIGATION } from './navigation/navigation';
import { getLocation } from './navigation/get-location';

// export interface IUndoResolveAndInjectRXRoutesFunction {
//   (): void;
// }

export interface IResolveAndInjectRXRoutesFunctionOptions {
  routes: readonly IResolvableRXRoute[];
  path: string; // normalized
  routerOutletElement: IRXRouterOutletElement;
  signal: AbortSignal;
}

export async function resolveAndInjectRXRoutes(
  {
    routes,
    path,
    routerOutletElement,
    signal, // TODO support signal
  }: IResolveAndInjectRXRoutesFunctionOptions,
): Promise<any> {
  const resolvedRoute = await resolveRoutes({
    routes,
    path: normalizeRoutePath(path),
    params: {},
    signal,
  });
  // const resolvedRouteWithComponents = await loadResolvedRXRouteComponents(resolvedRoute, signal);
  // console.log(resolvedRouteWithComponents);

  switch (resolvedRoute.state) {
    case 'matching': {
      return injectMatchingResolvedRXRoute({
        resolvedRoute,
        routerOutletElement,
        signal,
      });
    }
    case 'not-matching':
      throw createNotAValidPathForThisRouteError();
    case 'redirect':
      NAVIGATION.navigate(resolvedRoute.to);
      break;
      // return resolveAndInjectRXRoutes({
      //   routes,
      //   routerOutletElement,
      //   path: normalizeRoutePath(stringOrURLToString(resolvedRoute.to)),
      //   signal,
      // });
  }
}


export interface ICreateRXRouterOptions {
  routes: IRXRoutesList;
  routerOutletElement?: IRXRouterOutletElement;
}

function createRXRouter(
  {
    routes,
    routerOutletElement = getDocumentBody(),
  }: ICreateRXRouterOptions,
) {
  const controller = new AbortController();
  const signal = controller.signal;

  const resolvableRoutes = genericRoutesListToResolvableRoutesList(routes);

  const update = async () => {
    await resolveAndInjectRXRoutes({
      routes: resolvableRoutes,
      path: getCurrentPath(),
      routerOutletElement,
      signal,
    });
  };

  const getCurrentPath = (): string => {
    const currentPathName: string = getLocation().pathname;
    const baseURIPathName: string = new URL(getBaseURI()).pathname;
    return normalizeRoutePath(
      currentPathName.startsWith(baseURIPathName)
        ? currentPathName.slice(baseURIPathName.length)
        : currentPathName,
    );
  };

  NAVIGATION.change$(update);
  update();
}

async function routerExample1() {
  const routes = [
    {
      path: '/home',
      component: () => {
        return import('./pages/home/home.page.component').then(_ => _.AppHomePageComponent);
      },
    },
    {
      path: '/product/:productId',
      component: () => {
        return import('./pages/product/product.page.component').then(_ => _.AppProductPageComponent);
      },
    },
    {
      path: '/list',
      component: () => {
        return import('./pages/list/list.page.component').then(_ => _.AppListPageComponent);
      },
      children: [
        {
          path: '/',
        },
        {
          path: '/sub',
          component: () => {
            return import('./pages/sub-list//sub-list.page.component').then(_ => _.AppSubListPageComponent);
          },
        },
      ],
    },
    {
      path: '/forbidden',
      canActivate: navigateTo('/home'),
    },
    {
      path: '/**',
      component: () => {
        return import('./pages/404/not-found.page.component').then(_ => _.AppNotFoundPageComponent);
      },
    },
  ];



  createRXRouter({
    routes,
  });
}

// async function routerExample1() {
//   // TODO finish
//   const routes = [
//     createRouteResolver({
//       path: '/home',
//       component: () => {
//         return import('./pages/home/home.page.component').then(_ => _.AppHomePageComponent);
//       },
//     }),
//     createRouteResolver({
//       path: '/product/:productId',
//       component: () => {
//         return import('./pages/product/product.page.component').then(_ => _.AppProductPageComponent);
//       },
//     }),
//     createRouteResolver({
//       path: '/list',
//       component: () => {
//         return import('./pages/list/list.page.component').then(_ => _.AppListPageComponent);
//       },
//       children: [
//         createRouteResolver({
//           path: '/',
//         }),
//         createRouteResolver({
//           path: '/sub',
//           component: () => {
//             return import('./pages/sub-list//sub-list.page.component').then(_ => _.AppSubListPageComponent);
//           },
//         }),
//       ],
//     }),
//     createRouteResolver({
//       path: '/forbidden',
//       canActivate: navigateTo('/home'),
//     }),
//     createRouteResolver({
//       path: '/**',
//       component: () => {
//         return import('./pages/404/not-found.page.component').then(_ => _.AppNotFoundPageComponent);
//       },
//     }),
//   ];
//
//   const resolver = createRoutesResolver(routes);
//
//   let previousUndoFunction: IRouteResolveUndoFunction;
//
//   const DEFAULT_INJECT_PARENT_COMPONENT: IRouteResolveInjectParentComponentFunction = createDefaultInjectParentComponent();
//
//   const update = async () => {
//     try {
//       previousUndoFunction = await resolver({
//         path: getCurrentPath(),
//         params: {},
//         injectParentComponent: DEFAULT_INJECT_PARENT_COMPONENT,
//         previousUndoFunction,
//       });
//     } catch (error: unknown) {
//       if (isRedirectToError(error)) {
//         NAVIGATION.navigate(error.url);
//       } else {
//         throw error;
//       }
//     }
//   };
//
//   const getCurrentPath = (): string => {
//     const currentPathName: string = getLocation().pathname;
//     const baseURIPathName: string = new URL(getBaseURI()).pathname;
//     // getLocation().pathname.replace(new URL(getBaseURI()).pathname, '')
//     return normalizeRoutePath(
//       currentPathName.startsWith(baseURIPathName)
//         ? currentPathName.slice(baseURIPathName.length)
//         : currentPathName
//     );
//   };
//
//   NAVIGATION.onChange(update);
//   update();
// }

/*-----------------*/


export async function routerExample() {
  await routerExample1();
}

