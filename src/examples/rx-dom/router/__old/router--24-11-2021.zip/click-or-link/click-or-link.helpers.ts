import {
  IClickFunction, IClickOrLinkType, IClickType, ILinkType, ILinkTypeEventOptions, IOptionalClickOrLinkType,
  IRouterLinkType,
} from './click-or-link.types';
import { isObject } from '@lifaon/rx-js-light';
import { INavigationNavigateFunction } from '../navigation/navigation';
import { stringOrURLToString } from '@lifaon/rx-dom';

/** CREATE **/

export function clickType(
  onClick: IClickFunction,
  extraOptions?: ILinkTypeEventOptions,
): IClickType {
  return {
    type: 'click',
    onClick,
    ...extraOptions,
  };
}

export function linkType(
  href: string,
  newTab: boolean = false,
  extraOptions?: ILinkTypeEventOptions,
): ILinkType {
  return {
    type: 'link',
    url: href,
    newTab,
    ...extraOptions,
  };
}

export function routerLinkType(
  commands: any[],
  url: string,
  replaceState?: boolean,
  extraOptions?: ILinkTypeEventOptions,
): IRouterLinkType {
  return {
    type: 'router-link',
    url,
    replaceState,
    ...extraOptions,
  };
}

/** IS **/

export function isClickType(
  value: IClickOrLinkType,
): value is IClickType {
  return (value.type === 'click');
}

export function isLinkType(
  value: IClickOrLinkType,
): value is ILinkType {
  return (value.type === 'link');
}

export function isRouterLinkType(
  value: IClickOrLinkType,
): value is IRouterLinkType {
  return (value.type === 'router-link');
}

export function isClickOrLinkType(
  value: unknown,
): value is IClickOrLinkType {
  return isObject(value)
    && (isClickType(value as IClickOrLinkType) || isLinkType(value as IClickOrLinkType) || isRouterLinkType(value as IClickOrLinkType));
}

export function isOptionalClickOrLinkType(
  value: unknown,
): value is IOptionalClickOrLinkType {
  return (value === void 0)
    || isClickOrLinkType(value);
}

/** HELPERS **/

/* TO HREF **/
export function clickToHREF(
  input?: IClickType,
): string {
  return 'javascript:void(0)';
}

export function linkToHREF(
  {
    url,
  }: ILinkType,
): string {
  return stringOrURLToString(url);
}

/**
 * Returns an url (as string) from a routerLinkType
 */
export function routerLinkToHREF(
  {
    url,
  }: IRouterLinkType,
): string {
  return stringOrURLToString(url);
}

/**
 * Returns an url (as string) from a routerLinkType or a clickType (empty)
 */
export function clickOrLinkLinkToHREF(
  value: IClickOrLinkType,
): string {
  return isClickType(value)
    ? clickToHREF(value)
    : (
      isLinkType(value)
        ? linkToHREF(value)
        : routerLinkToHREF(value)
    );
}

/**
 * Returns an url (as string) from a routerLinkType, a clickType (empty) or undefined (empty)
 */
export function optionalClickOrLinkLinkToHREF(
  value: IOptionalClickOrLinkType,
): string {
  return (value === void 0)
    ? ''
    : clickOrLinkLinkToHREF(value);
}


/* TARGET */

/**
 * Returns a 'target' attribute (link) from a clickOrLinkType
 */
export function clickOrLinkLinkToTarget(
  value: IClickOrLinkType,
): string {
  return (isClickType(value) || isRouterLinkType(value))
    ? ''
    : (
      value.newTab
        ? '_blank'
        : '_self'
    );
}

/**
 * Returns a 'target' attribute (link) from a clickOrLinkType or undefined (empty)
 */
export function optionalClickOrLinkLinkToTarget(
  value: IOptionalClickOrLinkType,
): string {
  return (value === void 0)
    ? ''
    : clickOrLinkLinkToTarget(value);
}

/* RESOLVE */

export interface IResolveOnClick {
  clickOrLink: IOptionalClickOrLinkType;
  event: MouseEvent;
  navigate: INavigationNavigateFunction;
}

export function resolveOptionalClickOrLinkLinkOnClick(
  {
    clickOrLink,
    event,
    navigate,
  }: IResolveOnClick,
): void {
  if (clickOrLink !== void 0) {
    const {
      preventDefault = true,
      stopPropagation = true,
      stopImmediatePropagation = true,
    } = clickOrLink;

    if (preventDefault) {
      event.preventDefault();
    }

    if (stopPropagation) {
      event.stopPropagation();
    }

    if (stopImmediatePropagation) {
      event.stopImmediatePropagation();
    }

    if (isClickType(clickOrLink)) {
      clickOrLink.onClick(event);
    } else if (isLinkType(clickOrLink)) {
      navigate(clickOrLink.url, clickOrLink);
    } else {
      navigate(clickOrLink.url, clickOrLink);
    }
  }
}

// export function routerLinkNavigate(
//   value: IRouterLink,
//   router: Router,
// ): Promise<boolean> {
//   return (typeof value === 'string')
//     ? router.navigateByUrl(value)
//     : router.navigate(value);
// }
