import {
  createElementModifier, onNodeConnectedToWithImmediateCached, toObservableThrowIfUndefined,
} from '@lifaon/rx-dom';
import { fromEventTarget, IObservable, IUnsubscribe, noop } from '@lifaon/rx-js-light';
import { IOptionalClickOrLinkType } from './click-or-link.types';
import {
  optionalClickOrLinkLinkToHREF, optionalClickOrLinkLinkToTarget, resolveOptionalClickOrLinkLinkOnClick,
} from './click-or-link.helpers';
import { NAVIGATION } from '../navigation/navigation';


function isHTMLAnchorElement(
  value: unknown,
): value is HTMLAnchorElement{
  return (value instanceof HTMLAnchorElement);
}


export function clickOrLinkModifierFunction<GElement extends HTMLElement>(
  element: GElement,
  clickOrLink: IObservable<IOptionalClickOrLinkType> | IOptionalClickOrLinkType,
): GElement {
  const clickOrLink$ = toObservableThrowIfUndefined(clickOrLink);

  const _isHTMLAnchorElement = isHTMLAnchorElement(element);
  const click$ = fromEventTarget<'click', MouseEvent>(element, 'click');

  let unsubscribeOfClickOrLink: IUnsubscribe = noop;
  let unsubscribeOfClick: IUnsubscribe = noop;

  onNodeConnectedToWithImmediateCached(element)((connected: boolean) => {
    if (connected) {
      unsubscribeOfClickOrLink = clickOrLink$((clickOrLink: IOptionalClickOrLinkType): void => {
        unsubscribeOfClick();

        if (_isHTMLAnchorElement) {
          element.href = optionalClickOrLinkLinkToHREF(clickOrLink);
          element.target = optionalClickOrLinkLinkToTarget(clickOrLink);
        } else {
          unsubscribeOfClick = click$((event: MouseEvent): void => {
            resolveOptionalClickOrLinkLinkOnClick({
              event,
              clickOrLink,
              navigate: NAVIGATION.navigate,
            });
          });
        }
      });
    } else {
      unsubscribeOfClickOrLink();
      unsubscribeOfClick();
    }
  });
  return element;
}


export const CLICK_OR_LINK_MODIFIER = createElementModifier('click-or-link', clickOrLinkModifierFunction);

