import { ILinkTypeEventOptions } from './click-or-link.types';

export const LINK_TYPE_NO_PREVENT: ILinkTypeEventOptions = {
  preventDefault: false,
};

export const LINK_TYPE_NO_STOP_PROPAGATION: ILinkTypeEventOptions = {
  stopImmediatePropagation: false,
  stopPropagation: false,
};

export const LINK_TYPE_NO_PREVENT_AND_NO_STOP_PROPAGATION: ILinkTypeEventOptions = {
  ...LINK_TYPE_NO_PREVENT,
  ...LINK_TYPE_NO_STOP_PROPAGATION,
};
