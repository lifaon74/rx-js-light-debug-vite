import { INavigationNavigateOptions } from '../navigation/navigation';
import { IStringOrURL } from '@lifaon/rx-dom';

/** TYPES **/

export interface ILinkTypeEventOptions {
  preventDefault?: boolean; // default: true
  stopPropagation?: boolean; // default: true
  stopImmediatePropagation?: boolean; // default: true
}



export type IClickFunction = (event: MouseEvent) => void;

export interface IClickType extends ILinkTypeEventOptions {
  type: 'click';
  onClick: IClickFunction;
}

export interface ILinkType extends ILinkTypeEventOptions, Pick<INavigationNavigateOptions, 'target' | 'noopener' | 'noreferrer'>{
  type: 'link';
  url: IStringOrURL;
}

export interface IRouterLinkType extends ILinkTypeEventOptions, INavigationNavigateOptions {
  type: 'router-link';
  url: IStringOrURL;
}

export type IClickOrLinkType = IClickType | ILinkType | IRouterLinkType;
export type IOptionalClickOrLinkType = IClickOrLinkType | undefined;
