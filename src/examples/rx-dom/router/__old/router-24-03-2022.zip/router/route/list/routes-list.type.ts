import { IRoute } from '../route.type';

export type IRoutesList<GExtra> = readonly IRoute<GExtra>[];
