
export interface ILinkTypeEventOptions {
  preventDefault?: boolean; // default: true
  stopPropagation?: boolean; // default: true
  stopImmediatePropagation?: boolean; // default: true
}
