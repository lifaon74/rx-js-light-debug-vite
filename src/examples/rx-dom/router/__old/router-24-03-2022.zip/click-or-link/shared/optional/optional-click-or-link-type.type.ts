import { IClickOrLinkType } from '../click-or-link-type.type';

export type IOptionalClickOrLinkType = IClickOrLinkType | undefined;
