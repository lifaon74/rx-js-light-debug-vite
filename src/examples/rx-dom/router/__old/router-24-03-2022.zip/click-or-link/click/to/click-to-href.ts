import { IClickType } from '../click-type.type';

export function clickToHREF(
  value?: IClickType,
): string {
  return 'javascript:void(0)';
}
