import { IClickType } from '../click-type.type';

export function clickToTarget(
  value?: IClickType,
): string {
  return '';
}
