import {
  compileReactiveCSSAsComponentStyle, compileReactiveHTMLAsGenericComponentTemplate, Component, OnCreate,
} from '@lifaon/rx-dom';
// @ts-ignore
import html from './weather-page.component.html?raw';
// @ts-ignore
import style from './weather-page.component.scss';
import {
  filter$$$, fromGeolocationPosition, fromPromise, function$$, IDefaultNotificationsUnion,
  IFromGeolocationPositionObservableNotifications, IMapFilterDiscard, INextNotification, IObservable, IObserver,
  isErrorNotification,
  isNextNotification, letU$$, map$$, map$$$, MAP_FILTER_DISCARD, mapFilter$$, merge, mergeMapS$$, mergeMapS$$$, pipe$$,
  pipe$$$,
  shareRL$$,
  single, throttleTime$$,
} from '@lifaon/rx-js-light';
import { getReverseNominatimCached } from '../../api/get-reverse-nominatim/get-reverse-nominatim';
import { IGetReverseNominatimJSONResponse } from '../../api/get-reverse-nominatim/response.type';
import { Immutable, ImmutableArray } from '@lifaon/rx-store';
import { generateWeatherImage, IWeatherData } from '../../helpers/generate-weather-image/generate-weather-image';
import { kelvinToCelsius, MM_PER_DAY_TO_METER_PER_SECOND, MS_PER_DAY } from '../../helpers/units/converters';
import {
  dateTimeFormat$$$, ILocaleToTranslations, IRelativeTimeFormatValue, ITranslations, LOCALES, numberFormat$$$,
  relativeTimeFormat$$$,
} from '@lifaon/rx-i18n';
import { IGeographicPosition } from '../../api/shared/geographic-position';
import { getWeather } from '../../api/get-weather/get-weather';
import { IDailyWeather, IGetWeatherResponse, IHourlyWeather } from '../../api/get-weather/response.type';
import { getWeatherDescriptionFromId } from '../../api/get-weather/weather-state-id/get-weather-description-from-id';

/** CONSTANTS **/

const locales$ = LOCALES.subscribe;

const TRANSLATIONS: ILocaleToTranslations = new Map<string, ITranslations>([
  ['en', new Map([
    ['translate.uvi', 'UV Indice'],
    ['translate.humidity', 'Humidity'],
    ['translate.clouds', 'Clouds'],
    ['translate.wind', 'Wind'],
  ])],
]);

/** FUNCTIONS **/

// https://github.com/bennymeier/react-weather-app/blob/master/src/App.js
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/NumberFormat/NumberFormat

function capitalizeFirstLetter(value: string): string {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function getWeatherStartDate(
  dt: number,
): number {
  const date = new Date(dt * 1000);
  return new Date(
    date.getFullYear(),
    date.getMonth(),
    date.getDate(),
  ).getTime();
}

function getWeatherEndDate(
  dt: number,
): number {
  const date = new Date(dt * 1000);
  return new Date(
    date.getFullYear(),
    date.getMonth(),
    date.getDate() + 1,
  ).getTime();
}


function getWeatherImageURL(
  weather: IWeatherData,
): IObservable<string> {
  return pipe$$(fromPromise<HTMLCanvasElement>(generateWeatherImage(weather, 120)), [
    filter$$$<IDefaultNotificationsUnion<HTMLCanvasElement>, INextNotification<HTMLCanvasElement>>(isNextNotification),
    map$$$<INextNotification<HTMLCanvasElement>, string>((notification: INextNotification<HTMLCanvasElement>) => {
      return `url(${ notification.value.toDataURL() })`;
    }),
  ])
}


/** FORMAT **/

const formatRelativeDay$$$ = pipe$$$([
  relativeTimeFormat$$$(single('days'), locales$, single({
    numeric: 'auto',
    style: 'long',
  })),
  map$$$<string, string>(capitalizeFirstLetter),
]);

const formatWeekDay$$$ = dateTimeFormat$$$(locales$, single({
  weekday: 'long',
}));

const formatDay$$$ = mergeMapS$$$<number, string>((timestamp: number): IObservable<string> => {
  const days: number = Math.floor((timestamp - Date.now()) / MS_PER_DAY);
  if (days <= 1) {
    return pipe$$(single<IRelativeTimeFormatValue>(days), [
      formatRelativeDay$$$,
    ]);
  } else {
    return pipe$$(single<number>(timestamp), [
      formatWeekDay$$$,
    ]);
  }
});

const formatDate$$$ = dateTimeFormat$$$(locales$, single({
  month: 'short', day: 'numeric',
}));

const formatPercent$$$ = numberFormat$$$(locales$, single({
  style: 'percent',
}));

const formatPrecipitation$$$ = numberFormat$$$(locales$, single({
  style: 'unit',
  unit: 'millimeter',
  unitDisplay: 'narrow',
  maximumFractionDigits: 1,
}));

const formatDailyPrecipitation$$$ = pipe$$$([
  map$$$<number, number>((value: number) => (value / MM_PER_DAY_TO_METER_PER_SECOND)),
  formatPrecipitation$$$,
]);

const formatTemperature$$$ = pipe$$$([
  map$$$<number, number>(kelvinToCelsius),
  numberFormat$$$(locales$, single({
    style: 'unit',
    unit: 'celsius',
    unitDisplay: 'narrow',
    maximumFractionDigits: 0,
  })),
]);


const formatHour$$$ = dateTimeFormat$$$(locales$, single({
  hour: 'numeric', minute: 'numeric',
}));

/** COMPONENT **/

type IDailyState = Immutable<{
  timestamp: number;
  // data
  day$: IObservable<string>;
  date$: IObservable<string>;
  illustration$: IObservable<string>;
  weatherTitle$: IObservable<string>;
  // probabilityOfPrecipitation$: IObservable<string>;
  precipitation$: IObservable<string>;
  minTemperature$: IObservable<string>;
  maxTemperature$: IObservable<string>;
}>;

type IHourlyState = Immutable<{
  hour$: IObservable<string>;
}>;

type IData = Immutable<{
  // data
  place$: IObservable<string>;
  dailyForecast$: IObservable<ImmutableArray<IDailyState>>;

  // selectedDailyForecast$: IObservable<IDailyState>;
  // // hourly$: IObservable<ImmutableArray<IHourlyState>>;

  // events
  onClickGranularity: IObserver<IDailyState>;
  onClickDailyForecast: IObserver<IDailyState>;

  // others
  isDailyForecastSelected$$: (dailyForecast: IDailyState) => IObservable<boolean>;

}>;

const APP_WEATHER_PAGE_CUSTOM_ELEMENTS = [
  // AppWeatherIconComponent,
];

@Component({
  name: 'app-weather-page',
  template: compileReactiveHTMLAsGenericComponentTemplate({
    html,
  }),
  styles: [compileReactiveCSSAsComponentStyle(style)],
})
export class AppWeatherPageComponent extends HTMLElement implements OnCreate<IData> {

  protected readonly _data: IData;

  constructor() {
    super();

    /* POSITION */

    const geolocationPosition$ = shareRL$$(throttleTime$$(fromGeolocationPosition(), 60000));

    const position$ = mapFilter$$(geolocationPosition$, (notification: IFromGeolocationPositionObservableNotifications): IGeographicPosition | IMapFilterDiscard => {
      return isNextNotification(notification)
        ? {
          latitude: notification.value.coords.latitude,
          longitude: notification.value.coords.longitude,
        }
        : MAP_FILTER_DISCARD;
    });

    const positionError$ = mapFilter$$(geolocationPosition$, (notification: IFromGeolocationPositionObservableNotifications): string | IMapFilterDiscard => {
      return isErrorNotification(notification)
        ? `error.position`
        : MAP_FILTER_DISCARD;
    });


    /* PLACE */

    const reverseNominatimRequest$ = shareRL$$(mergeMapS$$(position$, getReverseNominatimCached));

    const reverseNominatimData$ = mapFilter$$(reverseNominatimRequest$, (notification: IDefaultNotificationsUnion<IGetReverseNominatimJSONResponse>): IGetReverseNominatimJSONResponse | IMapFilterDiscard => {
      return isNextNotification(notification)
        ? notification.value
        : MAP_FILTER_DISCARD;
    });

    const reverseNominatimDataError$ = mapFilter$$(reverseNominatimRequest$, (notification: IDefaultNotificationsUnion<IGetReverseNominatimJSONResponse>): string | IMapFilterDiscard => {
      return isErrorNotification(notification)
        ? `error.reverse-nominatim-request`
        : MAP_FILTER_DISCARD;
    });

    const place$ = map$$(reverseNominatimData$, (reverseNominatimData: IGetReverseNominatimJSONResponse): string => {
      return `${ reverseNominatimData.address.town } (${ reverseNominatimData.address.country })`;
    });

    /* WEATHER */

    const weatherRequest$ = shareRL$$(mergeMapS$$(position$, getWeather));

    const weatherData$ = mapFilter$$(weatherRequest$, (notification: IDefaultNotificationsUnion<IGetWeatherResponse>): IGetWeatherResponse | IMapFilterDiscard => {
      return isNextNotification(notification)
        ? notification.value
        : MAP_FILTER_DISCARD;
    });

    const weatherDataError$ = mapFilter$$(weatherRequest$, (notification: IDefaultNotificationsUnion<IGetWeatherResponse>): string | IMapFilterDiscard => {
      return isErrorNotification(notification)
        ? `error.weather-request`
        : MAP_FILTER_DISCARD;
    });


    /* DAILY FORECAST */

    const dailyForecast$ = map$$(weatherData$, (weatherData: IGetWeatherResponse): ImmutableArray<IDailyState> => {
      return weatherData.daily.map((dailyData: IDailyWeather): IDailyState => {
        const timestamp = dailyData.date;
        const timestamp$ = single(timestamp);

        const day$ = formatDay$$$(timestamp$);
        const date$ = formatDate$$$(timestamp$);

        // const illustration$ = single(`url(${ getWeatherImageURL(dailyData.weather[0].icon) }`);
        // const illustration$ = single(`url(${ getWeatherImageURLFromId(dailyData.state[0], false, false) }`);
        const illustration$ = getWeatherImageURL(dailyData);

        const weatherTitle$ = single(getWeatherDescriptionFromId(dailyData.state[0]));

        // const probabilityOfPrecipitation$ = formatPercent$$$(single<number>(dailyData.pop));

        const precipitation$ = ((dailyData.rain === void 0) || (dailyData.rain === 0))
          ? single('')
          : formatDailyPrecipitation$$$(single<number>(dailyData.rain));

        const minTemperature$ = formatTemperature$$$(single<number>(dailyData.temperature.min));

        const maxTemperature$ = formatTemperature$$$(single<number>(dailyData.temperature.max));

        return {
          timestamp,
          day$,
          date$,
          illustration$,
          weatherTitle$,
          // probabilityOfPrecipitation$,
          precipitation$,
          minTemperature$,
          maxTemperature$,
        };
      });
    });

    /* SELECTED DAILY FORECAST */

    const { emit: $selectedDailyForecast, subscribe: selectedDailyForecast$ } = letU$$<IDailyState>();

    const isDailyForecastSelected$$ = (dailyForecast: IDailyState): IObservable<boolean> => {
      return map$$(selectedDailyForecast$, (selectedDailyForecast: IDailyState) => (selectedDailyForecast === dailyForecast));
    };

    const onClickDailyForecast = $selectedDailyForecast;


    /* HOURLY FORECAST */

    const hourlyForecast$ = function$$([
      weatherData$,
      selectedDailyForecast$,
    ], (
      weatherData: IGetWeatherResponse,
      selectedDailyForecast: IDailyState,
    ): ImmutableArray<IHourlyState> => {
      const dailyForecastTimestamp: number = selectedDailyForecast.timestamp;
      const dailyForecastTimestampEnd: number = dailyForecastTimestamp + MS_PER_DAY;

      return weatherData.hourly
        .filter((hourlyData: IHourlyWeather): boolean => {
          return (dailyForecastTimestamp <= hourlyData.date)
            && (hourlyData.date < dailyForecastTimestampEnd);
        })
        .map((hourlyData: IHourlyWeather): IHourlyState => {
          const hour$ = formatHour$$$(single(hourlyData.date));
          return {
            hour$,
          };
        });
    });


    /* ERROR */

    const error$ = merge([
      positionError$,
      reverseNominatimDataError$,
      weatherDataError$,
    ]);

    this._data = {
      place$,
      dailyForecast$,
      // selectedDailyForecast$,
      // // hourly$,
      onClickDailyForecast,
      isDailyForecastSelected$$,
    };
  }

  public onCreate(): IData {
    return this._data;
  }
}

