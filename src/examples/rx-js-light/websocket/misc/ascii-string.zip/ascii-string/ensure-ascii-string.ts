import { isASCIIString } from './is-ascii-string';

export function ensureASCIIString(
  value: string,
): void {
  if (!isASCIIString(value)) {
    throw new Error(`Not an ASCII string`);
  }
}

