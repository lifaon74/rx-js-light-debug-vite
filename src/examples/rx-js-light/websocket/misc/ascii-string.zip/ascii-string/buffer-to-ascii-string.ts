import { IASCIIString } from './ascii-string.type';


export function bufferToASCIIString(
  input: Uint8Array, // assumes buffer is an ascii string
): IASCIIString {
  return String.fromCharCode.apply(null, input);
}

