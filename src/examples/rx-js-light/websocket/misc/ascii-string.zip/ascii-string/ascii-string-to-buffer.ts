import { IASCIIString } from './ascii-string.type';
import { u8 } from '@lifaon/number-types';


export function asciiStringToBuffer(
  input: IASCIIString,
): Uint8Array {
  const chars: Uint8Array = new Uint8Array(input.length);

  for (let i = 0, l = input.length; i < l; i++) {
    const byte: u8 = input.charCodeAt(i);
    if (byte >= 0x80) {
      throw new Error(`Not an ASCII string`);
    } else {
      chars[i] = byte;
    }
  }

  return chars;
}

