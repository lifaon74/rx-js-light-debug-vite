export type IASCIIString = string;
