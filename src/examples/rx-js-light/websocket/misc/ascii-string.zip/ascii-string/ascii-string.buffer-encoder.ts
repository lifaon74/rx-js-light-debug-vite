import { IASCIIString } from './ascii-string.type';
import { u32 } from '@lifaon/number-types';
import { ensureUint8ArrayHasEnoughSpace } from '../../array-buffer/ensure-uint8-array-has-enough-space';


export function asciiStringBufferEncoder(
  input: IASCIIString,
  buffer: Uint8Array,
  index: u32,
): u32 {
  const length: u32 = input.length;

  ensureUint8ArrayHasEnoughSpace(
    buffer,
    index,
    input.length,
  );

  for (let i = 0; i < length; i++) {
    buffer[index++] = input.charCodeAt(0);
  }

  return index;
}

