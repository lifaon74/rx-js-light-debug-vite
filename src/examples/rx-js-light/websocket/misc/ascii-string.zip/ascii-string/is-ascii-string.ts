import { IASCIIString } from './ascii-string.type';

export function isASCIIString(
  value: string,
): value is IASCIIString {
  for (let i = 0, l = value.length; i < l; i++) {
    if (value.charCodeAt(i) >= 0x80) {
      return false;
    }
  }
  return true;
}
