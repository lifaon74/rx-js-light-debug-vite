import { ASCIIString } from '../../../../../../classes/ascii-string/ascii-string.class';

export const MULTIPART_ALTERNATIVE = ASCIIString.fromSafeString('alternative');
