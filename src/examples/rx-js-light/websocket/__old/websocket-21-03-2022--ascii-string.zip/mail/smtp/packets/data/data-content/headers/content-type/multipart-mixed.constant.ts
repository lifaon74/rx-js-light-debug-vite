import { ASCIIString } from '../../../../../../classes/ascii-string/ascii-string.class';

export const MULTIPART_MIXED = ASCIIString.fromSafeString('mixed');

