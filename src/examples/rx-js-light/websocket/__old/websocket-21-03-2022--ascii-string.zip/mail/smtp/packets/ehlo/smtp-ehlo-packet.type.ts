import { Domain } from '../../../classes/domain/domain.class';

export interface ISMTP$EHLO$Packet {
  domain: Domain;
}
