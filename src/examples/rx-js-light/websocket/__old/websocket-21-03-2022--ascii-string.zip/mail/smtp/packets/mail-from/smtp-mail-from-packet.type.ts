import { EmailAddress } from '../../../classes/email-address/email-address.class';

export interface ISMTP$MAIL_FROM$Packet {
  from: EmailAddress;
}


