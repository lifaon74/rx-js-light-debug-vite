import { ASCIIString } from '../../../../classes/ascii-string/ascii-string.class';


export interface ISMTP$DATA_OK_RSP$Packet {
  text: ASCIIString;
}

