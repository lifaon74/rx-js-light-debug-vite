
headers: https://www.ietf.org/rfc/rfc2822.txt
body: https://www.ietf.org/rfc/rfc2045.txt
https://stackoverflow.com/questions/3902455/mail-multipart-alternative-vs-multipart-mixed
