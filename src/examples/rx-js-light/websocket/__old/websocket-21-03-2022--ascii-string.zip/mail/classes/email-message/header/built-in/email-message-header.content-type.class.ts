import { EmailMessageHeader } from '../email-message-header.class';
import { ensureASCIIString } from '../../../../../misc/ascii-string/ensure-ascii-string';
import { u32 } from '@lifaon/number-types';
import { asciiStringBufferEncoder } from '../../../../../misc/ascii-string/ascii-string.buffer-encoder';
import { ensureUint8ArrayHasEnoughSpace } from '../../../../../array-buffer/ensure-uint8-array-has-enough-space';
import { CHAR_COLON } from '../../../../../chars/colon.constant';
import { CHAR_SPACE } from '../../../../../chars/space.constant';
import { IASCIIString } from '../../../../../misc/ascii-string/ascii-string.type';


export class EmailMessageHeaderGeneric extends EmailMessageHeader {
  readonly key: IASCIIString;
  readonly value: IASCIIString;

  constructor(
    key: string,
    value: string,
  ) {
    super();
    ensureASCIIString(key);
    ensureASCIIString(value);
    this.key = key.trim();
    this.value = value.trim();
  }

  override encodeInBuffer(
    buffer: Uint8Array,
    index: u32,
  ): u32 {
    index = asciiStringBufferEncoder(
      this.key,
      buffer,
      index,
    );

    ensureUint8ArrayHasEnoughSpace(
      buffer,
      index,
      2,
    );

    buffer[index++] = CHAR_COLON;
    buffer[index++] = CHAR_SPACE;

    index = asciiStringBufferEncoder(
      this.value,
      buffer,
      index,
    );

    return index;
  }
}



