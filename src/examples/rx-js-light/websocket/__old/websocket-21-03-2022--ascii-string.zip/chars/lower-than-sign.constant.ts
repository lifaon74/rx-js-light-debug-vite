export const CHAR_LOWER_THAN = 0x3c; // '<'

