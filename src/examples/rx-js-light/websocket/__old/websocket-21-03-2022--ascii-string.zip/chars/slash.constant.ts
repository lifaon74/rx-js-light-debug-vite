export const CHAR_SLASH = 0x2f; // '/'

