export const CHAR_BACKSLASH = 0x5c; // '\\'

