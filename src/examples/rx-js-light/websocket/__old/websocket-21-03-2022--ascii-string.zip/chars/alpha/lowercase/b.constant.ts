export const CHAR_b = 0x62; // 'b'

