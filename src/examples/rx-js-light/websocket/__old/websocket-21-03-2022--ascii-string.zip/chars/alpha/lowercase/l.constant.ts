export const CHAR_l = 0x6c; // 'l'

