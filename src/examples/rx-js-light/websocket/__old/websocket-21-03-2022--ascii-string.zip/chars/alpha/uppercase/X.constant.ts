export const CHAR_X = 0x58; // 'X'

