export const CHAR_c = 0x63; // 'c'

