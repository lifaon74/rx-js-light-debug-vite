export const CHAR_S = 0x53; // 'S'

