export const CHAR_Q = 0x51; // 'Q'

