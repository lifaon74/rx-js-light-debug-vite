export const CHAR_D = 0x44; // 'D'

