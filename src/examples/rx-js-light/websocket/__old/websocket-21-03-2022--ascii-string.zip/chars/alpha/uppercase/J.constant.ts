export const CHAR_J = 0x4a; // 'J'

