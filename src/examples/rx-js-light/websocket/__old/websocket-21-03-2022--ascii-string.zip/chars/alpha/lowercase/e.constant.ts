export const CHAR_e = 0x65; // 'e'

