export const CHAR_t = 0x74; // 't'

