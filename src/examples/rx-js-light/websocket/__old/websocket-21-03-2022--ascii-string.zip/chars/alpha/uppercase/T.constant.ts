export const CHAR_T = 0x54; // 'T'

