export const CHAR_m = 0x6d; // 'm'

