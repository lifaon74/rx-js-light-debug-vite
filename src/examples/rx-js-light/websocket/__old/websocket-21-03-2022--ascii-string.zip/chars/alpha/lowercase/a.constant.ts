export const CHAR_a = 0x61; // 'a'

