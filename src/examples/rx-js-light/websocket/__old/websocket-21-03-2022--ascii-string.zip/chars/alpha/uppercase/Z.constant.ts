export const CHAR_Z = 0x5a; // 'Z'

