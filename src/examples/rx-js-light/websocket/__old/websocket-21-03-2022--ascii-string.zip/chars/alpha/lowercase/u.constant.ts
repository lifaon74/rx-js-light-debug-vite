export const CHAR_u = 0x75; // 'u'

