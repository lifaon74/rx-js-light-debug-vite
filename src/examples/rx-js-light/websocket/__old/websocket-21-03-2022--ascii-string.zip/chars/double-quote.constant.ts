export const CHAR_DOUBLE_QUOTE = 0x22; // '"'

