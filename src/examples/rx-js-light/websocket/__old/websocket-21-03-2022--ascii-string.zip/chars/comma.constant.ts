export const CHAR_COMMA = 0x2c; // ','

