export const CHAR_7 = 0x37; // '7'

