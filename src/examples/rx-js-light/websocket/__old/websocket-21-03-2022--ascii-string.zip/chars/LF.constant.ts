export const CHAR_LF = 0x0a; // '\n'

