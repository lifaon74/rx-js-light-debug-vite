export const CHAR_SEMICOLON = 0x3b; // ';'

