export const CHAR_DOT = 0x2e; // 'e'

