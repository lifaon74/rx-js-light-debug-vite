import {
  $$map, createDeferredPromise, IDeferredPromise, IObservable, map$$, noop, notificationObserver, share$$,
} from '@lifaon/rx-js-light';
import {
  createWebSocketByteStream, IWebSocketByteStreamObservable,
} from './stream/websocket/derived/byte-stream/create-websocket-byte-stream';
import { IByteStream } from './stream/byte-stream/byte-stream.type';
import { SMTP_CONFIG } from './mail/smtp/config.constant';
import { encodeInGrowableBuffer } from './encoding/helpers/encode-in-buffer';
import { encodeSMTP$EHLO$Packet } from './mail/smtp/packets/ehlo/encode-smtp-ehlo-packet';
import { stringToUTF8EncodedString } from './string/string-to-utf8-encoded-string';
import { decodeSMTP$GREETING$Packet } from './mail/smtp/packets/greeting/decode-smtp-greating-packet';
import { IByteStreamObservable } from './stream/byte-stream/byte-stream-observable.type';
import { IDecoder } from './encoding/types/decoder.type';
import { ISMTP$GREETING$Packet } from './mail/smtp/packets/greeting/smtp-greating-packet.type';
import { decodeSMTP$EHLO_OK_RSP$Packet } from './mail/smtp/packets/ehlo/ehlo-ok-rsp/decode-smtp-ehlo-ok-rsp-packet';
import { ISMTP$EHLO_OK_RSP$Packet } from './mail/smtp/packets/ehlo/ehlo-ok-rsp/smtp-ehlo-ok-rsp-packet.type';
import { utf8EncodedStringToString } from './string/utf8-encoded-string-to-string';
import { encodeUint8ArrayToBase64 } from './array-buffer/encode-uint8-array-to-base64';
import { decodeUint8ArrayFromBase64 } from './array-buffer/decode-uint8-array-from-base64';
import { uint8ArrayToBinaryString } from './string/uint8-array-to-binary-string';
import { binaryStringToUint8Array } from './string/binary-string-to-uint8-array';
import {
  decodeSMTP$AUTH_LOGIN_USERNAME_CHALLENGE$Packet,
} from './mail/smtp/packets/auth/login/auth-login-username-challenge/decode-smtp-auth-login-username-challenge-packet';
import {
  encodeSMTP$AUTH_LOGIN_USERNAME_RESPONSE$Packet,
} from './mail/smtp/packets/auth/login/auth-login-username-response/encode-smtp-auth-login-username-response-packet';
import { encodeSMTP$AUTH_LOGIN$Packet } from './mail/smtp/packets/auth/login/auth-login/encode-smtp-auth-packet';
import {
  decodeSMTP$AUTH_LOGIN_PASSWORD_CHALLENGE$Packet,
} from './mail/smtp/packets/auth/login/auth-login-password-challenge/decode-smtp-auth-login-password-challenge-packet';
import {
  encodeSMTP$AUTH_LOGIN_PASSWORD_RESPONSE$Packet,
} from './mail/smtp/packets/auth/login/auth-login-password-response/encode-smtp-auth-login-password-response-packet';
import { decodeSMTP$AUTH_OK_RSP$Packet } from './mail/smtp/packets/auth/auth-ok-rsp/decode-smtp-auth-ok-rsp-packet';
import { ISMTP$AUTH_OK_RSP$Packet } from './mail/smtp/packets/auth/auth-ok-rsp/smtp-auth-ok-rsp-packet.type';
import { encodeSMTP$MAIL_FROM$Packet } from './mail/smtp/packets/mail-from/encode-smtp-mail-from-packet';
import { decodeSMTP$OK_RSP$Packet } from './mail/smtp/packets/ok-rsp/decode-smtp-ok-rsp-packet';
import { ISMTP$OK_RSP$Packet } from './mail/smtp/packets/ok-rsp/smtp-ok-rsp-packet.type';
import { encodeSMTP$RCPT_TO$Packet } from './mail/smtp/packets/rcpt-to/encode-smtp-rcpt-to-packet';
import { encodeSMTP$DATA$Packet } from './mail/smtp/packets/data/encode-smtp-data-packet';
import { decodeSMTP$DATA_OK_RSP$Packet } from './mail/smtp/packets/data/data-ok-rsp/decode-smtp-data-ok-rsp-packet';
import { ISMTP$DATA_OK_RSP$Packet } from './mail/smtp/packets/data/data-ok-rsp/smtp-data-ok-rsp-packet.type';
import { encodeSMTP$DATA_CONTENT$Packet } from './mail/smtp/packets/data/data-content/encode-smtp-data-content-packet';
import { IEmailAddressString } from './mail/types/email-address-string/email-address-string.type';
import { createSMTPDataContentString } from './mail/smtp/packets/data/data-content/forge/forge-smtp-data-content';
import { fetchJSON } from '../../rx-dom/audio-player/api/helpers/fetch-json';

// https://github.com/ricea/websocketstream-explainer/blob/master/README.md


export interface IConnectTLSOptions {
  port: number;
  hostname: string;
  caCerts?: string[];
}

interface ISendConfig {
  to: string;
  from: string;
  subject: string;
  content: string;
  html?: string;
}

interface ICommand {
  code: number;
  args: string;
}


/*----------------------------------*/

function createRawSocketByteStream(
  options: IConnectTLSOptions,
): IWebSocketByteStreamObservable {
  const url = new URL(`ws://localhost:8081`);
  url.searchParams.set('config', JSON.stringify(options));

  return createWebSocketByteStream(url.href);
}

function decodeUint8ArrayObservable<GValue>(
  subscribe: IObservable<Uint8Array>,
  decoder: IDecoder<GValue>,
): Promise<GValue> {
  return new Promise<GValue>((
    resolve: (value: GValue) => void,
    reject: (reason: any) => void,
  ): void => {
    decoder.next();

    subscribe((data: Uint8Array): void => {
      for (let i = 0, l = data.length; i < l; i++) {
        try {
          const result: IteratorResult<void, GValue> = decoder.next(data[i]);
          if (result.done) {
            if (i < (l - 1)) {
              reject(new Error(`More data that the decoder can handle: ${utf8EncodedStringToString(data.subarray(i))}`));
            } else {
              resolve(result.value);
            }
          }
        } catch (error: unknown) {
          reject(error);
        }
      }
    });
  });
}

/*----------------------------------*/

function websocketExample0() {
  const url = `wss://demo.piesocket.com/v3/channel_1?api_key=oCdCMcMPQpbvNjUIzqtvF1d2X2okWpDQj4AwARJuAgtjhzKxVEjQU6IdCjwm&notify_self`;

  const stream$ = createWebSocketByteStream(url);

  stream$(notificationObserver({
    open: ({ emit, subscribe }: IByteStream) => {
      console.warn('websocket opened');

      const $output = $$map<string, Uint8Array>(emit, _ => new TextEncoder().encode(_));
      const input$ = map$$<ArrayBuffer, string>(subscribe, _ => new TextDecoder().decode(_));

      input$((data: string) => {
        console.log(`Receive: ${data}`);
      });

      window.onclick = () => {
        $output(`Message ${Math.floor(Math.random() * 1e3)}`);
      };
    },
    closed: (event: CloseEvent) => {
      console.warn('websocket closed', event);
    },
    error: (error: unknown) => {
      console.warn('websocket error', error);
    },
  }));
}

function websocketExample1() {
  // const url = `wss://demo.piesocket.com/v3/channel_1?api_key=oCdCMcMPQpbvNjUIzqtvF1d2X2okWpDQj4AwARJuAgtjhzKxVEjQU6IdCjwm&notify_self`;

  const config = SMTP_CONFIG;

  const stream$ = createRawSocketByteStream({
    hostname: config.hostname,
    port: config.port,
  });

  stream$(notificationObserver({
    open: async (stream: IByteStream) => {

      let deferredReadPromise: IDeferredPromise<void> | null = null;
      let readPromise: Promise<ICommand> = Promise.resolve(void 0 as any);

      const readCommand = (): Promise<ICommand> => {
        return readPromise = readPromise.then((): ICommand | Promise<ICommand> => {
          if (commands.length > 0) {
            return commands.shift() as ICommand;
          } else {
            console.log('defer');
            deferredReadPromise = createDeferredPromise();
            return deferredReadPromise.promise
              .then(() => {
                console.log('defered resolved');
                return readCommand();
              });
          }
        });
      };

      const assertCode = (
        _code: number,
      ): Promise<void> => {
        return readCommand()
          .then(({ code, args }: ICommand) => {
            if (_code !== code) {
              throw new Error(`${code}: ${args}`);
            }
          });
      };

      const writeCommands = (
        ...commands: string[]
      ): void => {
        stream.emit(new TextEncoder().encode(commands.join(' ') + '\r\n'));
      };

      const parseAddress = (email: string): [string, string] => {
        const m = email.toString().match(/(.*)\s<(.*)>/);
        console.log(m);
        return m?.length === 3
          ? [`<${m[2]}>`, email]
          : [`<${email}>`, `<${email}>`];
      };

      const send = async (
        {
          to,
          from,
          subject,
          content,
          html,
        }: ISendConfig,
      ) => {
        const [_from, fromData] = parseAddress(from);
        const [_to, toData] = parseAddress(to);

        console.log(_from, fromData);
        console.log(_to, toData);

        writeCommands('MAIL', 'FROM:', _from);
        await assertCode(250);
        writeCommands('MAIL', 'TO:', _to);
        await assertCode(250);
        writeCommands('DATA');
        await assertCode(354);

        writeCommands('Subject: ', subject);
        writeCommands('From: ', fromData);
        writeCommands('To: ', toData);
        writeCommands('Date: ', new Date().toString());

        if (html) {
          writeCommands('Content-Type: multipart/alternative; boundary=AlternativeBoundary', '\r\n');
          writeCommands('--AlternativeBoundary');
          writeCommands('Content-Type: text/plain; charset="utf-8"', '\r\n');
          writeCommands(content, '\r\n');
          writeCommands('--AlternativeBoundary');
          writeCommands('Content-Type: text/html; charset="utf-8"', '\r\n');
          writeCommands(html, '\r\n.\r\n');
        } else {
          writeCommands('MIME-Version: 1.0');
          writeCommands('Content-Type: text/html;charset=utf-8');
          writeCommands(`Content-Transfer-Encoding: ${'quoted-printable'}` + '\r\n');
          writeCommands(content, '\r\n.\r\n');
        }

        // this.assertCode(await this.readCmd(), CommandCode.OK);
      };

      const commands: ICommand[] = [];
      let previousText: string = '';

      stream.subscribe((buffer: ArrayBuffer) => {
        const data = new Uint8Array(buffer);
        const text: string = previousText + new TextDecoder().decode(data);

        const lines: string[] = text.split(/\r?\n/g);
        previousText = lines[lines.length - 1];
        commands.push(
          ...lines.slice(0, -1).map((line: string): ICommand => {
            const code: number = parseInt(line.slice(0, 3).trim());
            const args: string = line.slice(3).trim();
            return {
              code,
              args,
            };
          }),
        );

        if (deferredReadPromise !== null) {
          deferredReadPromise.resolve();
        }
      });


      // writeCommands('EHLO', config.hostname);
      //
      // while (true) {
      //   const cmd = await readCommand();
      //   console.log('cmd');
      //   if (!cmd || !cmd.args.startsWith('-')) break;
      // }
      //
      // console.log('ready');
      //
      // writeCommands('AUTH', 'LOGIN');
      // console.log('readCommand', await readCommand());
      // await assertCode(334);
      //
      // writeCommands(btoa(config.username));
      // await assertCode(334);
      //
      // writeCommands(btoa(config.password));
      // await assertCode(235);

      (window as any).send = () => {
        send({
          from: 'valentin.richard <valentin.richard@infomaniak.com>',
          to: 'valentin.richard <valentin.richard@infomaniak.com>',
          subject: 'my subject',
          content: 'hello world',
        });
      };
    },
    closed: (event: CloseEvent) => {
      console.warn('socket closed', event);
    },
    error: (error: unknown) => {
      console.warn('socket error', error);
    },
  }));
}


interface ICreateSMTPClientFromByteStreamOptions {
  stream$: IByteStreamObservable;
  hostname: string;
  username: string;
  password: string;
}

interface ISMTPClientSendOptions {
  from?: IEmailAddressString;
  to: IEmailAddressString;
  content: string;
}

interface ISMTPClientSendFunction {
  (
    options: ISMTPClientSendOptions,
  ): Promise<void>;
}


interface ISMTPClient {
  send: ISMTPClientSendFunction;
}


function createSMTPClientFromByteStream(
  {
    stream$,
    hostname,
    username,
    password,
  }: ICreateSMTPClientFromByteStreamOptions,
): Promise<ISMTPClient> {
  return new Promise<ISMTPClient>((
    resolve: (value: Promise<ISMTPClient>) => void,
    reject: (reason: any) => void,
  ): void => {
    const onOpen = (stream: IByteStream): void => {
      const input$ = share$$(map$$(stream.subscribe, (buffer: ArrayBuffer) => new Uint8Array(buffer)));
      const $output = stream.emit;
      const $outputEncoder = $$map($output, encodeInGrowableBuffer);

      const decode = <GValue>(
        decoder: IDecoder<GValue>,
      ): Promise<GValue> => {
        return decodeUint8ArrayObservable<GValue>(input$, decoder);
      };

      input$((data: Uint8Array) => {
        // console.log(data);
        const text: string = new TextDecoder().decode(data);
        console.log(text);
      });


      /* PRIVATE */

      // greeting
      const awaitGreeting = (): Promise<ISMTP$GREETING$Packet> => {
        return decode<ISMTP$GREETING$Packet>(decodeSMTP$GREETING$Packet());
      };

      // EHLO
      const send$EHLO$ = (): void => {
        $outputEncoder(encodeSMTP$EHLO$Packet({ hostname: stringToUTF8EncodedString(hostname) }));
      };

      const sendAndAwait$EHLO$ = (): Promise<ISMTP$EHLO_OK_RSP$Packet> => {
        send$EHLO$();
        return decode<ISMTP$EHLO_OK_RSP$Packet>(decodeSMTP$EHLO_OK_RSP$Packet());
      };

      // AUTH LOGIN
      const send$AUTH_LOGIN$ = (): void => {
        $outputEncoder(encodeSMTP$AUTH_LOGIN$Packet());
      };

      const send$AUTH_LOGIN_USERNAME$ = (): void => {
        $outputEncoder(encodeSMTP$AUTH_LOGIN_USERNAME_RESPONSE$Packet({ username: stringToUTF8EncodedString(username) }));
      };

      const send$AUTH_LOGIN_PASSWORD$ = (): void => {
        $outputEncoder(encodeSMTP$AUTH_LOGIN_PASSWORD_RESPONSE$Packet({ password: stringToUTF8EncodedString(password) }));
      };

      const sendAndAwait$AUTH_LOGIN$ = (): Promise<ISMTP$AUTH_OK_RSP$Packet> => {
        send$AUTH_LOGIN$();
        return decode<void>(decodeSMTP$AUTH_LOGIN_USERNAME_CHALLENGE$Packet())
          .then(() => {
            send$AUTH_LOGIN_USERNAME$();
            return decode<void>(decodeSMTP$AUTH_LOGIN_PASSWORD_CHALLENGE$Packet());
          })
          .then(() => {
            send$AUTH_LOGIN_PASSWORD$();
            return decode<ISMTP$AUTH_OK_RSP$Packet>(decodeSMTP$AUTH_OK_RSP$Packet());
          });
      };

      const performAuth = (): Promise<ISMTP$AUTH_OK_RSP$Packet> => {
        return sendAndAwait$AUTH_LOGIN$();
      };


      // --> SEND

      // MAIL
      const send$MAIL_FROM$ = (
        from: string,
      ): void => {
        $outputEncoder(encodeSMTP$MAIL_FROM$Packet({ from: stringToUTF8EncodedString(`<${from}>`) }));
      };

      const sendAndAwait$MAIL_FROM$ = (
        from: string,
      ): Promise<any> => {
        send$MAIL_FROM$(from);
        return decode<ISMTP$OK_RSP$Packet>(decodeSMTP$OK_RSP$Packet());
      };

      // RCPT
      const send$RCPT_TO$ = (
        to: string,
      ): void => {
        $outputEncoder(encodeSMTP$RCPT_TO$Packet({ to: stringToUTF8EncodedString(`<${to}>`) }));
      };

      const sendAndAwait$RCPT_TO$ = (
        from: string,
      ): Promise<any> => {
        send$RCPT_TO$(from);
        return decode<ISMTP$OK_RSP$Packet>(decodeSMTP$OK_RSP$Packet());
      };

      // DATA
      const send$DATA$ = (): void => {
        $outputEncoder(encodeSMTP$DATA$Packet());
      };

      const sendAndAwait$DATA$ = (): Promise<ISMTP$DATA_OK_RSP$Packet> => {
        send$DATA$();
        return decode<ISMTP$DATA_OK_RSP$Packet>(decodeSMTP$DATA_OK_RSP$Packet());
      };

      // DATA_CONTENT
      const send$DATA_CONTENT$ = (
        content: string,
      ): void => {
        $outputEncoder(encodeSMTP$DATA_CONTENT$Packet({ content: stringToUTF8EncodedString(content) }));
      };

      const sendAndAwait$DATA_CONTENT$ = (
        content: string,
      ): Promise<ISMTP$DATA_OK_RSP$Packet> => {
        send$DATA_CONTENT$(content);
        return decode<ISMTP$OK_RSP$Packet>(decodeSMTP$OK_RSP$Packet());
      };

      /* PUBLIC */

      const connect = (): Promise<ISMTPClient> => {
        return awaitGreeting()
          .then(() => {
            console.log('greating done');
            return sendAndAwait$EHLO$();
          })
          .then(() => {
            return performAuth();
          })
          .then(() => {
            console.log('auth done');
            return {
              send,
            };
          });
      };

      const send = (
        {
          from = username,
          to,
          content,
        }: ISMTPClientSendOptions,
      ): Promise<void> => {
        return sendAndAwait$MAIL_FROM$(from)
          .then(() => {
            return sendAndAwait$RCPT_TO$(to);
          })
          .then(() => {
            return sendAndAwait$DATA$();
          })
          .then(() => {
            return sendAndAwait$DATA_CONTENT$(content);
          })
          .then(noop)
          ;
      };

      // writeCommands('Subject: ', subject);
      // writeCommands('From: ', fromData);
      // writeCommands('To: ', toData);
      // writeCommands('Date: ', new Date().toString());
      //
      // if (html) {
      //   writeCommands('Content-Type: multipart/alternative; boundary=AlternativeBoundary', '\r\n');
      //   writeCommands('--AlternativeBoundary');
      //   writeCommands('Content-Type: text/plain; charset="utf-8"', '\r\n');
      //   writeCommands(content, '\r\n');
      //   writeCommands('--AlternativeBoundary');
      //   writeCommands('Content-Type: text/html; charset="utf-8"', '\r\n');
      //   writeCommands(html, '\r\n.\r\n');
      // } else {
      //   writeCommands('MIME-Version: 1.0');
      //   writeCommands('Content-Type: text/html;charset=utf-8');
      //   writeCommands(`Content-Transfer-Encoding: ${'quoted-printable'}` + '\r\n');
      //   writeCommands(content, '\r\n.\r\n');
      // }


      resolve(connect());
    };

    stream$(notificationObserver({
      open: onOpen,
      closed: (event: unknown) => {
        reject(new (Error as any)(`Socket closed`, { cause: event }));
      },
      error: (error: unknown) => {
        reject(error);
      },
    }));
  });
}


async function websocketExample2() {
  const config = SMTP_CONFIG;

  const stream$ = createRawSocketByteStream({
    hostname: config.hostname,
    port: config.port,
  });

  const client = await createSMTPClientFromByteStream({
    stream$,
    ...config,
  });

  console.log('client connected');

  window.onclick = async () => {
    await client.send({
      to: 'valentin.richard@infomaniak.com',
      content: await createSMTPDataContentExample1(),
    });
    console.log('sent');
  };

}

async function createSMTPDataContentExample1() {
  // 550 5.2.0 Spam message rejected
  // https://v2.jokeapi.dev/joke/Any?safe-mode&type=single

  const getJoke = () => {
    return fetchJSON<any>('https://v2.jokeapi.dev/joke/Any?safe-mode')
      .then((data: any): string => {
        return (data.type === 'twopart')
          ? `${data.setup}\n${data.delivery}`
          : data.joke;
      });
  };

  const joke = await getJoke();
  // const joke = 'joke';

  const content = createSMTPDataContentString({
    to: 'valentin.richard@infomaniak.com',
    from: 'valentin.richard@infomaniak.com',
    subject: `note #${Math.floor(Math.random() * 1e2)}`,
    text: joke,
    attachments: [
      {
        // type: 'text/plain',
        type: 'text/plain; charset=UTF-8; name="joke.txt"',
        name: 'joke.txt',
        content: stringToUTF8EncodedString(joke),
      },
    ],
  });

  console.log(content);

  return content;
}

async function btoaExample() {
  // const text = '\0';
  // const text = 'A';
  const text = 'abc';
  // const text = String.fromCharCode(0b11111100);
  const input = binaryStringToUint8Array(text);
  const output = encodeUint8ArrayToBase64(input);
  const encodedText: string = uint8ArrayToBinaryString(output);
  console.log(encodedText);
  const decoded = decodeUint8ArrayFromBase64(output);
  const decodedText = uint8ArrayToBinaryString(decoded);
  console.log(decodedText);
}


/*
TODO:
 use UnicastStream instead of generators to encode and decode ?
 OR
 see decoder v2
 */

/*----------------------------------*/

export function websocketExample() {
  // websocketExample0();
  // websocketExample1();
  // websocketExample2();
  // btoaExample();
  createSMTPDataContentExample1();
}
