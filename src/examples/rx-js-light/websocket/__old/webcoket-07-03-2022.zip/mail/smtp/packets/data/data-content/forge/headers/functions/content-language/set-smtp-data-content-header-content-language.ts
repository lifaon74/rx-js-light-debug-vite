import { ISMTPDataContentHeaders } from '../../types/smtp-data-content-headers.type';

// https://datatracker.ietf.org/doc/html/rfc3282

export function setSMTPDataContentHeader$ContentLanguage$(
  headers: ISMTPDataContentHeaders,
): void {
  // TODO
  headers.set('Content-Language', 'en-US');
}

