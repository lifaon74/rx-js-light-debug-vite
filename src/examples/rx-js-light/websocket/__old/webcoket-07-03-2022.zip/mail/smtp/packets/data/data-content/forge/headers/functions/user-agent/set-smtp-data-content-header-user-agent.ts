import { ISMTPDataContentHeaders } from '../../types/smtp-data-content-headers.type';

export function setSMTPDataContentHeader$UserAgent$(
  headers: ISMTPDataContentHeaders,
  userAgent: string = navigator.userAgent,
): void {
  headers.set('User-Agent', userAgent);
}

