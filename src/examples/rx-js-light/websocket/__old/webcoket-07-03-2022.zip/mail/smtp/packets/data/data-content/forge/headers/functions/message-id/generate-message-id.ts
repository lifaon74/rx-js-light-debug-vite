import { generateUUID } from './generate-uuid';

export function generateMessageId(
  hostname: string,
): string {
  return `${generateUUID()}@${hostname}`;
}
