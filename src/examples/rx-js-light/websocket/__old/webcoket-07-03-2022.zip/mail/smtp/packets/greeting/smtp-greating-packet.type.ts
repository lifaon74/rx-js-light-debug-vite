import { IUTF8EncodedString } from '../../../../string/utf8-encoded-string.type';


export interface ISMTP$GREETING$Packet {
  hostname: IUTF8EncodedString;
  text: IUTF8EncodedString;
}

