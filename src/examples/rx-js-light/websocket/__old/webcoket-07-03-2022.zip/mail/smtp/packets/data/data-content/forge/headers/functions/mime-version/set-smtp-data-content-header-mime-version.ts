import { ISMTPDataContentHeaders } from '../../types/smtp-data-content-headers.type';

export function setSMTPDataContentHeader$MIMEVersion$(
  headers: ISMTPDataContentHeaders,
  version: string,
): void {
  headers.set('MIME-Version', version);
}

