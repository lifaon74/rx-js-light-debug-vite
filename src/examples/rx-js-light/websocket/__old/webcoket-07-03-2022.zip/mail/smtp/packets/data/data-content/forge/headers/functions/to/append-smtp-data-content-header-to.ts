import { ISMTPDataContentHeaders } from '../../types/smtp-data-content-headers.type';
import { IEmailAddressString } from '../../../../../../../../types/email-address-string/email-address-string.type';
import { getSMTPDataContentHeader$To$ } from './get-smtp-data-content-header-to';
import { ISMTPDataContentHeaderToKeys } from './constants/smtp-data-content-header-to-keys.type';
import { setSMTPDataContentHeader$To$ } from './set-smtp-data-content-header-to';

export function appendSMTPDataContentHeader$To$(
  headers: ISMTPDataContentHeaders,
  key: ISMTPDataContentHeaderToKeys,
  value: IEmailAddressString,
): void {
  setSMTPDataContentHeader$To$(
    headers,
    key,
    [
      ...getSMTPDataContentHeader$To$(headers, key),
      value,
    ],
  );
}
