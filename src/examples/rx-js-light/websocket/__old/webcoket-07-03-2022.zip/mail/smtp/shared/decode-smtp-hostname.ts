import { IUTF8EncodedString } from '../../../string/utf8-encoded-string.type';
import { u8 } from '@lifaon/number-types';
import { GrowableUint8Array } from '../../../array-buffer/growable-uint8-array';
import { isAlphaNumericChar } from '../../../chars/is/is-alpha-numeric-char';
import { CHAR_MINUS } from '../../../chars/minus.constant';
import { CHAR_DOT } from '../../../chars/dot.constant';
import { CHAR_RIGHT_SQUARE_BRACKET } from '../../../chars/right-square-bracket.constant';
import { CHAR_LEFT_SQUARE_BRACKET } from '../../../chars/left-square-bracket.constant';
import { CHAR_COLON } from '../../../chars/colon.constant';
import { utf8EncodedStringToString } from '../../../string/utf8-encoded-string-to-string';

// https://datatracker.ietf.org/doc/html/rfc5321#section-4.1.2


export function * decodeSMTP$Hostname$(): Generator<void, IUTF8EncodedString, u8> {
  const text: GrowableUint8Array = new GrowableUint8Array();
  let byte: u8;

  while (true) {
    byte = yield;
    if (
      isAlphaNumericChar(byte)
      || (byte === CHAR_MINUS)
      || (byte === CHAR_DOT)
      || (byte === CHAR_LEFT_SQUARE_BRACKET)
      || (byte === CHAR_RIGHT_SQUARE_BRACKET)
      || (byte === CHAR_COLON)
    ) {
      text.push(byte);
    } else {
      const hostname: IUTF8EncodedString = text.data;

      try {
        new URL(`mailto:${utf8EncodedStringToString(hostname)}`);
      } catch {
        throw new Error(`Invalid domain`);
      }

      return hostname;
    }
  }
}



// export interface IDecodeSMTP$Hostname$Result {
//   hostname: IUTF8EncodedString;
//   byte: u8;
// }


// export function * decodeSMTP$Hostname$(
//   byte: u8,
// ): Generator<void, IDecodeSMTP$Hostname$Result, u8> {
//   const text: GrowableUint8Array = new GrowableUint8Array();
//   while (
//     isAlphaNumericChar(byte)
//     || (byte === CHAR_MINUS)
//     || (byte === CHAR_DOT)
//     || (byte === CHAR_LEFT_SQUARE_BRACKET)
//     || (byte === CHAR_RIGHT_SQUARE_BRACKET)
//     || (byte === CHAR_COLON)
//     ) {
//     text.push(byte);
//     byte = yield;
//   }
//
//   const hostname: IUTF8EncodedString = text.data;
//
//   try {
//     new URL(`mailto:${utf8EncodedStringToString(hostname)}`);
//   } catch {
//     throw new Error(`Invalid domain`);
//   }
//
//   return {
//     hostname,
//     byte,
//   };
// }
