export type ISMTPDataContentHeader = [
  key: string,
  value: string,
];
