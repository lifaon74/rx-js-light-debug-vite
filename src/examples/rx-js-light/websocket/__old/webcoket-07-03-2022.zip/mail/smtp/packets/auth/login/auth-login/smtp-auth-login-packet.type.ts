import { IUTF8EncodedString } from '../../../../../../string/utf8-encoded-string.type';

export interface ISMTP$AUT_LOGINH$Packet {
  username?: IUTF8EncodedString;
}
