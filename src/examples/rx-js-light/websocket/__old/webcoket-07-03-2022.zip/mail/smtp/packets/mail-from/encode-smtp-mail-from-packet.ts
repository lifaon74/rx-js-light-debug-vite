import { u8 } from '@lifaon/number-types';
import { ISMTP$MAIL_FROM$Packet } from './smtp-mail-from-packet.type';
import { CHAR_L } from '../../../../chars/alpha/uppercase/L.constant';
import { CHAR_O } from '../../../../chars/alpha/uppercase/O.constant';
import { CHAR_SPACE } from '../../../../chars/space.constant';
import { CHAR_CR } from '../../../../chars/CR.constant';
import { CHAR_LF } from '../../../../chars/LF.constant';
import { encodeUint8Array } from '../../../../encoding/uint8-array/encode-uint8-array';
import { CHAR_A } from '../../../../chars/alpha/uppercase/A.constant';
import { CHAR_R } from '../../../../chars/alpha/uppercase/R.constant';
import { CHAR_F } from '../../../../chars/alpha/uppercase/F.constant';
import { CHAR_I } from '../../../../chars/alpha/uppercase/I.constant';
import { CHAR_M } from '../../../../chars/alpha/uppercase/M.constant';
import { CHAR_COLON } from '../../../../chars/colon.constant';

// https://datatracker.ietf.org/doc/html/rfc5321#section-3.3
// https://datatracker.ietf.org/doc/html/rfc5321#section-4.1.1.2
// https://datatracker.ietf.org/doc/html/rfc5321#section-4.1.2 => reverse path

// TODO mail parameters

export function * encodeSMTP$MAIL_FROM$Packet(
  {
    from,
  }: ISMTP$MAIL_FROM$Packet,
): Generator<u8, void, void> {
  yield CHAR_M;
  yield CHAR_A;
  yield CHAR_I;
  yield CHAR_L;

  yield CHAR_SPACE;

  yield CHAR_F;
  yield CHAR_R;
  yield CHAR_O;
  yield CHAR_M;

  yield CHAR_COLON;

  yield * encodeUint8Array(from);

  yield CHAR_CR;
  yield CHAR_LF;
}

