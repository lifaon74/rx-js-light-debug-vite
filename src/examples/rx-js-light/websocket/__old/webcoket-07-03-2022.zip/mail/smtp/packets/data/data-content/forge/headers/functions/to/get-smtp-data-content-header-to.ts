import { ISMTPDataContentHeaders } from '../../types/smtp-data-content-headers.type';
import { IEmailAddressString } from '../../../../../../../../types/email-address-string/email-address-string.type';
import { ISMTPDataContentHeaderToKeys } from './constants/smtp-data-content-header-to-keys.type';

export function getSMTPDataContentHeader$To$(
  headers: ISMTPDataContentHeaders,
  key: ISMTPDataContentHeaderToKeys,
): IEmailAddressString[] {
  const value: string | undefined = headers.get(key);
  if (value === void 0) {
    return [];
  } else {
    return value.split(', ');
  }
}
