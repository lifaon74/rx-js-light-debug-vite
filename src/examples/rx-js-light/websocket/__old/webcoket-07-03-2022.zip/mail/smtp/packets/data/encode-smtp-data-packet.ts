import { u8 } from '@lifaon/number-types';
import { CHAR_CR } from '../../../../chars/CR.constant';
import { CHAR_LF } from '../../../../chars/LF.constant';
import { CHAR_D } from '../../../../chars/alpha/uppercase/D.constant';
import { CHAR_T } from '../../../../chars/alpha/uppercase/T.constant';
import { CHAR_A } from '../../../../chars/alpha/uppercase/A.constant';

// https://datatracker.ietf.org/doc/html/rfc5321#section-4.1.1.4

export function * encodeSMTP$DATA$Packet(): Generator<u8, void, void> {
  yield CHAR_D;
  yield CHAR_A;
  yield CHAR_T;
  yield CHAR_A;

  yield CHAR_CR;
  yield CHAR_LF;
}

