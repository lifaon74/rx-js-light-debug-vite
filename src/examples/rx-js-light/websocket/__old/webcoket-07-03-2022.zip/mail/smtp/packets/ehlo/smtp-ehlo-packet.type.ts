import { IUTF8EncodedString } from '../../../../string/utf8-encoded-string.type';


export interface ISMTP$EHLO$Packet {
  hostname: IUTF8EncodedString;
}
