export const SMTP_DATA_CONTENT_HEADER_TO_KEY = 'To';

