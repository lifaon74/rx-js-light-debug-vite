import { ISMTPDataContentHeaders } from '../../types/smtp-data-content-headers.type';


export function setSMTPDataContentHeader$MessageId$(
  headers: ISMTPDataContentHeaders,
  messageId: string,
): void {
  headers.set('Message-ID', `<${messageId}>`);
}

