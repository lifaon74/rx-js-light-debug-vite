import { ISMTP$AUTH_OK_RSP$Packet } from './smtp-auth-ok-rsp-packet.type';
import {
  decodeAndCacheLastByte, IDecodeAndCacheLastByteResult,
} from '../../../../../encoding/helpers/decode-and-cache-last-byte';
import { isNumericChar } from '../../../../../chars/is/is-numeric-char';
import { CHAR_DOT } from '../../../../../chars/dot.constant';
import { CHAR_3 } from '../../../../../chars/digits/3.constant';
import { u8 } from '@lifaon/number-types';
import { CHAR_2 } from '../../../../../chars/digits/2.constant';
import { CHAR_5 } from '../../../../../chars/digits/5.constant';
import { CHAR_SPACE } from '../../../../../chars/space.constant';
import { IUTF8EncodedString } from '../../../../../string/utf8-encoded-string.type';
import { GrowableUint8Array } from '../../../../../array-buffer/growable-uint8-array';
import { CHAR_CR } from '../../../../../chars/CR.constant';
import { CHAR_LF } from '../../../../../chars/LF.constant';

// https://www.rfc-editor.org/rfc/rfc4954.txt


export function * decodeSMTP$AUTH_OK_RSP$Packet(): Generator<void, ISMTP$AUTH_OK_RSP$Packet, u8> {

  let byte: u8;

  // code
  {
    const result: IDecodeAndCacheLastByteResult<void> = yield * decodeAndCacheLastByte<void>(
      decodeSMTP$AUTH_OK_RSP_CODE(),
      0,
    );
    byte = result.byte;
  }

  // version
  let version: IUTF8EncodedString;
  {
    const result: IDecodeAndCacheLastByteResult<IUTF8EncodedString> = yield * decodeAndCacheLastByte<IUTF8EncodedString>(
      decodeSMTP$AUTH_OK_RSP_VERSION$(),
      byte,
    );
    version = result.value;
    byte = result.byte;
  }

  // text
  let text: IUTF8EncodedString;
  {
    const result: IDecodeAndCacheLastByteResult<IUTF8EncodedString> = yield * decodeAndCacheLastByte<IUTF8EncodedString>(
      decodeSMTP$AUTH_OK_RSP_TEXT$(),
      byte,
    );
    text = result.value;
    byte = result.byte;
  }

  if (byte !== CHAR_CR) {
    throw new Error(`Expected \\r`);
  }

  if ((byte = yield) !== CHAR_LF) {
    throw new Error(`Expected \\n`);
  }

  return {
    version,
    text,
  };
}



function * decodeSMTP$AUTH_OK_RSP_CODE(): Generator<void, void, u8> {
  // 235
  let byte: u8;
  if ((byte = yield) !== CHAR_2) {
    throw new Error(`Expected 2, found: ${byte}`);
  }
  if ((byte = yield) !== CHAR_3) {
    throw new Error(`Expected 3, found: ${byte}`);
  }
  if ((byte = yield) !== CHAR_5) {
    throw new Error(`Expected 5, found: ${byte}`);
  }
  if ((byte = yield) !== CHAR_SPACE) {
    throw new Error(`Expected SPACE, found: ${byte}`);
  }
}


function * decodeSMTP$AUTH_OK_RSP_VERSION$(): Generator<void, IUTF8EncodedString, u8> {
  const text: GrowableUint8Array = new GrowableUint8Array();
  let byte: u8;
  while (true) {
    byte = yield;
    if (
      isNumericChar(byte)
        || (byte === CHAR_DOT)
    ) {
      text.push(byte);
    } else {
      return text.data;
    }
  }
}


function * decodeSMTP$AUTH_OK_RSP_TEXT$(): Generator<void, IUTF8EncodedString, u8> {
  const text: GrowableUint8Array = new GrowableUint8Array();
  let byte: u8;
  while (true) {
    byte = yield;
    if (
      (byte !== CHAR_CR)
      && (byte !== CHAR_LF)
    ) {
      text.push(byte);
    } else {
      return text.data;
    }
  }
}

