import { ISMTPDataContentHeaders } from '../../types/smtp-data-content-headers.type';

export type ISMTPDataContentOptionsDate =
  | Date
  | number
  ;


export function setSMTPDataContentHeader$Date$(
  headers: ISMTPDataContentHeaders,
  date: ISMTPDataContentOptionsDate = new Date(),
): void {
  const _date: Date = (typeof date === 'number')
    ? new Date(date)
    : date;
  headers.set('Date', _date.toString());
}

