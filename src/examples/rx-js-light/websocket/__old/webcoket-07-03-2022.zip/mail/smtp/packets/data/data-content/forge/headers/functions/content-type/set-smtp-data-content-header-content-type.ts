import { ISMTPDataContentHeaders } from '../../types/smtp-data-content-headers.type';


export function setSMTPDataContentHeader$ContentType$(
  headers: ISMTPDataContentHeaders,
  contentType: string,
): void {
  headers.set('Content-Type', contentType);
}

