import { u8 } from '@lifaon/number-types';
import { ISMTP$DATA_CONTENT$Packet } from './smtp-data-content-packet.type';
import { encodeUint8Array } from '../../../../../encoding/uint8-array/encode-uint8-array';
import { CHAR_CR } from '../../../../../chars/CR.constant';
import { CHAR_LF } from '../../../../../chars/LF.constant';
import { CHAR_DOT } from '../../../../../chars/dot.constant';

// https://datatracker.ietf.org/doc/html/rfc5321#section-3.3

export function * encodeSMTP$DATA_CONTENT$Packet(
  {
    content,
  }: ISMTP$DATA_CONTENT$Packet,
): Generator<u8, void, void> {
  yield * encodeUint8Array(content);

  yield CHAR_CR;
  yield CHAR_LF;
  yield CHAR_DOT;
  yield CHAR_CR;
  yield CHAR_LF;
}

