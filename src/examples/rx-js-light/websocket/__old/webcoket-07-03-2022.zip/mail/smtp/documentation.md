https://datatracker.ietf.org/doc/html/rfc5321


https://deno.land/x/smtp@v0.7.0/smtp.ts
https://mailtrap.io/blog/smtp-commands-and-responses/#:~:text=The%20HELO%20command%20initiates%20the,address%20of%20the%20SMTP%20client.&text=EHLO%20is%20an%20alternative%20to,SMTP%20service%20extensions%20(ESMTP).
https://github.com/xpepermint/smtp-client#readme
