import { IEmailContact } from '../../../../../../../../types/email-contact/email-contact.type';
import { ISMTPDataContentHeaders } from '../../types/smtp-data-content-headers.type';
import { IEmailContactOrEmailAddressString } from '../../../../../../../../types/email-contact/email-contact-or-email-address-string.type';

export function setSMTPDataContentHeader$From$(
  headers: ISMTPDataContentHeaders,
  from: IEmailContactOrEmailAddressString,
): void {
  const _from: string = (typeof from === 'string')
    ? `<${from}>`
    : emailContactToSMTPDataContentHeader$From$(from);
  headers.set('From', _from);
}

function emailContactToSMTPDataContentHeader$From$(
  {
    email,
    name,
  }: IEmailContact,
): string {
  return `"${name}" <${email}>`;
}
