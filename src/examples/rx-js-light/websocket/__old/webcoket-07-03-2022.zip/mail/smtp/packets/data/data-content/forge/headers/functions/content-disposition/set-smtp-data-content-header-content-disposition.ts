import { ISMTPDataContentHeaders } from '../../types/smtp-data-content-headers.type';


export function setSMTPDataContentHeader$ContentDisposition$(
  headers: ISMTPDataContentHeaders,
  contentDisposition: string,
): void {
  headers.set('Content-Disposition', contentDisposition);
}

