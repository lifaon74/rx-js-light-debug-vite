import { u16, u32, u64 } from '@lifaon/number-types';

// https://en.wikipedia.org/wiki/Universally_unique_identifier

// export function generateUUIDV1(): string {
//   const time: u64 = Date.now() * 1000 + 12219292800000;
//   const time_low: u32 = (time & 0xffffffff) >>> 0;
//   const time_high: u16 = ((time / 0x100000000) & 0xffffffff) >>> 0;
//   const time_medium: u16 = time_high & 0xffff;
//   const time_high_and_version: number = ((time_high >>> 16) & 0x0fff) | 0x1000;
//
//   const time_low_string: string = toHEX(time_low, 8);
//   const time_medium_string: string = toHEX(time_medium, 4);
//   const time_high_and_version_string: string = toHEX(time_high_and_version, 4);
//
//
//   return `${time_low_string}-${time_medium_string}-${time_high_and_version_string}`
// }

// function toHEX(
//   value: number,
//   pad: number,
// ): string {
//   return value.toString(16).padStart(pad, '0');
// }

export function generateUID(
  size: number, // in bytes
): string {
  const bytes: Uint8Array = crypto.getRandomValues(new Uint8Array(size));
  let output: string = '';
  for(let i = 0; i < size; i++) {
    output += bytes[i].toString(16).padStart(2, '0');
  }
  return output;
}

export function generateUUID(): string {
  return generateUID(16);
}
