import { ISMTPDataContentHeaders } from '../types/smtp-data-content-headers.type';

export function createSMTPDataContentHeaders(): ISMTPDataContentHeaders {
  return new Map<string, string>();
}
