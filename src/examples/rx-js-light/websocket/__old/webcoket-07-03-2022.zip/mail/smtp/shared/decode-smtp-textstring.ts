import { IUTF8EncodedString } from '../../../string/utf8-encoded-string.type';
import { u8 } from '@lifaon/number-types';
import { GrowableUint8Array } from '../../../array-buffer/growable-uint8-array';


export function * decodeSMTP$TextString$(): Generator<void, IUTF8EncodedString, u8> {
  const text: GrowableUint8Array = new GrowableUint8Array();
  let byte: u8;

  while (true) {
    byte = yield;
    if (
      (byte === 9)
      || ((32 <= byte) && (byte <= 126))
    ) {
      text.push(byte);
    } else {
      return text.data;
    }
  }
}

