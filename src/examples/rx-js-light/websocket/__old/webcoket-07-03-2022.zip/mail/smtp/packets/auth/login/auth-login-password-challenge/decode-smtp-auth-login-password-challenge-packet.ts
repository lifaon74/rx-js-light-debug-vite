import { u8 } from '../../../../../../../../../../../number-types/dist';
import { CHAR_CR } from '../../../../../../chars/CR.constant';
import { CHAR_LF } from '../../../../../../chars/LF.constant';

// const BYTES = binaryStringToUint8Array('334 UGFzc3dvcmQ6');
const BYTES = new Uint8Array([51, 51, 52, 32, 85, 71, 70, 122, 99, 51, 100, 118, 99, 109, 81, 54, CHAR_CR, CHAR_LF]);

export function * decodeSMTP$AUTH_LOGIN_PASSWORD_CHALLENGE$Packet(): Generator<void, void, u8> {
  for (let i = 0, l = BYTES.length; i < l; i++) {
    const byte: u8 = yield;
    const _byte: u8 = BYTES[i];
    if (byte !== _byte) {
      throw new Error(`Expected ${_byte}, found: ${byte}`);
    }
  }
}


