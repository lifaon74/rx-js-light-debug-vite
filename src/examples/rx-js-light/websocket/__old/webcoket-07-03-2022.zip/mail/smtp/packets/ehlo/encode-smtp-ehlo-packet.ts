import { u8 } from '@lifaon/number-types';
import { ISMTP$EHLO$Packet } from './smtp-ehlo-packet.type';
import { CHAR_E } from '../../../../chars/alpha/uppercase/E.constant';
import { CHAR_H } from '../../../../chars/alpha/uppercase/H.constant';
import { CHAR_L } from '../../../../chars/alpha/uppercase/L.constant';
import { CHAR_O } from '../../../../chars/alpha/uppercase/O.constant';
import { CHAR_SPACE } from '../../../../chars/space.constant';
import { CHAR_CR } from '../../../../chars/CR.constant';
import { CHAR_LF } from '../../../../chars/LF.constant';
import { encodeUint8Array } from '../../../../encoding/uint8-array/encode-uint8-array';

// https://datatracker.ietf.org/doc/html/rfc5321#section-4.1.1.1

export function * encodeSMTP$EHLO$Packet(
  {
    hostname,
  }: ISMTP$EHLO$Packet,
): Generator<u8, void, void> {
  yield CHAR_E;
  yield CHAR_H;
  yield CHAR_L;
  yield CHAR_O;
  yield CHAR_SPACE;

  yield * encodeUint8Array(hostname);

  yield CHAR_CR;
  yield CHAR_LF;
}

