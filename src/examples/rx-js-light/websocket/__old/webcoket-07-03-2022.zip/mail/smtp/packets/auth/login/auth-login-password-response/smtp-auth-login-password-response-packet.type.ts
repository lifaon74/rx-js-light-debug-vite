import { IUTF8EncodedString } from '../../../../../../string/utf8-encoded-string.type';



export interface ISMTP$AUTH_LOGIN_PASSWORD_RESPONSE$Packet {
  password: IUTF8EncodedString;
}
