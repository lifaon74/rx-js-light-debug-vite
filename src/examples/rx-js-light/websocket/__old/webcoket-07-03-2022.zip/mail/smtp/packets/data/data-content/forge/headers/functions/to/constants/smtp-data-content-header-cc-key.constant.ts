export const SMTP_DATA_CONTENT_HEADER_CC_KEY = 'Cc';

