import { ISMTPDataContentHeaders } from '../../types/smtp-data-content-headers.type';

export function setSMTPDataContentHeader$Subject$(
  headers: ISMTPDataContentHeaders,
  subject: string,
): void {
  headers.set('Subject', subject);
}

