import { IUTF8EncodedString } from '../../../../string/utf8-encoded-string.type';


export interface ISMTP$MAIL_FROM$Packet {
  from: IUTF8EncodedString;
}
