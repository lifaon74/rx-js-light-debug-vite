export const SMTP_DATA_CONTENT_HEADER_REPLY_TO = 'Reply-To';

