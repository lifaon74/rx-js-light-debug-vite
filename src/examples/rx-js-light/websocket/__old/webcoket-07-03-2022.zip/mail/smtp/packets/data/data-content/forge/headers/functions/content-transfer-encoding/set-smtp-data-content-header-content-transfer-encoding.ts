import { ISMTPDataContentHeaders } from '../../types/smtp-data-content-headers.type';

// https://docs.microsoft.com/en-us/exchange/configure-content-transfer-encoding-exchange-2013-help
// https://www.w3.org/Protocols/rfc1341/5_Content-Transfer-Encoding.html

export type ISMTPDataContentHeaderContentTransferEncoding =
  | '7bit'
  | '8bit'
  | 'base64'
  | 'quoted-printable'
  | 'binary'
;

export function setSMTPDataContentHeader$ContentTransferEncoding$(
  headers: ISMTPDataContentHeaders,
  contentTransferEncoding: ISMTPDataContentHeaderContentTransferEncoding,
): void {
  headers.set('Content-Transfer-Encoding', contentTransferEncoding);
}

