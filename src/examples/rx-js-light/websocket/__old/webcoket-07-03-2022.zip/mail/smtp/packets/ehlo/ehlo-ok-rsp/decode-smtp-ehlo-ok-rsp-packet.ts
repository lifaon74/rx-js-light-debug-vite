import { ISMTP$EHLO_OK_RSP$Packet, ISMTP$EHLO_OK_RSP$PacketLine } from './smtp-ehlo-ok-rsp-packet.type';
import { u8 } from '@lifaon/number-types';
import { CHAR_2 } from '../../../../../chars/digits/2.constant';
import { CHAR_5 } from '../../../../../chars/digits/5.constant';
import { CHAR_0 } from '../../../../../chars/digits/0.constant';
import { CHAR_SPACE } from '../../../../../chars/space.constant';
import { CHAR_MINUS } from '../../../../../chars/minus.constant';
import { GrowableUint8Array } from '../../../../../array-buffer/growable-uint8-array';
import { CHAR_CR } from '../../../../../chars/CR.constant';
import { IUTF8EncodedString } from '../../../../../string/utf8-encoded-string.type';
import { CHAR_LF } from '../../../../../chars/LF.constant';
import { decodeSMTP$Hostname$ } from '../../../shared/decode-smtp-hostname';
import {
  decodeAndCacheLastByte, IDecodeAndCacheLastByteResult,
} from '../../../../../encoding/helpers/decode-and-cache-last-byte';
import { isAlphaNumericChar } from '../../../../../chars/is/is-alpha-numeric-char';


// https://datatracker.ietf.org/doc/html/rfc5321#section-4.1.1.1

export function * decodeSMTP$EHLO_OK_RSP$Packet(): Generator<void, ISMTP$EHLO_OK_RSP$Packet, u8> {

  let byte: u8;
  let hasNextLine: boolean;

  // code
  {
    const result: IDecodeAndCacheLastByteResult<boolean> = yield * decodeAndCacheLastByte<boolean>(
      decodeSMTP$EHLO_OK_RSP_CODE(),
      0,
    );
    hasNextLine = result.value;
    byte = result.byte;
  }

  // hostname
  let hostname: IUTF8EncodedString;
  {
    const result: IDecodeAndCacheLastByteResult<IUTF8EncodedString> = yield * decodeAndCacheLastByte<IUTF8EncodedString>(
      decodeSMTP$Hostname$(),
      byte,
    );
    hostname = result.value;
    byte = result.byte;
  }

  // greet
  let greet: IUTF8EncodedString;
  if (byte === CHAR_CR) {
    greet = new Uint8Array();
  } else if (byte === CHAR_SPACE) {
    const result: IDecodeAndCacheLastByteResult<IUTF8EncodedString> = yield * decodeAndCacheLastByte(
      decodeSMTP$EHLO_GREET$(),
      byte,
    );
    greet = result.value;
    byte = result.byte;
  } else {
    throw new Error(`Expected \\r or space`);
  }

  if (byte !== CHAR_CR) {
    throw new Error(`Expected \\r`);
  }

  if ((byte = yield) !== CHAR_LF) {
    throw new Error(`Expected \\n`);
  }

  // lines
  const lines: ISMTP$EHLO_OK_RSP$PacketLine[] = [];
  while (hasNextLine) {
    // code
    {
      const result: IDecodeAndCacheLastByteResult<boolean> = yield * decodeAndCacheLastByte<boolean>(
        decodeSMTP$EHLO_OK_RSP_CODE(),
        byte,
      );
      hasNextLine = result.value;
      byte = result.byte;
    }

    // line
    {
      const result: IDecodeAndCacheLastByteResult<ISMTP$EHLO_OK_RSP$PacketLine> = yield * decodeAndCacheLastByte<ISMTP$EHLO_OK_RSP$PacketLine>(
        decodeSMTP$EHLO_LINE$(),
        byte,
      );
      lines.push(result.value);
      byte = result.byte;
    }

    if (byte !== CHAR_CR) {
      throw new Error(`Expected \\r`);
    }

    if ((byte = yield) !== CHAR_LF) {
      throw new Error(`Expected \\n`);
    }
  }

  return {
    hostname,
    greet,
    lines,
  };
}



function * decodeSMTP$EHLO_OK_RSP_CODE(): Generator<void, boolean, u8> {
  // 250
  let byte: u8;
  if ((byte = yield) !== CHAR_2) {
    throw new Error(`Expected 2, found: ${byte}`);
  }
  if ((byte = yield) !== CHAR_5) {
    throw new Error(`Expected 5, found: ${byte}`);
  }
  if ((byte = yield) !== CHAR_0) {
    throw new Error(`Expected 0, found: ${byte}`);
  }

  // SPACE or -
  byte = yield;
  if (
    (byte !== CHAR_SPACE)
    && (byte !== CHAR_MINUS)
  ) {
    throw new Error(`Expected SPACE or -`);
  }

  return (byte === CHAR_MINUS); // hasNextLine
}


function * decodeSMTP$EHLO_GREET$(): Generator<void, IUTF8EncodedString, u8> {
  const text: GrowableUint8Array = new GrowableUint8Array();
  let byte: u8;
  while (true) {
    byte = yield;
    if (
      (byte !== CHAR_CR)
      && (byte !== CHAR_LF)
      // ((0 <= byte) && (byte <= 9))
      // || ((11 <= byte) && (byte <= 12))
      // || ((14 <= byte) && (byte <= 127))
    ) {
      text.push(byte);
    } else {
      return text.data;
    }
  }
}


function * decodeSMTP$EHLO_LINE$(): Generator<void, ISMTP$EHLO_OK_RSP$PacketLine, u8> {
  let byte: u8;

  // keyword
  let keyword: IUTF8EncodedString;
  {
    const result: IDecodeAndCacheLastByteResult<IUTF8EncodedString> = yield * decodeAndCacheLastByte<IUTF8EncodedString>(
      decodeSMTP$EHLO_KEYWORD(),
      0,
    );
    keyword = result.value;
    byte = result.byte;
  }

  // params
  const params: IUTF8EncodedString[] = [];
  while (byte === CHAR_SPACE) {
    // param
    const result: IDecodeAndCacheLastByteResult<IUTF8EncodedString> = yield * decodeAndCacheLastByte<IUTF8EncodedString>(
      decodeSMTP$EHLO_PARAM(),
      0,
    );
    params.push(result.value);
    byte = result.byte;
  }

  return {
    keyword,
    params,
  };
}

function * decodeSMTP$EHLO_KEYWORD(): Generator<void, IUTF8EncodedString, u8> {
  const text: GrowableUint8Array = new GrowableUint8Array();
  let byte: u8;
  while (true) {
    byte = yield;
    if (
      isAlphaNumericChar(byte)
      || (byte === CHAR_MINUS)
    ) {
      text.push(byte);
    } else {
      return text.data;
    }
  }
}

function * decodeSMTP$EHLO_PARAM(): Generator<void, IUTF8EncodedString, u8> {
  const text: GrowableUint8Array = new GrowableUint8Array();
  let byte: u8;
  while (true) {
    byte = yield;
    if (
      (33 <= byte) && (byte <= 126)
    ) {
      text.push(byte);
    } else {
      return text.data;
    }
  }
}

