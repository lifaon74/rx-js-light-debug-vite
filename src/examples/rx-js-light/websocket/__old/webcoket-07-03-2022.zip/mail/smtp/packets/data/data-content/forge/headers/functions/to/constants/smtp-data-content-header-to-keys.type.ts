import { SMTP_DATA_CONTENT_HEADER_CC_KEY } from './smtp-data-content-header-cc-key.constant';
import { SMTP_DATA_CONTENT_HEADER_TO_KEY } from './smtp-data-content-header-to-key.constant';
import { SMTP_DATA_CONTENT_HEADER_BCC_KEY } from './smtp-data-content-header-bcc-key.constant';
import { SMTP_DATA_CONTENT_HEADER_REPLY_TO } from './smtp-data-content-header-reply-to-key.constant';

export type ISMTPDataContentHeaderToKeys =
  | typeof SMTP_DATA_CONTENT_HEADER_TO_KEY
  | typeof SMTP_DATA_CONTENT_HEADER_CC_KEY
  | typeof SMTP_DATA_CONTENT_HEADER_BCC_KEY
  | typeof SMTP_DATA_CONTENT_HEADER_REPLY_TO
;

