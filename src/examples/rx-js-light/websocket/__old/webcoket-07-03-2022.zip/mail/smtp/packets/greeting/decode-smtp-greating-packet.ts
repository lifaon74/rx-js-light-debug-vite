import { ISMTP$GREETING$Packet } from './smtp-greating-packet.type';
import { u8 } from '../../../../../../../../../number-types/dist';
import { CHAR_2 } from '../../../../chars/digits/2.constant';
import { CHAR_0 } from '../../../../chars/digits/0.constant';
import { CHAR_SPACE } from '../../../../chars/space.constant';
import { CHAR_MINUS } from '../../../../chars/minus.constant';
import { CHAR_CR } from '../../../../chars/CR.constant';
import { IUTF8EncodedString } from '../../../../string/utf8-encoded-string.type';
import { decodeSMTP$TextString$ } from '../../shared/decode-smtp-textstring';
import { decodeSMTP$Hostname$ } from '../../shared/decode-smtp-hostname';
import { CHAR_LF } from '../../../../chars/LF.constant';
import {
  decodeAndCacheLastByte, IDecodeAndCacheLastByteResult,
} from '../../../../encoding/helpers/decode-and-cache-last-byte';

// https://datatracker.ietf.org/doc/html/rfc5321#section-4.2

export function * decodeSMTP$GREETING$Packet(): Generator<void, ISMTP$GREETING$Packet, u8> {

  let byte: u8;

  // code
  {
    const result: IDecodeAndCacheLastByteResult<boolean> = yield * decodeAndCacheLastByte<boolean>(
      decodeSMTP$GREETING_CODE(),
      0,
    );
    // hasNextLine = result.value;
    byte = result.byte;
  }

  // TODO support the case where byte = '-'

  // hostname
  let hostname: IUTF8EncodedString;
  {
    const result: IDecodeAndCacheLastByteResult<IUTF8EncodedString> = yield * decodeAndCacheLastByte<IUTF8EncodedString>(
      decodeSMTP$Hostname$(),
      byte,
    );
    hostname = result.value;
    byte = result.byte;
  }

  // console.log(utf8EncodedStringToString(hostname));

  // text
  let text: IUTF8EncodedString;
  if (byte === CHAR_CR) {
    text = new Uint8Array();
  } else if (byte === CHAR_SPACE) {
    const result: IDecodeAndCacheLastByteResult<IUTF8EncodedString> = yield * decodeAndCacheLastByte(
      decodeSMTP$TextString$(),
      byte,
    );
    text = result.value;
    byte = result.byte;
  } else {
    throw new Error(`Expected \\r or space`);
  }

  // console.log(utf8EncodedStringToString(text));

  if (byte !== CHAR_CR) {
    throw new Error(`Expected \\r`);
  }

  if ((byte = yield) !== CHAR_LF) {
    throw new Error(`Expected \\n`);
  }

  return {
    hostname,
    text,
  };
}


function * decodeSMTP$GREETING_CODE(): Generator<void, boolean, u8> {
  // 220
  let byte: u8;
  if ((byte = yield) !== CHAR_2) {
    throw new Error(`Expected 2, found: ${byte}`);
  }
  if ((byte = yield) !== CHAR_2) {
    throw new Error(`Expected 2, found: ${byte}`);
  }
  if ((byte = yield) !== CHAR_0) {
    throw new Error(`Expected 0, found: ${byte}`);
  }

  // SPACE or -
  byte = yield;
  if (
    (byte !== CHAR_SPACE)
    && (byte !== CHAR_MINUS)
  ) {
    throw new Error(`Expected SPACE or -`);
  }

  return (byte === CHAR_MINUS); // hasNextLine
}
