import { u8 } from '@lifaon/number-types';
import { ISMTP$AUT_LOGINH$Packet } from './smtp-auth-login-packet.type';
import { CHAR_T } from '../../../../../../chars/alpha/uppercase/T.constant';
import { CHAR_CR } from '../../../../../../chars/CR.constant';
import { CHAR_U } from '../../../../../../chars/alpha/uppercase/U.constant';
import { CHAR_L } from '../../../../../../chars/alpha/uppercase/L.constant';
import { CHAR_I } from '../../../../../../chars/alpha/uppercase/I.constant';
import { CHAR_SPACE } from '../../../../../../chars/space.constant';
import { CHAR_O } from '../../../../../../chars/alpha/uppercase/O.constant';
import { CHAR_N } from '../../../../../../chars/alpha/uppercase/N.constant';
import { CHAR_A } from '../../../../../../chars/alpha/uppercase/A.constant';
import { CHAR_G } from '../../../../../../chars/alpha/uppercase/G.constant';
import { CHAR_H } from '../../../../../../chars/alpha/uppercase/H.constant';
import { CHAR_LF } from '../../../../../../chars/LF.constant';
import { encodeUint8Array } from '../../../../../../encoding/uint8-array/encode-uint8-array';

// https://datatracker.ietf.org/doc/html/rfc4954
// https://interoperability.blob.core.windows.net/files/MS-XLOGIN/%5BMS-XLOGIN%5D.pdf   => p.8

export function * encodeSMTP$AUTH_LOGIN$Packet(
  {
    username,
  }: ISMTP$AUT_LOGINH$Packet = {},
): Generator<u8, void, void> {
  yield CHAR_A;
  yield CHAR_U;
  yield CHAR_T;
  yield CHAR_H;

  yield CHAR_SPACE;

  yield CHAR_L;
  yield CHAR_O;
  yield CHAR_G;
  yield CHAR_I;
  yield CHAR_N;

  if (username !== void 0) {
    yield CHAR_SPACE;
    yield * encodeUint8Array(username);
  }

  yield CHAR_CR;
  yield CHAR_LF;
}

