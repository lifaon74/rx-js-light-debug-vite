export const SMTP_DATA_CONTENT_HEADER_BCC_KEY = 'Bcc';

