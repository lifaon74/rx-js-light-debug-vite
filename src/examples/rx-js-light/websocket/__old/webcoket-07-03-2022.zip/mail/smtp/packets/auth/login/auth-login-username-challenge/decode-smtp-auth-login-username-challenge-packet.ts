import { u8 } from '../../../../../../../../../../../number-types/dist';
import { CHAR_CR } from '../../../../../../chars/CR.constant';
import { CHAR_LF } from '../../../../../../chars/LF.constant';

// const BYTES = binaryStringToUint8Array('334 VXNlcm5hbWU6');
const BYTES = new Uint8Array([51, 51, 52, 32, 86, 88, 78, 108, 99, 109, 53, 104, 98, 87, 85, 54, CHAR_CR, CHAR_LF]);

export function * decodeSMTP$AUTH_LOGIN_USERNAME_CHALLENGE$Packet(): Generator<void, void, u8> {
  for (let i = 0, l = BYTES.length; i < l; i++) {
    const byte: u8 = yield;
    const _byte: u8 = BYTES[i];
    if (byte !== _byte) {
      throw new Error(`Expected ${_byte}, found: ${byte}`);
    }
  }
}


