import { IUTF8EncodedString } from '../../../../../string/utf8-encoded-string.type';


export interface ISMTP$AUTH_OK_RSP$Packet {
  version: IUTF8EncodedString;
  text: IUTF8EncodedString;
}


