import { ISMTPDataContentHeader } from '../types/smtp-data-content-header.type';

export function smtpDataContentHeadersToString(
  headers: Iterable<ISMTPDataContentHeader>,
): string {
  let output: string = '';
  const iterator: Iterator<ISMTPDataContentHeader> = headers[Symbol.iterator]();
  let result: IteratorResult<ISMTPDataContentHeader>;
  while (!(result = iterator.next()).done) {
    const [key, value]: ISMTPDataContentHeader = result.value;
    if (output !== '') {
      output += '\r\n';
    }
    output += `${key}: ${value}`;
  }
  return output;
}

export function smtpDataContentHeadersToLines(
  headers: Iterable<ISMTPDataContentHeader>,
): string[] {
  return Array.from(headers, ([key, value]: ISMTPDataContentHeader): string => {
    return `${key}: ${value}`;
  });
}

