import { IEmailAddressString } from '../../../../../types/email-address-string/email-address-string.type';
import {
  IEmailContactOrEmailAddressString,
} from '../../../../../types/email-contact/email-contact-or-email-address-string.type';
import { createSMTPDataContentHeaders } from './headers/functions/create-smtp-data-content-headers';
import { ISMTPDataContentHeaders } from './headers/types/smtp-data-content-headers.type';
import { setSMTPDataContentHeader$Subject$ } from './headers/functions/subject/set-smtp-data-content-header-from';
import {
  ISMTPDataContentOptionsDate, setSMTPDataContentHeader$Date$,
} from './headers/functions/date/set-smtp-data-content-header-date';
import { generateMessageId } from './headers/functions/message-id/generate-message-id';
import {
  setSMTPDataContentHeader$MessageId$,
} from './headers/functions/message-id/set-smtp-data-content-header-message-id';
import { smtpDataContentHeadersToLines } from './headers/functions/smtp-data-content-headers-to-string';
import {
  setSMTPDataContentHeader$MIMEVersion$,
} from './headers/functions/mime-version/set-smtp-data-content-header-mime-version';
import {
  setSMTPDataContentHeader$ContentType$,
} from './headers/functions/content-type/set-smtp-data-content-header-content-type';
import {
  ISMTPDataContentHeaderContentTransferEncoding, setSMTPDataContentHeader$ContentTransferEncoding$,
} from './headers/functions/content-transfer-encoding/set-smtp-data-content-header-content-transfer-encoding';
import { setSMTPDataContentHeader$To$ } from './headers/functions/to/set-smtp-data-content-header-to';
import {
  SMTP_DATA_CONTENT_HEADER_TO_KEY,
} from './headers/functions/to/constants/smtp-data-content-header-to-key.constant';
import { setSMTPDataContentHeader$From$ } from './headers/functions/from/set-smtp-data-content-header-from';
import { IEmailAttachment } from '../../../../../types/email-attachment/email-attachment.type';
import {
  emailContactOrEmailAddressStringToEmailAddressString,
} from '../../../../../types/email-contact/email-contact-or-email-address-string-to-email-address-string';
import {
  IEmailAddressStringReadonlyArray,
} from '../../../../../types/email-address-string/email-address-string-readonly-array.type';
import {
  IEmailAddressStringOrEmailAddressStringReadonlyArray,
} from '../../../../../types/email-address-string/email-address-string-or-email-address-string-readonly-array.type';
import {
  emailAddressStringOrEmailAddressStringReadonlyArrayToEmailAddressStringReadonlyArray,
} from '../../../../../types/email-address-string/email-address-string-or-email-address-string-readonly-array-to-email-address-string-readonly-array';
import {
  SMTP_DATA_CONTENT_HEADER_REPLY_TO,
} from './headers/functions/to/constants/smtp-data-content-header-reply-to-key.constant';
import {
  SMTP_DATA_CONTENT_HEADER_CC_KEY,
} from './headers/functions/to/constants/smtp-data-content-header-cc-key.constant';
import {
  SMTP_DATA_CONTENT_HEADER_BCC_KEY,
} from './headers/functions/to/constants/smtp-data-content-header-bcc-key.constant';
import {
  setSMTPDataContentHeader$ContentDisposition$,
} from './headers/functions/content-disposition/set-smtp-data-content-header-content-disposition';
import { uint8ArrayToBinaryString } from '../../../../../../string/uint8-array-to-binary-string';


/*--------------*/


// export interface IForgeSMTPDataContentOptions {
//   headers: Iterable<ISMTPDataContentHeader>;
// }
//
//
// export function forgeSMTPDataContent(
//   {
//
//   }: IForgeSMTPDataContentOptions,
// ): void {
//
// }

// export function applyHeaderFoldingToLine(
//   line: string,
// ): string[] {
//   while (line.length > 78) {
//
//   }
// }

export function applyBodyFoldingToLine(
  line: string,
): string[] {
  const maxLength: number = 78;
  const lines: string[] = [];
  while (line.length > maxLength) {
    lines.push(line.slice(0, maxLength));
    console.log('do fold');
    line = line.slice(maxLength);
  }
  if ((line.length > 0) || (lines.length === 0)) {
    lines.push(line);
  }
  return lines;
}

export function applyBodyFoldingToLines(
  lines: string[],
): string[] {
  return lines
    .map(applyBodyFoldingToLine)
    .flat();
}


const CRLF = '\r\n';

export function createSMTPDataContentString(
  options: ICreateSMTPDataContentOptions,
): string {
  return createSMTPDataContent(options).join(CRLF);
}

export interface ICreateSMTPDataContentOptions {
  messageId?: string;
  date?: ISMTPDataContentOptionsDate;
  userAgent?: string;
  to: IEmailAddressStringOrEmailAddressStringReadonlyArray;
  cc?: IEmailAddressStringOrEmailAddressStringReadonlyArray;
  bcc?: IEmailAddressStringOrEmailAddressStringReadonlyArray;
  replyTo?: IEmailAddressStringOrEmailAddressStringReadonlyArray;
  from: IEmailContactOrEmailAddressString;
  subject: string;
  text: string;
  html?: string;
  attachments?: readonly IEmailAttachment[];
}

// https://www.ietf.org/rfc/rfc2822.txt

export function createSMTPDataContent(
  {
    messageId,
    date,
    userAgent = '',
    to,
    cc = [],
    bcc = [],
    replyTo = [],
    from,
    subject,
    text,
    html = '',
    attachments = [],
  }: ICreateSMTPDataContentOptions,
): string[] {
  // const headers: ISMTPDataContentHeaders = createSMTPDataContentHeaders();

  if (messageId === void 0) {
    const fromEmail: IEmailAddressString = emailContactOrEmailAddressStringToEmailAddressString(from);
    const fromURL: URL = new URL(`http://${fromEmail.split('@')[1]}`);
    messageId = generateMessageId(fromURL.hostname);
  }

  to = emailAddressStringOrEmailAddressStringReadonlyArrayToEmailAddressStringReadonlyArray(to);
  cc = emailAddressStringOrEmailAddressStringReadonlyArrayToEmailAddressStringReadonlyArray(cc);
  bcc = emailAddressStringOrEmailAddressStringReadonlyArrayToEmailAddressStringReadonlyArray(bcc);
  replyTo = emailAddressStringOrEmailAddressStringReadonlyArrayToEmailAddressStringReadonlyArray(replyTo);

  const contentTransferEncoding: ISMTPDataContentHeaderContentTransferEncoding = 'base64';

  const headers: ISMTPDataContentHeaders = createSMTPDataContentHeaders();

  appendDefaultSMTPDataContentHeaders(headers, {
    messageId,
    date,
    to,
    cc,
    bcc,
    replyTo,
    from,
    subject,
  });

  const textContent: string[] = createSMTPDataContentTextContent(contentTransferEncoding, text);

  if (html === '') {
    if (attachments.length === 0) { // text
      return [
        ...smtpDataContentHeadersToLines(headers),
        '',
        ...textContent,
      ];
    } else { // text & attachments
      // const boundary: string = `------------${generateUUID()}`;
      const boundary: string = `------------20f7c0nUPvZRtniUu0yqxVCY`;
      const fullBoundary: string = `--${boundary}`;

      const _headers: ISMTPDataContentHeaders = createSMTPDataContentHeaders();
      setSMTPDataContentHeader$ContentType$(_headers, `multipart/mixed; boundary="${boundary}"`);

      return applyBodyFoldingToLines([
        ...smtpDataContentHeadersToLines(_headers),
        ...smtpDataContentHeadersToLines(headers),
        '',
        'This is a multi-part message in MIME format.',
        fullBoundary,
        ...textContent,
        '',
        ...attachments
          .map(
            (attachment: IEmailAttachment): string[] => {
              return [
                fullBoundary,
                ...createSMTPDataContentAttachmentContent(attachment),
                '',
              ];
            },
          )
          .flat(),
        `${fullBoundary}--`,
      ]);

    }
  } else {
    if (attachments.length === 0) { // text & html

    } else { // html, text & attachments

    }
  }


  throw new Error(`TODO`); // TODO

}


export interface IAppendDefaultSMTPDataContentHeadersOptions {
  messageId: string;
  date: ISMTPDataContentOptionsDate | undefined;
  to: IEmailAddressStringReadonlyArray;
  cc: IEmailAddressStringReadonlyArray;
  bcc: IEmailAddressStringReadonlyArray;
  replyTo: IEmailAddressStringReadonlyArray;
  from: IEmailContactOrEmailAddressString;
  subject: string,
}

function appendDefaultSMTPDataContentHeaders(
  headers: ISMTPDataContentHeaders,
  {
    messageId,
    date,
    from,
    to,
    cc,
    bcc,
    replyTo,
    subject,
  }: IAppendDefaultSMTPDataContentHeadersOptions,
): void {
  setSMTPDataContentHeader$MessageId$(headers, messageId);
  setSMTPDataContentHeader$Date$(headers, date);
  setSMTPDataContentHeader$MIMEVersion$(headers, '1.0');

  // setSMTPDataContentHeader$UserAgent$(headers, userAgent);

  if (to.length === 0) {
    throw new Error(`'to' must contain at least a value`);
  } else {
    setSMTPDataContentHeader$To$(headers, SMTP_DATA_CONTENT_HEADER_TO_KEY, to);
  }

  if (cc.length !== 0) {
    setSMTPDataContentHeader$To$(headers, SMTP_DATA_CONTENT_HEADER_CC_KEY, cc);
  }

  if (bcc.length !== 0) {
    setSMTPDataContentHeader$To$(headers, SMTP_DATA_CONTENT_HEADER_BCC_KEY, bcc);
  }

  if (replyTo.length !== 0) {
    setSMTPDataContentHeader$To$(headers, SMTP_DATA_CONTENT_HEADER_REPLY_TO, replyTo);
  }

  setSMTPDataContentHeader$From$(headers, from);
  setSMTPDataContentHeader$Subject$(headers, subject);
}


function createSMTPDataContentTextContent(
  contentTransferEncoding: ISMTPDataContentHeaderContentTransferEncoding,
  text: string,
): string[] {
  const headers: ISMTPDataContentHeaders = createSMTPDataContentHeaders();

  setSMTPDataContentHeader$ContentType$(headers, 'text/plain; charset=UTF-8');
  setSMTPDataContentHeader$ContentTransferEncoding$(headers, contentTransferEncoding);

  return [
    ...smtpDataContentHeadersToLines(headers),
    '',
    btoa(text),
  ];
}


function createSMTPDataContentAttachmentContent(
  {
    name,
    type,
    content,
  }: IEmailAttachment,
): string[] {
  const headers: ISMTPDataContentHeaders = createSMTPDataContentHeaders();

  setSMTPDataContentHeader$ContentType$(headers, type);
  setSMTPDataContentHeader$ContentDisposition$(headers, `attachment; filename="${name}"`);
  setSMTPDataContentHeader$ContentTransferEncoding$(headers, 'base64');

  return [
    ...smtpDataContentHeadersToLines(headers),
    '',
    btoa(uint8ArrayToBinaryString(content)),
    // uint8ArrayToBinaryString(encodeUint8ArrayToBase64(content)),
  ];
}
