import { IUTF8EncodedString } from '../../../../../string/utf8-encoded-string.type';


export interface ISMTP$EHLO_OK_RSP$Packet {
  hostname: IUTF8EncodedString;
  greet: IUTF8EncodedString;
  lines: ISMTP$EHLO_OK_RSP$PacketLine[];
}


export interface ISMTP$EHLO_OK_RSP$PacketLine {
  keyword: IUTF8EncodedString;
  params: IUTF8EncodedString[];
}
