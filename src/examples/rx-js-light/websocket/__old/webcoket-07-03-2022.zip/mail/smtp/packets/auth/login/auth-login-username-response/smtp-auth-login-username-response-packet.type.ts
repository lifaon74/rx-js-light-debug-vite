import { IUTF8EncodedString } from '../../../../../../string/utf8-encoded-string.type';



export interface ISMTP$AUTH_LOGIN_USERNAME_RESPONSE$Packet {
  username: IUTF8EncodedString;
}
