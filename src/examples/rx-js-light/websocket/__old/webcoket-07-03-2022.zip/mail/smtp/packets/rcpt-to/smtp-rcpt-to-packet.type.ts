import { IUTF8EncodedString } from '../../../../string/utf8-encoded-string.type';


export interface ISMTP$RCPT_TO$Packet {
  to: IUTF8EncodedString;
}
