import { IUTF8EncodedString } from '../../../../../string/utf8-encoded-string.type';


export interface ISMTP$DATA_CONTENT$Packet {
  content: IUTF8EncodedString; // includes header and body, but excludes end CRLF.CRLF
}

