import { u8 } from '@lifaon/number-types';
import { ISMTP$RCPT_TO$Packet } from './smtp-rcpt-to-packet.type';
import { CHAR_O } from '../../../../chars/alpha/uppercase/O.constant';
import { CHAR_SPACE } from '../../../../chars/space.constant';
import { CHAR_CR } from '../../../../chars/CR.constant';
import { CHAR_LF } from '../../../../chars/LF.constant';
import { encodeUint8Array } from '../../../../encoding/uint8-array/encode-uint8-array';
import { CHAR_R } from '../../../../chars/alpha/uppercase/R.constant';
import { CHAR_COLON } from '../../../../chars/colon.constant';
import { CHAR_C } from '../../../../chars/alpha/uppercase/C.constant';
import { CHAR_T } from '../../../../chars/alpha/uppercase/T.constant';
import { CHAR_P } from '../../../../chars/alpha/uppercase/P.constant';

// https://datatracker.ietf.org/doc/html/rfc5321#section-4.1.1.3

// TODO rcpt parameters

export function * encodeSMTP$RCPT_TO$Packet(
  {
    to,
  }: ISMTP$RCPT_TO$Packet,
): Generator<u8, void, void> {
  yield CHAR_R;
  yield CHAR_C;
  yield CHAR_P;
  yield CHAR_T;

  yield CHAR_SPACE;

  yield CHAR_T;
  yield CHAR_O;

  yield CHAR_COLON;

  yield * encodeUint8Array(to);

  yield CHAR_CR;
  yield CHAR_LF;
}

