import { u8 } from '@lifaon/number-types';
import { ISMTP$AUTH_LOGIN_PASSWORD_RESPONSE$Packet } from './smtp-auth-login-password-response-packet.type';
import { encodeUTF8EncodedStringToBase64 } from '../../../../../../string/encode-utf8-encoded-string-to-base64';
import { CHAR_CR } from '../../../../../../chars/CR.constant';
import { CHAR_LF } from '../../../../../../chars/LF.constant';
import { encodeUint8Array } from '../../../../../../encoding/uint8-array/encode-uint8-array';


export function * encodeSMTP$AUTH_LOGIN_PASSWORD_RESPONSE$Packet(
  {
    password,
  }: ISMTP$AUTH_LOGIN_PASSWORD_RESPONSE$Packet,
): Generator<u8, void, void> {
  yield * encodeUint8Array(encodeUTF8EncodedStringToBase64(password));

  yield CHAR_CR;
  yield CHAR_LF;
}

