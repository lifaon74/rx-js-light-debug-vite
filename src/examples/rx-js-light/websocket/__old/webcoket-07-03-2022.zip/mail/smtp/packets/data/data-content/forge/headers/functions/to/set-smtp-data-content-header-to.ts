import { ISMTPDataContentHeaders } from '../../types/smtp-data-content-headers.type';
import { ISMTPDataContentHeaderToKeys } from './constants/smtp-data-content-header-to-keys.type';
import {
  IEmailAddressStringReadonlyArray,
} from '../../../../../../../../types/email-address-string/email-address-string-readonly-array.type';

export function setSMTPDataContentHeader$To$(
  headers: ISMTPDataContentHeaders,
  key: ISMTPDataContentHeaderToKeys,
  value: IEmailAddressStringReadonlyArray,
): void {
  headers.set(key, value.join(', '));
}


