export type ISMTPDataContentHeaders = Map<string, string>;
