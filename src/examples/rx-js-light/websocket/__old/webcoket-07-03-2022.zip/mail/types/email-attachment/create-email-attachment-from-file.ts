import { IEmailAttachment } from './email-attachment.type';
import { createEmailAttachmentFromBlob } from './create-email-attachment-from-blob';

export function createEmailAttachmentFromFile(
  file: File,
): Promise<IEmailAttachment> {
  return createEmailAttachmentFromBlob(file, file.name);
}
