import { IEmailContactOrEmailAddressString } from './email-contact-or-email-address-string.type';
import { IEmailAddressString } from '../email-address-string/email-address-string.type';

export function emailContactOrEmailAddressStringToEmailAddressString(
  input: IEmailContactOrEmailAddressString,
): IEmailAddressString {
  return (typeof input === 'string')
    ? input
    : input.email;
}
