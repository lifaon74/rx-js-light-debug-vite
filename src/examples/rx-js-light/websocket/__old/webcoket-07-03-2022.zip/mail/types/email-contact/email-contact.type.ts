import { IEmailAddressString } from '../email-address-string/email-address-string.type';

export interface IEmailContact {
  email: IEmailAddressString;
  name: string;
}

