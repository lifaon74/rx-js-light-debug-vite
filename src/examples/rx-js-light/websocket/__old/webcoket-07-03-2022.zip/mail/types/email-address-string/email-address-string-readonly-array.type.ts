import { IEmailAddressString } from './email-address-string.type';

export type IEmailAddressStringReadonlyArray = readonly IEmailAddressString[];

