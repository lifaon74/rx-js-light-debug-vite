import {
  IEmailAddressStringOrEmailAddressStringReadonlyArray
} from './email-address-string-or-email-address-string-readonly-array.type';
import { IEmailAddressStringReadonlyArray } from './email-address-string-readonly-array.type';

export function emailAddressStringOrEmailAddressStringReadonlyArrayToEmailAddressStringReadonlyArray(
  input: IEmailAddressStringOrEmailAddressStringReadonlyArray,
): IEmailAddressStringReadonlyArray {
  return (typeof input === 'string')
    ? [input]
    : input;
}

