import { IEmailAddressString } from './email-address-string.type';
import { IEmailAddressStringReadonlyArray } from './email-address-string-readonly-array.type';

export type IEmailAddressStringOrEmailAddressStringReadonlyArray =
  | IEmailAddressStringReadonlyArray
  | IEmailAddressString
  ;

