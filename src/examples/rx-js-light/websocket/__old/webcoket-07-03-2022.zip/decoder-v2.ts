import { u32, u8 } from '@lifaon/number-types';


export interface IBufferDecoderResultDone<GValue> {
  value: GValue;
  index: u32; // index at which the decoder stopped to read the data
}


export type IBufferDecoderResult<GValue> =
  | IBufferDecoderResultDone<GValue>
  | null // not done
  ;

export interface IBufferDecoder<GValue> {
  (
    buffer: Uint8Array,
    index: u32,
  ): IBufferDecoderResult<GValue>;
}


/*----------*/

export interface IEncoder<GValue> {
  (
    value: GValue,
    buffer: Uint8Array,
    index: u32,
  ): u32; // index at which the encoder stopped to write the data
}


/*----------*/

export function throwNotEnoughSpaceError(): never {
  throw new Error(`Not enough space`);
}

export function pushUint8Array(
  buffer: Uint8Array,
  index: u32,
  value: u8,
): number {
  if (index < buffer.length) {
    buffer[index] = value;
    return index + 1;
  } else {
    throwNotEnoughSpaceError();
  }
}

export function subarray(
  buffer: Uint8Array,
  index: u32,
): Uint8Array {
  return (index === 0)
    ? buffer
    : buffer.subarray(index);
}

/*----------*/

export function estimateStringToUTF8EncodedStringBufferSize(
  input: string,
): u32 {
  return input.length * 2;
}

export function stringToUTF8EncodedStringBufferEncoder(
  input: string,
  buffer: Uint8Array,
  index: u32,
): u32 {
  const { read, written }: TextEncoderEncodeIntoResult = new TextEncoder().encodeInto(
    input,
    subarray(buffer, index),
  );

  if (read === input.length) {
    return index + (written as u32);
  } else {
    throwNotEnoughSpaceError();
  }
}


export function utf8EncodedStringToStringBufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<string> {
  try {
    return {
      value: new TextDecoder('utf-8', { fatal: true }).decode(subarray(buffer, index)),
      index: buffer.length,
    };
  } catch {
    return null;
  }
}



