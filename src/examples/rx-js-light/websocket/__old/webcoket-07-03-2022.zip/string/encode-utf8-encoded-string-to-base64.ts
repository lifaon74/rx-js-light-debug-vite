import { IUTF8EncodedString } from './utf8-encoded-string.type';
import { encodeUint8ArrayToBase64 } from '../array-buffer/encode-uint8-array-to-base64';
import { utf8EncodedStringToString } from './utf8-encoded-string-to-string';
import { binaryStringToUint8Array } from './binary-string-to-uint8-array';


export function encodeUTF8EncodedStringToBase64(
  input: IUTF8EncodedString,
): Uint8Array {
  return encodeUint8ArrayToBase64(binaryStringToUint8Array(utf8EncodedStringToString(input)));
}

