export type IUTF8EncodedString = Uint8Array;
