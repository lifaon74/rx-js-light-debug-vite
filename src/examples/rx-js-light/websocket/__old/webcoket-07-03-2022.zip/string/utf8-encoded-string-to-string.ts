import { IUTF8EncodedString } from './utf8-encoded-string.type';

export function utf8EncodedStringToString(
  str: IUTF8EncodedString,
): string {
  return new TextDecoder().decode(str);
}
