import { IUTF8EncodedString } from './utf8-encoded-string.type';
import { stringToUTF8EncodedString } from './string-to-utf8-encoded-string';


export function toUTF8EncodedString(
  value: string | IUTF8EncodedString,
): IUTF8EncodedString {
  return (typeof value === 'string')
    ? stringToUTF8EncodedString(value)
    : value;
}
