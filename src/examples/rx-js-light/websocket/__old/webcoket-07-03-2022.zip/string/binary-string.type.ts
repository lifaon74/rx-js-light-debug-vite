export type IBinaryString = string;
