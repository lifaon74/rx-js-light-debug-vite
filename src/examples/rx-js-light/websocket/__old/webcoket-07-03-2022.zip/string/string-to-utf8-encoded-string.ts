import { IUTF8EncodedString } from './utf8-encoded-string.type';

export function stringToUTF8EncodedString(
  str: string,
): IUTF8EncodedString {
  return new TextEncoder().encode(str);
}
