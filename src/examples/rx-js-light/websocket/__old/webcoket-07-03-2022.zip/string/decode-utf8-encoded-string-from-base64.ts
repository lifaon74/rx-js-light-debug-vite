import { IUTF8EncodedString } from './utf8-encoded-string.type';
import { stringToUTF8EncodedString } from './string-to-utf8-encoded-string';
import { uint8ArrayToBinaryString } from './uint8-array-to-binary-string';
import { decodeUint8ArrayFromBase64 } from '../array-buffer/decode-uint8-array-from-base64';


export function decodeUTF8EncodedStringFromBase64(
  input: Uint8Array,
): IUTF8EncodedString {
  return stringToUTF8EncodedString(uint8ArrayToBinaryString(decodeUint8ArrayFromBase64(input)));
}

