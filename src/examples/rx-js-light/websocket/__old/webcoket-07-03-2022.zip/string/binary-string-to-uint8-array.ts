import { u8 } from '@lifaon/number-types';
import { IBinaryString } from './binary-string.type';

export function binaryStringToUint8Array(
  str: IBinaryString,
): Uint8Array {
  return Uint8Array.from(str, (char: string): u8  => {
    const _char: u8 = char.charCodeAt(0);
    if (_char > 0xff) {
      throw new Error(`Character out of range`);
    } else {
      return _char;
    }
  });
}
