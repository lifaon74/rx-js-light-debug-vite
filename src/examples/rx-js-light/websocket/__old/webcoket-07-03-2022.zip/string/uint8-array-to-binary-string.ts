import { IBinaryString } from './binary-string.type';

export function uint8ArrayToBinaryString(
  buffer: Uint8Array,
): IBinaryString {
  return String.fromCharCode(...buffer);
}
