import { IObserver, IObserverPipe } from '@lifaon/rx-js-light';
import { u8 } from '@lifaon/number-types';
import {
  IUint8ArrayToBufferedU8EmitPipeOptions, uint8ArrayToBufferedU8Observer,
} from './uint8-array-to-buffered-u8-observer';


export function uint8ArrayToBufferedU8ObserverPipe(
  options?: IUint8ArrayToBufferedU8EmitPipeOptions,
): IObserverPipe<u8, Uint8Array> {
  return (emit: IObserver<Uint8Array>): IObserver<u8> => {
    return uint8ArrayToBufferedU8Observer(emit, options);
  };
}

