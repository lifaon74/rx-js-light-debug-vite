import { IByteStream } from '../byte-stream/byte-stream.type';
import { IU8Stream } from './u8-stream.type';
import { freeze } from '@lifaon/rx-js-light';
import { uint8ArrayToBufferedU8Observer } from './helpers/uint8-array-to-buffered-u8-observer';
import { arrayBufferToU8Observable } from './helpers/array-buffer-to-u8-observable';


export function convertByteStreamToU8Stream(
  stream: IByteStream,
): IU8Stream {
  return freeze<IU8Stream>({
    emit: uint8ArrayToBufferedU8Observer(stream.emit),
    subscribe: arrayBufferToU8Observable(stream.subscribe),
  });
}
