import { IObservable, IObservablePipe } from '@lifaon/rx-js-light';
import { u8 } from '@lifaon/number-types';
import { arrayBufferToU8Observable } from './array-buffer-to-u8-observable';

export function arrayBufferToU8ObservablePipe(): IObservablePipe<ArrayBuffer, u8> {
  return (subscribe: IObservable<ArrayBuffer>): IObservable<u8> => {
    return arrayBufferToU8Observable(subscribe);
  };
}
