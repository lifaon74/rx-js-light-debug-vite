import { IStream } from '../stream.type';
import { u8 } from '@lifaon/number-types';

export type IU8Stream = IStream<u8, u8>;
