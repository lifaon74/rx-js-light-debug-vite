import { IObservable, IObserver, IUnsubscribe } from '@lifaon/rx-js-light';
import { u8 } from '@lifaon/number-types';

export function arrayBufferToU8Observable(
  subscribe: IObservable<ArrayBuffer>,
): IObservable<u8> {
  return (emit: IObserver<u8>): IUnsubscribe => {
    let running: boolean = true;

    const unsubscribe = subscribe((buffer: ArrayBuffer): void => {
      const data: Uint8Array = new Uint8Array(buffer);
      for (let i = 0, l = data.length; (i < l) && running; i++) {
        emit(data[i]);
      }
    });

    return (): void => {
      if (!running) {
        running = false;
        unsubscribe();
      }
    };
  };
}
