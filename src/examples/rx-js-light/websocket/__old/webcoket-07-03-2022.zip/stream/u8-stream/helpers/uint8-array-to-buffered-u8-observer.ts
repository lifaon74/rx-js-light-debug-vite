import { createTimeout, IAbortTimer, IObserver } from '@lifaon/rx-js-light';
import { u8 } from '@lifaon/number-types';

export interface IUint8ArrayToBufferedU8EmitPipeOptions {
  buffer?: Uint8Array;
  timeout?: number;
}

export function uint8ArrayToBufferedU8Observer(
  emit: IObserver<Uint8Array>,
  {
    buffer = new Uint8Array(2 ** 20), // 1MB
    timeout = 0,
  }: IUint8ArrayToBufferedU8EmitPipeOptions = {},
): IObserver<u8> {
  let bufferSize: number = 0;
  let abortTimeout: IAbortTimer | null = null;

  const emitBuffer = () => {
    emit(buffer.slice(0, bufferSize));
    bufferSize = 0;
  };

  return (value: u8): void => {
    if (bufferSize >= buffer.length) {
      emitBuffer();
    }
    buffer[bufferSize] = value;
    bufferSize++;
    if (abortTimeout === null) {
      abortTimeout = createTimeout(() => {
        abortTimeout = null;
        emitBuffer();
      }, timeout);
    }
  };
}
