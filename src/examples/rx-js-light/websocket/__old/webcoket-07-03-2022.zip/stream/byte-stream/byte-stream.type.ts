import { IStream } from '../stream.type';


export type IByteStreamIn = ArrayBuffer;
export type IByteStreamOut = Uint8Array;

export type IByteStream = IStream<IByteStreamIn, Uint8Array>;
