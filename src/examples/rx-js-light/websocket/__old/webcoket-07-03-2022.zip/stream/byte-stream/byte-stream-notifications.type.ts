import { IByteStream } from './byte-stream.type';
import { IStreamObservableNotifications } from '../stream-observable-notifications.type';

export type IByteStreamObservableNotifications<GClosedValue = unknown> =
  IStreamObservableNotifications<IByteStream, GClosedValue>;
