import { IByteStream } from './byte-stream.type';
import { IStreamObservable } from '../stream-observable.type';

export type IByteStreamObservable<GClosedValue = unknown> =
  IStreamObservable<IByteStream, GClosedValue>;
