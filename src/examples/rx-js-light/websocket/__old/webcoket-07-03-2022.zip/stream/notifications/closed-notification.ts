import { createNotification, INotification } from '@lifaon/rx-js-light';

export type IClosedNotification<GValue> = INotification<'closed', GValue>;

export function createClosedNotification<GValue>(
  value: GValue,
): IClosedNotification<GValue> {
  return createNotification('closed', value);
}
