import { createNotification, INotification } from '@lifaon/rx-js-light';

export type IOpenNotification<GValue> = INotification<'open', GValue>;

export function createOpenNotification<GValue>(
  value: GValue,
): IOpenNotification<GValue> {
  return createNotification('open', value);
}
