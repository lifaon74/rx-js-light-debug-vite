import { IOpenNotification } from './notifications/open-notification';
import { IClosedNotification } from './notifications/closed-notification';
import { IErrorNotification } from '@lifaon/rx-js-light';
import { IStream } from './stream.type';

export type IStreamObservableNotifications<GStream extends IStream<any, any>, GClosedValue = unknown> =
  | IOpenNotification<GStream>
  | IClosedNotification<GClosedValue>
  | IErrorNotification
  ;
