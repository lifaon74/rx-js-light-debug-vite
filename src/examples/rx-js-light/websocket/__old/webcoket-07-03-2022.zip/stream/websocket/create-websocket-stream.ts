import {
  createErrorNotification, freeze, fromEventTarget, IObserver, IUnsubscribe, map$$$, pipe$$,
} from '@lifaon/rx-js-light';
import { createClosedNotification } from '../notifications/closed-notification';
import { createOpenNotification } from '../notifications/open-notification';
import {
  IWebSocketInValue, IWebSocketOutValue, IWebSocketStream, IWebSocketStreamObservable,
  IWebSocketStreamObservableNotifications,
} from './web-socket-stream.type';


export interface IWebSocketFactory {
  (): WebSocket;
}

export function createWebSocketStream(
  createWebSocket: IWebSocketFactory,
): IWebSocketStreamObservable {
  return (emit: IObserver<IWebSocketStreamObservableNotifications>): IUnsubscribe => {
    type GWebSocketStream = IWebSocketStream;

    const socket: WebSocket = createWebSocket();

    if (socket.readyState === socket.CONNECTING) {
      const end = (): void => {
        unsubscribeToOpenEvent();
        unsubscribeToCloseEvent();
        unsubscribeToErrorEvent();
      };

      const open$ = fromEventTarget<'open', Event>(socket, 'open');
      const message$ = fromEventTarget<'message', MessageEvent<IWebSocketInValue>>(socket, 'message');
      const close$ = fromEventTarget<'close', CloseEvent>(socket, 'close');
      const error$ = fromEventTarget<'error', Event>(socket, 'error');

      const unsubscribeToOpenEvent = open$((): void => {
        unsubscribeToOpenEvent();

        const stream = freeze<GWebSocketStream>({
          emit: (value: IWebSocketOutValue): void => {
            socket.send(value);
          },
          subscribe: pipe$$(message$, [
            // logStateSubscribePipe<MessageEvent<ArrayBuffer>>('socket'),
            map$$$<MessageEvent<IWebSocketInValue>, IWebSocketInValue>((event: MessageEvent<IWebSocketInValue>): IWebSocketInValue => {
              return event.data;
            }),
            // share$$$<ArrayBuffer>(),
          ]),
        });

        emit(createOpenNotification<GWebSocketStream>(stream));
      });

      const unsubscribeToCloseEvent = close$((event: CloseEvent): void => {
        end();
        emit(createClosedNotification(event));
      });

      const unsubscribeToErrorEvent = error$((): void => {
        end();
        emit(createErrorNotification(new Error(`WebSocket Error`)));
      });

      return (): void => {
        if (
          (socket.readyState === socket.CONNECTING)
          || (socket.readyState === socket.OPEN)
        ) {
          end();
          socket.close();
        }
      };
    } else {
      throw new Error(`Socket should be in a CONNECTING state`);
    }
  };
}

