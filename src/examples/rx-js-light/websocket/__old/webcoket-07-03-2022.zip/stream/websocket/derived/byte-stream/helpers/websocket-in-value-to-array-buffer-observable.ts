import { IObservable, mapObservable } from '@lifaon/rx-js-light';
import { IWebSocketInValue } from '../../../web-socket-stream.type';

export function websocketInValueToArrayBufferObservable(
  subscribe: IObservable<IWebSocketInValue>,
): IObservable<ArrayBuffer> {
  return mapObservable<IWebSocketInValue, ArrayBuffer>(subscribe, (value: IWebSocketInValue): ArrayBuffer => {
    if (value instanceof ArrayBuffer) {
      return value;
    } else if (typeof value === 'string') {
      return new TextEncoder().encode(value).buffer;
    } else {
      throw new TypeError(`Unsupported type`);
    }
  });
}
