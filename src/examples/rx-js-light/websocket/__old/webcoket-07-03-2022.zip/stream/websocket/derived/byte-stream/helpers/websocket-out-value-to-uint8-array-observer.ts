import { IObserver, mapObserver } from '@lifaon/rx-js-light';
import { IWebSocketOutValue } from '../../../web-socket-stream.type';

export function websocketOutValueToUint8ArrayObserver(
  emit: IObserver<IWebSocketOutValue>,
): IObserver<Uint8Array> {
  return mapObserver<Uint8Array, IWebSocketOutValue>(emit, (value: Uint8Array): IWebSocketOutValue => {
    return value;
  });
}
