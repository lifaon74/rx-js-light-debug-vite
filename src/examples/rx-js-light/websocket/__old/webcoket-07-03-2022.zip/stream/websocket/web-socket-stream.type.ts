import { IStreamObservable } from '../stream-observable.type';
import { IStreamObservableNotifications } from '../stream-observable-notifications.type';
import { IStream } from '../stream.type';

export type IWebSocketInValue = string | Blob | ArrayBuffer;
export type IWebSocketOutValue = string | ArrayBufferLike | Blob | ArrayBufferView;
export type IWebSocketClosedValue = CloseEvent;

export type IWebSocketStream = IStream<IWebSocketInValue, IWebSocketOutValue>;

export type IWebSocketStreamObservable =
  IStreamObservable<IWebSocketStream, IWebSocketClosedValue>;

export type IWebSocketStreamObservableNotifications =
  IStreamObservableNotifications<IWebSocketStream, IWebSocketClosedValue>;
