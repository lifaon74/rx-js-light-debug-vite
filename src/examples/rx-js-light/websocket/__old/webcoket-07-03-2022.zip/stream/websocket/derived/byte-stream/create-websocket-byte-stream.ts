import { IByteStreamObservable } from '../../../byte-stream/byte-stream-observable.type';
import { mapObservable } from '@lifaon/rx-js-light';
import { IStreamObservableNotifications } from '../../../stream-observable-notifications.type';
import { IByteStream } from '../../../byte-stream/byte-stream.type';
import { IWebSocketClosedValue, IWebSocketStream } from '../../web-socket-stream.type';
import { convertWebsocketStreamToByteStream } from './convert-websocket-stream-to-byte-stream';
import { createOpenNotification } from '../../../notifications/open-notification';
import { createArrayBufferWebSocketStream } from '../../create-array-buffer-websocket-stream';


export type IWebSocketByteStreamObservable = IByteStreamObservable<IWebSocketClosedValue>;

export function createWebSocketByteStream(
  url: string,
  protocols?: string | string[],
): IWebSocketByteStreamObservable {
  type GIn = IStreamObservableNotifications<IWebSocketStream, IWebSocketClosedValue>;
  type GOut = IStreamObservableNotifications<IByteStream, IWebSocketClosedValue>;

  return mapObservable<GIn, GOut>(
    createArrayBufferWebSocketStream(url, protocols),
    (notification: GIn): GOut => {
      if (notification.name === 'open') {
        return createOpenNotification<IByteStream>(
          convertWebsocketStreamToByteStream(notification.value),
        );
      } else {
        return notification;
      }
    },
  );
}
