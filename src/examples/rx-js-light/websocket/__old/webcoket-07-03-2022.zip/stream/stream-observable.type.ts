import { IObservable } from '@lifaon/rx-js-light';
import { IStreamObservableNotifications } from './stream-observable-notifications.type';
import { IStream } from './stream.type';

export type IStreamObservable<GStream extends IStream<any, any>, GClosedValue = unknown> =
  IObservable<IStreamObservableNotifications<GStream, GClosedValue>>;
