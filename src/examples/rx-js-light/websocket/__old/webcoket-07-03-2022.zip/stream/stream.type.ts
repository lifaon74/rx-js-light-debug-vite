import { IObserverObservablePair } from '@lifaon/rx-js-light';


export type IStream<GInValue, GOutValue> = IObserverObservablePair<GOutValue, GInValue>;
