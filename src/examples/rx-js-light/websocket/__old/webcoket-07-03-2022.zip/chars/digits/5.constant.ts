export const CHAR_5 = 0x35; // '5'

