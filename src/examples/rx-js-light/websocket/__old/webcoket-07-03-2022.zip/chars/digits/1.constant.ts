export const CHAR_1 = 0x31; // '1'

