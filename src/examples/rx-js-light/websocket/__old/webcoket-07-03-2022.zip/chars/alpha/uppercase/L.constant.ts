export const CHAR_L = 0x4c; // 'L'

