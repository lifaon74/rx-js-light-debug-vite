export const CHAR_R = 0x52; // 'R'

