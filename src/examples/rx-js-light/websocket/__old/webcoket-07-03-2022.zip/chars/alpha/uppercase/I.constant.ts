export const CHAR_I = 0x49; // 'I'

