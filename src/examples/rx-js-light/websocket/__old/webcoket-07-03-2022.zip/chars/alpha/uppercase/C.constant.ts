export const CHAR_C = 0x43; // 'C'

