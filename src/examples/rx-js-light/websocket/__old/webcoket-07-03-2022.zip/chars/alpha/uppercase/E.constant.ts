export const CHAR_E = 0x45; // 'E'

