export const CHAR_P = 0x50; // 'P'

