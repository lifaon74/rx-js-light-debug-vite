https://www.rapidtables.com/code/text/ascii-table.html

''.charCodeAt(0).toString(16)
