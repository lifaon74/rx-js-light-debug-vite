export const CHAR_COLON = 0x3a; // ':'

