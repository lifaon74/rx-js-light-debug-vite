export const CHAR_CR = 0x0d; // '\r'

