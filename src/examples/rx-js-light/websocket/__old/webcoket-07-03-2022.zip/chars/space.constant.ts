export const CHAR_SPACE = 0x20; // ' '

