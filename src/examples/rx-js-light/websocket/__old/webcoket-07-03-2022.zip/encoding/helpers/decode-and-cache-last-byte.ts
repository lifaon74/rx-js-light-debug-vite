import { IDecoder } from '../types/decoder.type';
import { u8 } from '@lifaon/number-types';

export interface IDecodeAndCacheLastByteResult<GValue> {
  byte: u8;
  value: GValue;
}

export function * decodeAndCacheLastByte<GValue>(
  decoder: IDecoder<GValue>,
  byte: u8,
): Generator<void, IDecodeAndCacheLastByteResult<GValue>, u8> {
  let result: IteratorResult<void, GValue>;
  while (!(result = decoder.next(byte)).done) {
    byte = yield;
  }
  return {
    byte,
    value: result.value,
  };
}

