import { IDecoder } from '../types/decoder.type';
import { u8 } from '@lifaon/number-types';
import { decodeAndCacheLastByte, IDecodeAndCacheLastByteResult } from './decode-and-cache-last-byte';

export function * decodeAndCacheLastByteWithAPreviousByte<GValue>(
  decoder: IDecoder<GValue>,
  byte: u8,
): Generator<void, IDecodeAndCacheLastByteResult<GValue>, u8> {
  type _GValue = IDecodeAndCacheLastByteResult<GValue>;
  const _decoder: Generator<void, _GValue, u8> = decodeAndCacheLastByte<GValue>(decoder, byte);
  let result: IteratorResult<void, _GValue>;
  if (!(result = _decoder.next(byte)).done) {
    while (!(result = _decoder.next(byte)).done) {
      byte = yield;
    }
  }
  return result.value;
}

