import { IEncoder } from '../types/encoder.type';
import { u8 } from '../../../../../../../number-types/dist';
import { GrowableUint8Array } from '../../array-buffer/growable-uint8-array';

export function encodeInBuffer(
  encoder: IEncoder,
  data: Uint8Array = new Uint8Array(1e6),
): Uint8Array {
  let i: number = 0;
  let result: IteratorResult<u8, void>;
  while (!(result = encoder.next()).done) {
    data[i++] = result.value;
  }
  return data.subarray(0, i);
}


export function encodeInGrowableBuffer(
  encoder: IEncoder,
): Uint8Array {
  const buffer: GrowableUint8Array = new GrowableUint8Array();
  let result: IteratorResult<u8, void>;
  while (!(result = encoder.next()).done) {
    buffer.push(result.value);
  }
  return buffer.data;
}
