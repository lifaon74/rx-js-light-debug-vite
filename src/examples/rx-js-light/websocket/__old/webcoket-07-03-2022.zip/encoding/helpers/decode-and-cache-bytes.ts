import { IDecoder } from '../types/decoder.type';
import { GrowableUint8Array } from '../../array-buffer/growable-uint8-array';
import { u8 } from '@lifaon/number-types';

export interface IDecodeAndCacheBytesResult<GValue> {
  bytes: Uint8Array;
  value: GValue;
}

export function * decodeAndCacheBytes<GValue>(
  decoder: IDecoder<GValue>,
): Generator<void, IDecodeAndCacheBytesResult<GValue>, u8> {
  const bytes: GrowableUint8Array = new GrowableUint8Array();

  while (true) {
    const byte: u8 = yield;
    bytes.push(byte);
    const result: IteratorResult<void, GValue> = decoder.next(byte);
    if (result.done) {
      return {
        bytes: bytes.data,
        value: result.value,
      }
    }
  }
}

