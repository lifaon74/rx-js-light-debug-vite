import { u8 } from '@lifaon/number-types';

// export type IEncoder = Generator<void, u8, void>;

export type IEncoder = Iterator<u8, void, void>;

export interface IEncoderGenerator<GValue> {
  (value: GValue): IEncoder;
}
