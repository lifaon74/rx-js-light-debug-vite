import { u8 } from '@lifaon/number-types';

// export type IDecoder<GValue> = Generator<void, GValue, u8>;
export type IDecoder<GValue> = Iterator<void, GValue, u8>;

export interface IDecoderGenerator<GValue, GArguments extends any[] = any[]> {
  (...args: GArguments): Generator<void, GValue, u8>;
}


/*-------------*/

export type IInfiniteDecoder = Iterator<void, void, u8>;

export interface IInfiniteDecoderGeneratorCallback<GValue> {
  (value: GValue): void;
}

export interface IInfiniteDecoderGenerator<GValue, GArguments extends any[] = any[]> {
  (decoded: IInfiniteDecoderGeneratorCallback<GValue>, ...args: GArguments): IInfiniteDecoder;
}

