import { u8 } from '@lifaon/number-types';

export function * encodeUint8Array(
  value: Uint8Array,
): Generator<u8, void, void> {
  yield * (value as any);
}

