import { u32, u8 } from '@lifaon/number-types';

const BUFFER = new Uint8Array(2 ** 24); // 16M

export function * decodeUint8Array(
  length: u32, // [0, buffer.length]
  buffer: Uint8Array = BUFFER,
): Generator<void, Uint8Array, u8> {
  let i: number = 0;
  for (; i < length; i++) {
    buffer[i] = yield;
  }
  return buffer.slice(0, i);
}

