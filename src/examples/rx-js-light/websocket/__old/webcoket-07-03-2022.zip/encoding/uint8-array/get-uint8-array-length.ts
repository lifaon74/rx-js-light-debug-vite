export function getUint8ArrayLength(
  array: Uint8Array,
): number {
  return array.length;
}
