export const CHAR_DIVIDE = 0x2f; // '/'

