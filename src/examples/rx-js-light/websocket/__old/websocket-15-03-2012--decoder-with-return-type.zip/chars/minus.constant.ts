export const CHAR_MINUS = 0x2d; // '-'

