export const CHAR_AT_SIGN = 0x40; // '@'

