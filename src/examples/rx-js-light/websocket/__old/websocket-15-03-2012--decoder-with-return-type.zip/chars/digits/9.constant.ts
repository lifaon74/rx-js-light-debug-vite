export const CHAR_9 = 0x39; // '9'

