export const CHAR_8 = 0x38; // '8'

