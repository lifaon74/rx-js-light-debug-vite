export const CHAR_3 = 0x33; // '3'

