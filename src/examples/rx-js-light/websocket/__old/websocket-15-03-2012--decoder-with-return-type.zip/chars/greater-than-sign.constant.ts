export const CHAR_GREATER_THAN = 0x3e; // '>'

