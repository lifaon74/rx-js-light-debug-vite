export const CHAR_PLUS = 0x2b; // '+'

