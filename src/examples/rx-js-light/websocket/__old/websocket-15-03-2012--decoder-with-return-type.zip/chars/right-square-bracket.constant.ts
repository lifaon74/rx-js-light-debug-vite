export const CHAR_RIGHT_SQUARE_BRACKET = 0x5d; // ']'

