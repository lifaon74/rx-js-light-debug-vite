export const CHAR_y = 0x79; // 'y'

