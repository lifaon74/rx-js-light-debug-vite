export const CHAR_g = 0x67; // 'g'

