export const CHAR_W = 0x57; // 'W'

