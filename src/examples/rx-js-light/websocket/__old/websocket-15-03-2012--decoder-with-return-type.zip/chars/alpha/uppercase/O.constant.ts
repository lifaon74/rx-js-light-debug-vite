export const CHAR_O = 0x4f; // 'O'

