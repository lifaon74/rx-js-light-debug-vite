export const CHAR_A = 0x41; // 'A'

