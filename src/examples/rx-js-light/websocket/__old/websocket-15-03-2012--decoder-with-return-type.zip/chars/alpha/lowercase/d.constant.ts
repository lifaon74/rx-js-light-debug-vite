export const CHAR_d = 0x64; // 'd'

