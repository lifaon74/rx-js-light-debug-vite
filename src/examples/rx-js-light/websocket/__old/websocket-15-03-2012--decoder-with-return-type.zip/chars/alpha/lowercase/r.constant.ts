export const CHAR_r = 0x72; // 'r'

