export const CHAR_o = 0x6f; // 'o'

