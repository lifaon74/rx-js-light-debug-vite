export const CHAR_f = 0x66; // 'f'

