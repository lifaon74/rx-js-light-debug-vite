export const CHAR_p = 0x70; // 'p'

