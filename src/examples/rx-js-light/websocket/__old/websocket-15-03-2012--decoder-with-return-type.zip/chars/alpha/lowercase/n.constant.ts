export const CHAR_n = 0x6e; // 'n'

