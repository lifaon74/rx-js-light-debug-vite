export const CHAR_H = 0x48; // 'H'

