export const CHAR_V = 0x56; // 'V'

