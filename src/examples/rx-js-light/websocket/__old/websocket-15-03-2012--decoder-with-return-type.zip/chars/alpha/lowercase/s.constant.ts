export const CHAR_s = 0x73; // 's'

