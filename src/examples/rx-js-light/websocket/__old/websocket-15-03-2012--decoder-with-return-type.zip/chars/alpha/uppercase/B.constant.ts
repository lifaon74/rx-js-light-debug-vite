export const CHAR_B = 0x42; // 'B'

