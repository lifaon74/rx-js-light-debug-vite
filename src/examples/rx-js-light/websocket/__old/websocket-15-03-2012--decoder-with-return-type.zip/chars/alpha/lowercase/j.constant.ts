export const CHAR_j = 0x6a; // 'j'

