export const CHAR_i = 0x69; // 'i'

