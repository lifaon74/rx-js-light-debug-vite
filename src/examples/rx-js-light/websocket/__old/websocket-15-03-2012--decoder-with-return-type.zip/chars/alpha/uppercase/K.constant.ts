export const CHAR_K = 0x4b; // 'K'

