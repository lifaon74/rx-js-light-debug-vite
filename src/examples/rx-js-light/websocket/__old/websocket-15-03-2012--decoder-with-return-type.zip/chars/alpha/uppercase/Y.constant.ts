export const CHAR_Y = 0x59; // 'Y'

