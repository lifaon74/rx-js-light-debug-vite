import { u32, u8 } from '@lifaon/number-types';
import { IBufferDecoderResult } from '../types/buffer-decoder/result/buffer-decoder-result.type';
import {
  createBufferDecoderResultError,
} from '../types/buffer-decoder/result/error/create-buffer-decoder-result-error';
import { createExpectedByteError } from '../../errors/expected-byte/expected-byte-error';
import {
  BUFFER_DECODER_RESULT_NOT_ENOUGH_DATA,
} from '../types/buffer-decoder/result/not-enough-data/buffer-decoder-result-not-enough-data.constant';
import { createBufferDecoderResultDone } from '../types/buffer-decoder/result/done/create-buffer-decoder-result-done';


export function bufferDecoderExpects(
  data: ArrayLike<u8>,
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<void> {
  if (buffer.length >= (index + data.length)) {
    for (let i = 0; i < data.length; i++) {
      const byte: u8 = buffer[index++];
      if (byte !== data[i]) {
        return createBufferDecoderResultError(createExpectedByteError(data[i], byte));
      }
    }
    return createBufferDecoderResultDone<void>(
      void 0,
      index,
    );
  } else {
    return BUFFER_DECODER_RESULT_NOT_ENOUGH_DATA;
  }
}
