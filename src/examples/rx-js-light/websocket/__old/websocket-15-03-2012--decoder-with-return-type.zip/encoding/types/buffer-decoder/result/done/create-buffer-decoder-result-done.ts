import { u32 } from '@lifaon/number-types';
import { IBufferDecoderResultDone } from './buffer-decoder-result-done.type';

export function createBufferDecoderResultDone<GValue>(
  value: GValue,
  index: u32,
): IBufferDecoderResultDone<GValue> {
  return {
    state: 'done',
    value,
    index,
  };
}
