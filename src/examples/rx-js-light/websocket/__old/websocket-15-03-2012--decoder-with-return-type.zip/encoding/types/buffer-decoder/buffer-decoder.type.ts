import { u32 } from '@lifaon/number-types';
import { IBufferDecoderResult } from './result/buffer-decoder-result.type';


export interface IBufferDecoder<GValue> {
  (
    buffer: Uint8Array,
    index: u32,
  ): IBufferDecoderResult<GValue>;
}

