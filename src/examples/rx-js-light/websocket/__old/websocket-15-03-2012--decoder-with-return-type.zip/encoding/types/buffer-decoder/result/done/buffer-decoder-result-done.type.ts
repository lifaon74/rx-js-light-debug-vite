import { u32 } from '@lifaon/number-types';

export interface IBufferDecoderResultDone<GValue> {
  state: 'done';
  value: GValue;
  index: u32; // index at which the decoder stopped to read the data
}
