import { IBufferDecoderResultError } from './buffer-decoder-result-error.type';

export function createBufferDecoderResultError(
  error: unknown,
): IBufferDecoderResultError {
  return {
    state: 'error',
    error,
  };
}
