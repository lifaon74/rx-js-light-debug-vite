
export interface IEmailAttachment {
  name: string;
  type: string;
  content: Uint8Array;
}
