import { ASCIIString } from './ascii-string.class';

export const EMPTY_ASCII_STRING = ASCIIString.fromSafeBuffer(new Uint8Array());
