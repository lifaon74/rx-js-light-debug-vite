import { ASCIIString } from '../ascii-string/ascii-string.class';
import { Domain } from '../domain/domain.class';
import { u8 } from '@lifaon/number-types';
import { toHex } from '../../../misc/to-hex';

export class MessageId {

  static generate(
    domain: Domain,
    length: number = 16,
  ): MessageId {
    const left: string = Array.from(crypto.getRandomValues(new Uint8Array(length)), (byte: u8): string => {
      return toHex(byte, 2);
    }).join('');

    return new MessageId(
      ASCIIString.fromSafeString(left),
      domain.domain,
    );
  }

  readonly left: ASCIIString;
  readonly right: ASCIIString;

  protected constructor(
    left: ASCIIString,
    right: ASCIIString,
  ) {
    this.left = left;
    this.right = right;
  }
}
