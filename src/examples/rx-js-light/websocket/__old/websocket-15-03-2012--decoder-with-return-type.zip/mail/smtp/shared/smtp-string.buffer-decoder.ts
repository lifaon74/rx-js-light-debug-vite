import { u32, u8 } from '@lifaon/number-types';
import { IBufferDecoderResult } from '../../../encoding/types/buffer-decoder/result/buffer-decoder-result.type';
import {
  BUFFER_DECODER_RESULT_NOT_ENOUGH_DATA,
} from '../../../encoding/types/buffer-decoder/result/not-enough-data/buffer-decoder-result-not-enough-data.constant';
import {
  createBufferDecoderResultDone,
} from '../../../encoding/types/buffer-decoder/result/done/create-buffer-decoder-result-done';
import { ASCIIString } from '../../classes/ascii-string/ascii-string.class';

export interface IIsAllowedCharFunction {
  (
    byte: u8,
  ): boolean;
}

export function smtpStringBufferDecoder(
  isAllowedChar: IIsAllowedCharFunction,
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<ASCIIString> {
  const start: number = index;
  while (index < buffer.length) {
    const byte: u8 = buffer[index];
    if (isAllowedChar(byte)) {
      index++;
    } else {
      return createBufferDecoderResultDone<ASCIIString>(
        ASCIIString.fromSafeBuffer(buffer.subarray(start, index)),
        index,
      );
    }
  }
  return BUFFER_DECODER_RESULT_NOT_ENOUGH_DATA;
}
