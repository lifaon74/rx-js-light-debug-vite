import { ISMTP$AUTH_OK_RSP$Packet } from './smtp-auth-ok-rsp-packet.type';
import { CHAR_3 } from '../../../../../chars/digits/3.constant';
import { u32, u8 } from '@lifaon/number-types';
import { CHAR_2 } from '../../../../../chars/digits/2.constant';
import { CHAR_5 } from '../../../../../chars/digits/5.constant';
import { CHAR_SPACE } from '../../../../../chars/space.constant';
import { IBufferDecoderResult } from '../../../../../encoding/types/buffer-decoder/result/buffer-decoder-result.type';
import {
  createBufferDecoderResultDone,
} from '../../../../../encoding/types/buffer-decoder/result/done/create-buffer-decoder-result-done';
import { isNumericChar } from '../../../../../chars/is/is-numeric-char';
import { CHAR_DOT } from '../../../../../chars/dot.constant';
import { smtpStringBufferDecoder } from '../../../shared/smtp-string.buffer-decoder';
import { CHAR_CR } from '../../../../../chars/CR.constant';
import { CHAR_LF } from '../../../../../chars/LF.constant';
import { ASCIIString } from '../../../../classes/ascii-string/ascii-string.class';
import { EMPTY_ASCII_STRING } from '../../../../classes/ascii-string/empty-ascii-string.constant';
import { smtp$Code$BufferDecoder } from '../../../shared/smtp-code.buffer-decoder';
import { bufferDecoderExpectsCRLF } from '../../../../../encoding/functions/buffer-decoder-expects-crlf';

// https://www.rfc-editor.org/rfc/rfc4954.txt

export function smtp$AUTH_OK_RSP$PacketBufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<ISMTP$AUTH_OK_RSP$Packet> {

  // code
  {
    const result: IBufferDecoderResult<boolean> = smtp$AUTH_OK_RSP_CODE$BufferDecoder(buffer, index);
    if (result.state === 'done') {
      if (result.value) {
        throw new Error(`Unexpected multi line response`);
      }
      index = result.index;
    } else {
      return result;
    }
  }

  // version
  let version: ASCIIString;
  {
    const result: IBufferDecoderResult<ASCIIString> = smtp$AUTH_OK_RSP_VERSION$BufferDecoder(buffer, index);
    if (result.state === 'done') {
      version = result.value;
      index = result.index;
    } else {
      return result;
    }
  }


  // text
  let text: ASCIIString;
  if (buffer[index] === CHAR_SPACE) {
    const result: IBufferDecoderResult<ASCIIString> = smtp$AUTH_OK_RSP_TEXT$BufferDecoder(buffer, index + 1);
    if (result.state === 'done') {
      text = result.value;
      index = result.index;
    } else {
      return result;
    }
  } else {
    text = EMPTY_ASCII_STRING;
  }

  // CRLF
  {
    const result: IBufferDecoderResult<void> = bufferDecoderExpectsCRLF(buffer, index);
    if (result.state !== 'done') {
      return result;
    }
  }

  return createBufferDecoderResultDone<ISMTP$AUTH_OK_RSP$Packet>(
    {
      version,
      text,
    },
    index,
  );
}

/*---------------------*/

/* AUTH_OK_RSP_CODE*/

const AUTH_OK_RSP_CODE = new Uint8Array([
  CHAR_2,
  CHAR_3,
  CHAR_5,
]);

function smtp$AUTH_OK_RSP_CODE$BufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<boolean> {
  return smtp$Code$BufferDecoder(
    AUTH_OK_RSP_CODE,
    buffer,
    index,
  );
}

/* AUTH_OK_RSP_VERSION */

function smtp$AUTH_OK_RSP_VERSION$BufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<ASCIIString> {
  return smtpStringBufferDecoder(
    isSMTP$AUTH_OK_RSP_VERSION$Char,
    buffer,
    index,
  );
}

function isSMTP$AUTH_OK_RSP_VERSION$Char(
  byte: u8,
): boolean {
  return isNumericChar(byte)
    || (byte === CHAR_DOT);
}


/* AUTH_OK_RSP_TEXT */

function smtp$AUTH_OK_RSP_TEXT$BufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<ASCIIString> {
  return smtpStringBufferDecoder(
    isSMTP$AUTH_OK_RSP_TEXT$Char,
    buffer,
    index,
  );
}

function isSMTP$AUTH_OK_RSP_TEXT$Char(
  byte: u8,
): boolean {
  return (byte !== CHAR_CR)
    && (byte !== CHAR_LF);
}


