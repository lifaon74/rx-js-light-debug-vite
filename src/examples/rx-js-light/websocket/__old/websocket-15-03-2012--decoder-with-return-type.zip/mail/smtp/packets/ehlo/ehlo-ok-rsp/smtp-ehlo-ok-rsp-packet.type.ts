import { ASCIIString } from '../../../../classes/ascii-string/ascii-string.class';


export interface ISMTP$EHLO_OK_RSP$Packet {
  hostname: ASCIIString;
  greet: ASCIIString;
  lines: ISMTP$EHLO_OK_RSP$PacketLine[];
}


export interface ISMTP$EHLO_OK_RSP$PacketLine {
  keyword: ASCIIString;
  params: ASCIIString[];
}
