import { IUTF8EncodedString } from '../../../../../string/utf8-encoded-string.type';


export interface ISMTP$DATA_OK_RSP$Packet {
  text: IUTF8EncodedString;
}

