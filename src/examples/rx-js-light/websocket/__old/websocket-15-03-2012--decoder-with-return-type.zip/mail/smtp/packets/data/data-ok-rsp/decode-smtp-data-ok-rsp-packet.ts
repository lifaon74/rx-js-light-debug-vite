import { ISMTP$DATA_OK_RSP$Packet } from './smtp-data-ok-rsp-packet.type';
import { u8 } from '@lifaon/number-types';
import { CHAR_5 } from '../../../../../chars/digits/5.constant';
import { CHAR_SPACE } from '../../../../../chars/space.constant';
import { IUTF8EncodedString } from '../../../../../string/utf8-encoded-string.type';
import {
  decodeAndCacheLastByte, IDecodeAndCacheLastByteResult,
} from '../../../../../encoding/helpers/decode-and-cache-last-byte';
import { CHAR_3 } from '../../../../../chars/digits/3.constant';
import { CHAR_4 } from '../../../../../chars/digits/4.constant';
import { GrowableUint8Array } from '../../../../../array-buffer/growable-uint8-array';
import { CHAR_CR } from '../../../../../chars/CR.constant';
import { CHAR_LF } from '../../../../../chars/LF.constant';


export function * decodeSMTP$DATA_OK_RSP$Packet(): Generator<void, ISMTP$DATA_OK_RSP$Packet, u8> {

  let byte: u8;

  // code
  {
    const result: IDecodeAndCacheLastByteResult<void> = yield * decodeAndCacheLastByte<void>(
      decodeSMTP$DATA_OK_RSP_CODE(),
      0,
    );
    byte = result.byte;
  }

  // text
  let text: IUTF8EncodedString;
  {
    const result: IDecodeAndCacheLastByteResult<IUTF8EncodedString> = yield * decodeAndCacheLastByte<IUTF8EncodedString>(
      decodeSMTP$DATA_OK_RSP_TEXT$(),
      byte,
    );
    text = result.value;
    byte = result.byte;
  }

  if (byte !== CHAR_CR) {
    throw new Error(`Expected \\r`);
  }

  if ((byte = yield) !== CHAR_LF) {
    throw new Error(`Expected \\n`);
  }

  return {
    text,
  };
}


function * decodeSMTP$DATA_OK_RSP_CODE(): Generator<void, void, u8> {
  // 354
  let byte: u8;
  if ((byte = yield) !== CHAR_3) {
    throw new Error(`Expected 3, found: ${byte}`);
  }
  if ((byte = yield) !== CHAR_5) {
    throw new Error(`Expected 5, found: ${byte}`);
  }
  if ((byte = yield) !== CHAR_4) {
    throw new Error(`Expected 4, found: ${byte}`);
  }
  if ((byte = yield) !== CHAR_SPACE) {
    throw new Error(`Expected SPACE, found: ${byte}`);
  }
}

function * decodeSMTP$DATA_OK_RSP_TEXT$(): Generator<void, IUTF8EncodedString, u8> {
  const text: GrowableUint8Array = new GrowableUint8Array();
  let byte: u8;
  while (true) {
    byte = yield;
    if (
      (byte !== CHAR_CR)
      && (byte !== CHAR_LF)
    ) {
      text.push(byte);
    } else {
      return text.data;
    }
  }
}

