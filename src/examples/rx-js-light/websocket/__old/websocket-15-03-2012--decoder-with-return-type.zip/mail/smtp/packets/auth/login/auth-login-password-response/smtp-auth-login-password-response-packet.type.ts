import { ASCIIString } from '../../../../../classes/ascii-string/ascii-string.class';



export interface ISMTP$AUTH_LOGIN_PASSWORD_RESPONSE$Packet {
  password: ASCIIString;
}
