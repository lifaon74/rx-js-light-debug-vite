import { ISMTP$GREETING$Packet } from './smtp-greeting-packet.type';
import { u32 } from '@lifaon/number-types';
import { CHAR_2 } from '../../../../chars/digits/2.constant';
import { CHAR_0 } from '../../../../chars/digits/0.constant';
import { CHAR_SPACE } from '../../../../chars/space.constant';
import { IBufferDecoderResult } from '../../../../encoding/types/buffer-decoder/result/buffer-decoder-result.type';
import { smtp$Hostname$BufferDecoder } from '../../shared/smtp-hostname.buffer-decoder';
import {
  createBufferDecoderResultDone,
} from '../../../../encoding/types/buffer-decoder/result/done/create-buffer-decoder-result-done';
import { smtp$TextString$BufferDecoder } from '../../shared/smtp-textstring.buffer-decoder';
import { ASCIIString } from '../../../classes/ascii-string/ascii-string.class';
import { EMPTY_ASCII_STRING } from '../../../classes/ascii-string/empty-ascii-string.constant';
import { smtp$Code$BufferDecoder } from '../../shared/smtp-code.buffer-decoder';
import { bufferDecoderExpectsCRLF } from '../../../../encoding/functions/buffer-decoder-expects-crlf';

// https://datatracker.ietf.org/doc/html/rfc5321#section-4.2


export function smtp$GREETING$PacketBufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<ISMTP$GREETING$Packet> {

  // code
  let hasNextLine: boolean;
  {
    const result: IBufferDecoderResult<boolean> = smtp$GREETING_CODE$BufferDecoder(buffer, index);
    if (result.state === 'done') {
      hasNextLine = result.value;
      index = result.index;
    } else {
      return result;
    }
  }

  // TODO support hasNextLine

  // hostname
  let hostname: ASCIIString;
  {
    const result: IBufferDecoderResult<ASCIIString> = smtp$Hostname$BufferDecoder(buffer, index);
    if (result.state === 'done') {
      hostname = result.value;
      index = result.index;
    } else {
      return result;
    }
  }

  // text
  let text: ASCIIString;
  if (buffer[index] === CHAR_SPACE) {
    const result: IBufferDecoderResult<ASCIIString> = smtp$TextString$BufferDecoder(buffer, index + 1);
    if (result.state === 'done') {
      text = result.value;
      index = result.index;
    } else {
      return result;
    }
  } else {
    text = EMPTY_ASCII_STRING;
  }

  // CRLF
  {
    const result: IBufferDecoderResult<void> = bufferDecoderExpectsCRLF(buffer, index);
    if (result.state !== 'done') {
      return result;
    }
  }

  return createBufferDecoderResultDone<ISMTP$GREETING$Packet>(
    {
      hostname,
      text,
    },
    index,
  );
}

/*---------------------*/

const GREETING_CODE = new Uint8Array([
  CHAR_2,
  CHAR_2,
  CHAR_0,
]);

function smtp$GREETING_CODE$BufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<boolean> {
  return smtp$Code$BufferDecoder(
    GREETING_CODE,
    buffer,
    index,
  );
}
