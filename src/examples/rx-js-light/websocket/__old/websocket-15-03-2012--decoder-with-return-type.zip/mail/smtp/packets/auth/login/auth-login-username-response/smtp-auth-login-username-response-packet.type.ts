import { ASCIIString } from '../../../../../classes/ascii-string/ascii-string.class';

export interface ISMTP$AUTH_LOGIN_USERNAME_RESPONSE$Packet {
  username: ASCIIString;
}
