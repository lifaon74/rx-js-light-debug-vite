
headers: https://www.ietf.org/rfc/rfc2822.txt
body: https://www.ietf.org/rfc/rfc2045.txt
