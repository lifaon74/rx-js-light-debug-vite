import { u32 } from '@lifaon/number-types';
import { IBufferDecoderResult } from '../../../encoding/types/buffer-decoder/result/buffer-decoder-result.type';
import { CHAR_MINUS } from '../../../chars/minus.constant';
import {
  createBufferDecoderResultError,
} from '../../../encoding/types/buffer-decoder/result/error/create-buffer-decoder-result-error';
import { bufferDecoderExpects } from '../../../encoding/functions/buffer-decoder-expects';
import { CHAR_SPACE } from '../../../chars/space.constant';
import {
  createBufferDecoderResultDone,
} from '../../../encoding/types/buffer-decoder/result/done/create-buffer-decoder-result-done';
import { createExpectedOrBytesError } from '../../../errors/expected-byte/expected-byte-error';


export function smtp$Code$BufferDecoder(
  code: Uint8Array,
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<boolean> {
  const result: IBufferDecoderResult<void> = bufferDecoderExpects(
    code,
    buffer,
    index,
  );

  if (result.state === 'done') {
    index = result.index;
  } else {
    return result;
  }

  if (
    (buffer[index] === CHAR_SPACE)
    || (buffer[index] === CHAR_MINUS)
  ) {
    return createBufferDecoderResultDone<boolean>(
      (buffer[index] === CHAR_MINUS),
      index + 1,
    );
  } else {
    return createBufferDecoderResultError(createExpectedOrBytesError([CHAR_SPACE, CHAR_MINUS], buffer[index]));
  }
}

