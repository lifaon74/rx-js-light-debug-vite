export interface IBufferDecoderResultNotEnoughData {
  state: 'not-enough-data';
}
