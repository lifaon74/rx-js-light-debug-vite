import { IBufferDecoderResultNotEnoughData } from './buffer-decoder-result-not-enough-data.type';

export const BUFFER_DECODER_RESULT_NOT_ENOUGH_DATA: IBufferDecoderResultNotEnoughData = {
  state: 'not-enough-data',
};
