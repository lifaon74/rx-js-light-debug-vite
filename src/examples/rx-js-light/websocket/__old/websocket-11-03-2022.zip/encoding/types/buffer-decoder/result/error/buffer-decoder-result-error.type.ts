export interface IBufferDecoderResultError {
  state: 'error';
  error: unknown;
}
