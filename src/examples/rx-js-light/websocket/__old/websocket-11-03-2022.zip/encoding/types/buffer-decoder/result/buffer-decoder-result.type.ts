import { IBufferDecoderResultDone } from './done/buffer-decoder-result-done.type';
import { IBufferDecoderResultNotEnoughData } from './not-enough-data/buffer-decoder-result-not-enough-data.type';
import { IBufferDecoderResultError } from './error/buffer-decoder-result-error.type';

export type IBufferDecoderResult<GValue> =
  | IBufferDecoderResultDone<GValue>
  | IBufferDecoderResultNotEnoughData
  | IBufferDecoderResultError
  ;
