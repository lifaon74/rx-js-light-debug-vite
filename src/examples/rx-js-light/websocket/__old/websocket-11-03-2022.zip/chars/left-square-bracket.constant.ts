export const CHAR_LEFT_SQUARE_BRACKET = 0x5b; // '['

