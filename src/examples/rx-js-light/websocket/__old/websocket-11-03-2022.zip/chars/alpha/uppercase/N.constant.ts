export const CHAR_N = 0x4e; // 'N'

