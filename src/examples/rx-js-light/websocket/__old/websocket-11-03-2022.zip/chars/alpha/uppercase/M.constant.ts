export const CHAR_M = 0x4d; // 'M'

