export const CHAR_U = 0x55; // 'U'

