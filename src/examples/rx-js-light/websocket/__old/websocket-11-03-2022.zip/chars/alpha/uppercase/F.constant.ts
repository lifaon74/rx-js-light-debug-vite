export const CHAR_F = 0x46; // 'F'

