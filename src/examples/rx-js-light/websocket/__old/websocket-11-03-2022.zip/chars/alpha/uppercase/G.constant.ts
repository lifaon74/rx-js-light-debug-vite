export const CHAR_G = 0x47; // 'G'

