export const CHAR_2 = 0x32; // '2'

