export const CHAR_4 = 0x34; // '4'

