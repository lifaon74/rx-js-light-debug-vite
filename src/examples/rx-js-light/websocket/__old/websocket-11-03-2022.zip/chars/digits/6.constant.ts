export const CHAR_6 = 0x36; // '6'

