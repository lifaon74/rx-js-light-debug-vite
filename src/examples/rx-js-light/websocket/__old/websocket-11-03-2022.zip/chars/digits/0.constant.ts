export const CHAR_0 = 0x30; // '0'

