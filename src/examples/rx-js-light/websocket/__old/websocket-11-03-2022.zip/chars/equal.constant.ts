export const CHAR_EQUAL = 0x3d; // '='

