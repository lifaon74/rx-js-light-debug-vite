import { EmailAddress } from '../email-address/email-address.class';

export class EmailContact {
  readonly name: string;
  readonly address: EmailAddress;

  constructor(
    name: string,
    address: EmailAddress,
  ) {
    // TODO support quoted string and check name validity
    this.name = name;
    this.address = address;
  }

  toString(): string {
    return `${this.name} <${this.address.toString()}>`;
  }
}
