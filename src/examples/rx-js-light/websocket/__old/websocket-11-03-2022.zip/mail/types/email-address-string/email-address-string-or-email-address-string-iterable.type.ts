import { IEmailAddressStringIterable } from './email-address-string-iterable.type';
import { IEmailAddressString } from './email-address-string.type';

export type IEmailAddressStringOrEmailAddressString =
  | IEmailAddressString
  | IEmailAddressStringIterable
  ;

