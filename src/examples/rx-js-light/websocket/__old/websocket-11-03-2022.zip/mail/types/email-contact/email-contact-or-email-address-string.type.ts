import { IEmailContact } from './email-contact.type';
import { IEmailAddressString } from '../email-address-string/email-address-string.type';

export type IEmailContactOrEmailAddressString = IEmailContact | IEmailAddressString;
