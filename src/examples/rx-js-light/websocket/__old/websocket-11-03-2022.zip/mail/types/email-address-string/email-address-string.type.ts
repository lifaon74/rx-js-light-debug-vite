export type IEmailAddressString = string; // a pur email address

