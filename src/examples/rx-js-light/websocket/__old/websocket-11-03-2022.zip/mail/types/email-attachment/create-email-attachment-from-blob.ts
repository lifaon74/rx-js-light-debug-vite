import { IEmailAttachment } from './email-attachment.type';

export function createEmailAttachmentFromBlob(
  blob: Blob,
  name: string,
): Promise<IEmailAttachment> {
  return blob.arrayBuffer()
    .then((buffer: ArrayBuffer): IEmailAttachment => {
      return {
        name,
        type: blob.type,
        content: new Uint8Array(buffer),
      };
    });
}
