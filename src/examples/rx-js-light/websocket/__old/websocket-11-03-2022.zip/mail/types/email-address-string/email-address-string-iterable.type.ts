import { IEmailAddressString } from './email-address-string.type';

export type IEmailAddressStringIterable = Iterable<IEmailAddressString>;

