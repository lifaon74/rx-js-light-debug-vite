import { IBinaryStringBuffer } from '@lifaon/rx-js-light';



export interface ISMTP$AUTH_LOGIN_PASSWORD_RESPONSE$Packet {
  password: IBinaryStringBuffer;
}
