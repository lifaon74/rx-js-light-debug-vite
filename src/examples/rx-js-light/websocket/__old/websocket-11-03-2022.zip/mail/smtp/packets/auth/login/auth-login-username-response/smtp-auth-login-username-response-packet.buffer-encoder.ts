import { u32 } from '@lifaon/number-types';
import { ISMTP$AUTH_LOGIN_USERNAME_RESPONSE$Packet } from './smtp-auth-login-username-response-packet.type';
import { CHAR_CR } from '../../../../../../chars/CR.constant';
import { CHAR_LF } from '../../../../../../chars/LF.constant';
import { ensureUint8ArrayHasEnoughSpace } from '../../../../../../array-buffer/ensure-uint8-array-has-enough-space';
import { encodeUint8ArrayToBase64 } from '../../../../../../array-buffer/base64/encode-uint8-array-to-base64';


export function smtp$AUTH_LOGIN_USERNAME_RESPONSE$PacketBufferEncoder(
  {
    username,
  }: ISMTP$AUTH_LOGIN_USERNAME_RESPONSE$Packet,
  buffer: Uint8Array,
  index: u32,
): u32 {
  const base64Username: Uint8Array = encodeUint8ArrayToBase64(username);

  ensureUint8ArrayHasEnoughSpace(
    buffer,
    index,
    (
      base64Username.length
      + 2 // CRLF
    ),
  );

  buffer.set(base64Username, index);
  index += base64Username.length;

  buffer[index++] = CHAR_CR;
  buffer[index++] = CHAR_LF;

  return index;
}
