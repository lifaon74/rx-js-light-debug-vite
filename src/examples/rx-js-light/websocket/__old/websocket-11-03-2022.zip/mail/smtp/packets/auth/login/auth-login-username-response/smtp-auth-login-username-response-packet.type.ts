import { IBinaryStringBuffer } from '@lifaon/rx-js-light';

export interface ISMTP$AUTH_LOGIN_USERNAME_RESPONSE$Packet {
  username: IBinaryStringBuffer;
}
