import { u32 } from '@lifaon/number-types';
import { IStringUTF8EncodedStringBuffer, IUTF8EncodedStringBuffer, toUTF8EncodedString } from '@lifaon/rx-js-light';
import { smtpDataContentHeader$Date$BufferEncoder } from './headers/smtp-data-content-header-date.buffer-encoder';
import { IEmailAddressString } from '../../../../types/email-address-string/email-address-string.type';

export type IEmailAddressLike =
  | IEmailAddressString
  | IUTF8EncodedStringBuffer
  ;

export type IEmailAddressListLike =
  | IEmailAddressLike
  | Iterable<IEmailAddressLike>
  ;

export function emailAddressListLikeToEmailAddressBufferList(
  input: IEmailAddressListLike,
): IUTF8EncodedStringBuffer[] {
  if (
    (typeof input === 'string')
    || (input instanceof Uint8Array)
  ) {
    return [
      toUTF8EncodedString(input),
    ];
  } else {
    return Array.from(input, toUTF8EncodedString);
  }
}

export interface ISMTPDataContentOptionsLike {
  // messageId?: string;
  date?: Date | number; // (default: current date)
  // userAgent?: string;
  to: IEmailAddressListLike;
  // cc?: IEmailAddressStringOrEmailAddressStringReadonlyArray;
  // bcc?: IEmailAddressStringOrEmailAddressStringReadonlyArray;
  // replyTo?: IEmailAddressStringOrEmailAddressStringReadonlyArray;
  // from: IEmailContactOrEmailAddressString;
  // subject: string;
  text: IStringUTF8EncodedStringBuffer;
  // html?: string;
  // attachments?: readonly IEmailAttachment[];
}

export function prepareSMTPDataContentOptions(
  {
    date,
    to,
    text,
  }: ISMTPDataContentOptionsLike,
): ISMTPDataContentOptions {
  const _date: Date = (date === void 0)
    ? new Date()
    : (
      (typeof date === 'number')
        ? new Date(date)
        : date
    );

  const _to: IUTF8EncodedStringBuffer[] = emailAddressListLikeToEmailAddressBufferList(to);

  const _text: IUTF8EncodedStringBuffer = toUTF8EncodedString(text);

  return {
    date: _date,
    to: _to,
    text: _text,
  };
}

/*-----------------------------*/

export interface ISMTPDataContentOptions {
  // messageId?: string;
  date: Date;
  // userAgent?: string;
  to: IUTF8EncodedStringBuffer[];
  // cc?: IEmailAddressStringOrEmailAddressStringReadonlyArray;
  // bcc?: IEmailAddressStringOrEmailAddressStringReadonlyArray;
  // replyTo?: IEmailAddressStringOrEmailAddressStringReadonlyArray;
  // from: IEmailContactOrEmailAddressString;
  // subject: string;
  text: IUTF8EncodedStringBuffer;
  // html?: string;
  // attachments?: readonly IEmailAttachment[];
}

export function smtp$DataContent$BufferEncoder(
  {
    // messageId,
    date,
    // userAgent = '',
    // to,
    // cc = [],
    // bcc = [],
    // replyTo = [],
    // from,
    // subject,
    text,
    // html = '',
    // attachments = [],
  }: ISMTPDataContentOptions,
  buffer: Uint8Array,
  index: u32,
): u32 {

  index = smtpDataContentHeader$Date$BufferEncoder(date, buffer, index);

  // ensureUint8ArrayHasEnoughSpace(
  //   buffer,
  //   index,
  //   (
  //     6 // "Date:" SP
  //     + dateBuffer.length
  //     + 2 // CRLF
  //   ),
  // );
  //
  // buffer[index++] = CHAR_D;
  // buffer[index++] = CHAR_A;
  // buffer[index++] = CHAR_T;
  // buffer[index++] = CHAR_E;
  // buffer[index++] = CHAR_COLON;
  // buffer[index++] = CHAR_SPACE;
  //
  // buffer.set(dateBuffer, index);
  // index += dateBuffer.length;
  //
  // buffer[index++] = CHAR_CR;
  // buffer[index++] = CHAR_LF;

  return index;
}
