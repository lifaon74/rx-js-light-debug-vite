import { IUTF8EncodedStringBuffer } from '@lifaon/rx-js-light';

export interface ISMTP$EHLO$Packet {
  hostname: IUTF8EncodedStringBuffer;
}
