import { u32 } from '@lifaon/number-types';
import { ISMTP$AUT_LOGINH$Packet } from './smtp-auth-login-packet.type';
import { CHAR_A } from '../../../../../../chars/alpha/uppercase/A.constant';
import { CHAR_U } from '../../../../../../chars/alpha/uppercase/U.constant';
import { CHAR_T } from '../../../../../../chars/alpha/uppercase/T.constant';
import { CHAR_H } from '../../../../../../chars/alpha/uppercase/H.constant';
import { CHAR_SPACE } from '../../../../../../chars/space.constant';
import { CHAR_L } from '../../../../../../chars/alpha/uppercase/L.constant';
import { CHAR_O } from '../../../../../../chars/alpha/uppercase/O.constant';
import { CHAR_G } from '../../../../../../chars/alpha/uppercase/G.constant';
import { CHAR_I } from '../../../../../../chars/alpha/uppercase/I.constant';
import { CHAR_N } from '../../../../../../chars/alpha/uppercase/N.constant';
import { CHAR_CR } from '../../../../../../chars/CR.constant';
import { CHAR_LF } from '../../../../../../chars/LF.constant';
import { ensureUint8ArrayHasEnoughSpace } from '../../../../../../array-buffer/ensure-uint8-array-has-enough-space';

// https://datatracker.ietf.org/doc/html/rfc4954
// https://interoperability.blob.core.windows.net/files/MS-XLOGIN/%5BMS-XLOGIN%5D.pdf   => p.8

export function smtp$AUTH_LOGIN$PacketBufferEncoder(
  {
    username,
  }: ISMTP$AUT_LOGINH$Packet,
  buffer: Uint8Array,
  index: u32,
): u32 {
  ensureUint8ArrayHasEnoughSpace(
    buffer,
    index,
    (
      10 // "AUTH" SP "LOGIN"
      + ((username === void 0) ? 0 : username.length)
      + 2 // CRLF
    ),
  );

  buffer[index++] = CHAR_A;
  buffer[index++] = CHAR_U;
  buffer[index++] = CHAR_T;
  buffer[index++] = CHAR_H;

  buffer[index++] = CHAR_SPACE;

  buffer[index++] = CHAR_L;
  buffer[index++] = CHAR_O;
  buffer[index++] = CHAR_G;
  buffer[index++] = CHAR_I;
  buffer[index++] = CHAR_N;

  if (username !== void 0) {
    buffer.set(username, index);
    index += username.length;
  }

  buffer[index++] = CHAR_CR;
  buffer[index++] = CHAR_LF;

  return index;
}
