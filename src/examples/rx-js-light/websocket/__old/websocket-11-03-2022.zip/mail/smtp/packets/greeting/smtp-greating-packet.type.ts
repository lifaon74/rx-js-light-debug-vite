import { IReadonlyUTF8EncodedStringBuffer } from '@lifaon/rx-js-light';


export interface ISMTP$GREETING$Packet {
  hostname: IReadonlyUTF8EncodedStringBuffer;
  text: IReadonlyUTF8EncodedStringBuffer;
}

