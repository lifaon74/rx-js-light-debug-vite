import { ISMTP$EHLO_OK_RSP$Packet, ISMTP$EHLO_OK_RSP$PacketLine } from './smtp-ehlo-ok-rsp-packet.type';
import { u32, u8 } from '@lifaon/number-types';
import { CHAR_2 } from '../../../../../chars/digits/2.constant';
import { CHAR_5 } from '../../../../../chars/digits/5.constant';
import { CHAR_0 } from '../../../../../chars/digits/0.constant';
import { CHAR_SPACE } from '../../../../../chars/space.constant';
import { CHAR_MINUS } from '../../../../../chars/minus.constant';
import { CHAR_CR } from '../../../../../chars/CR.constant';
import { CHAR_LF } from '../../../../../chars/LF.constant';
import { IBufferDecoderResult } from '../../../../../encoding/types/buffer-decoder/result/buffer-decoder-result.type';
import {
  createBufferDecoderResultError,
} from '../../../../../encoding/types/buffer-decoder/result/error/create-buffer-decoder-result-error';
import {
  createExpectedByteError, createExpectedOrBytesError,
} from '../../../../../errors/expected-byte/expected-byte-error';
import { IReadonlyUTF8EncodedStringBuffer, IUTF8EncodedStringBuffer } from '@lifaon/rx-js-light';
import { smtp$Hostname$BufferDecoder } from '../../../shared/smtp-hostname.buffer-decoder';
import {
  createBufferDecoderResultDone,
} from '../../../../../encoding/types/buffer-decoder/result/done/create-buffer-decoder-result-done';
import { smtpStringBufferDecoder } from '../../../shared/smtp-string.buffer-decoder';
import { isAlphaNumericChar } from '../../../../../chars/is/is-alpha-numeric-char';


// https://datatracker.ietf.org/doc/html/rfc5321#section-4.1.1.1

export function smtp$EHLO_OK_RSP$PacketBufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<ISMTP$EHLO_OK_RSP$Packet> {
  let hasNextLine: boolean;

  // code
  {
    const result: IBufferDecoderResult<boolean> = smtp$EHLO_OK_RSP_CODE$BufferDecoder(buffer, index);
    if (result.state === 'done') {
      hasNextLine = result.value;
      index = result.index;
    } else {
      return result;
    }
  }

  // hostname
  let hostname: IReadonlyUTF8EncodedStringBuffer;
  {
    const result: IBufferDecoderResult<IReadonlyUTF8EncodedStringBuffer> = smtp$Hostname$BufferDecoder(buffer, index);
    if (result.state === 'done') {
      hostname = result.value;
      index = result.index;
    } else {
      return result;
    }
  }

  // greet
  let greet: IReadonlyUTF8EncodedStringBuffer;
  if (buffer[index] === CHAR_SPACE) {
    const result: IBufferDecoderResult<IReadonlyUTF8EncodedStringBuffer> = smtp$EHLO_GREET$BufferDecoder(buffer, index + 1);
    if (result.state === 'done') {
      greet = result.value;
      index = result.index;
    } else {
      return result;
    }
  } else {
    greet = new Uint8Array();
  }

  // \r\n
  {
    if (buffer[index] === CHAR_CR) {
      index++;
    } else {
      return createBufferDecoderResultError(createExpectedByteError(CHAR_CR, buffer[index]));
    }

    if (buffer[index] === CHAR_LF) {
      index++;
    } else {
      return createBufferDecoderResultError(createExpectedByteError(CHAR_LF, buffer[index]));
    }
  }

  // lines
  const lines: ISMTP$EHLO_OK_RSP$PacketLine[] = [];
  while (hasNextLine) {
    // code
    {
      const result: IBufferDecoderResult<boolean> = smtp$EHLO_OK_RSP_CODE$BufferDecoder(buffer, index);
      if (result.state === 'done') {
        hasNextLine = result.value;
        index = result.index;
      } else {
        return result;
      }
    }

    // line
    {
      const result: IBufferDecoderResult<ISMTP$EHLO_OK_RSP$PacketLine> = smtp$EHLO_LINE$BufferDecoder(buffer, index);
      if (result.state === 'done') {
        lines.push(result.value);
        index = result.index;
      } else {
        return result;
      }
    }

    // \r\n
    {
      if (buffer[index] === CHAR_CR) {
        index++;
      } else {
        return createBufferDecoderResultError(createExpectedByteError(CHAR_CR, buffer[index]));
      }

      if (buffer[index] === CHAR_LF) {
        index++;
      } else {
        return createBufferDecoderResultError(createExpectedByteError(CHAR_LF, buffer[index]));
      }
    }
  }

  return createBufferDecoderResultDone<ISMTP$EHLO_OK_RSP$Packet>(
    {
      hostname,
      greet,
      lines,
    },
    index,
  );
}

/*---------------------*/

/* EHLO_OK_RSP_CODE */

function smtp$EHLO_OK_RSP_CODE$BufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<boolean> {
  if (buffer[index] === CHAR_2) {
    index++;
  } else {
    return createBufferDecoderResultError(createExpectedByteError(CHAR_2, buffer[index]));
  }

  if (buffer[index] === CHAR_5) {
    index++;
  } else {
    return createBufferDecoderResultError(createExpectedByteError(CHAR_5, buffer[index]));
  }

  if (buffer[index] === CHAR_0) {
    index++;
  } else {
    return createBufferDecoderResultError(createExpectedByteError(CHAR_0, buffer[index]));
  }

  if (
    (buffer[index] === CHAR_SPACE)
    || (buffer[index] === CHAR_MINUS)
  ) {
    return createBufferDecoderResultDone<boolean>(
      (buffer[index] === CHAR_MINUS),
      index,
    );
  } else {
    return createBufferDecoderResultError(createExpectedOrBytesError([CHAR_SPACE, CHAR_MINUS], buffer[index]));
  }
}


/* EHLO_GREET */

function smtp$EHLO_GREET$BufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<IReadonlyUTF8EncodedStringBuffer> {
  return smtpStringBufferDecoder(
    isSMTP$EHLO_GREET$Char,
    buffer,
    index,
  );
}

function isSMTP$EHLO_GREET$Char(
  byte: u8,
): boolean {
  return (byte === 9)
    || ((32 <= byte) && (byte <= 126));
}

/* EHLO_LINE */

function smtp$EHLO_LINE$BufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<ISMTP$EHLO_OK_RSP$PacketLine> {

  // keyword
  let keyword: IReadonlyUTF8EncodedStringBuffer;
  {
    const result: IBufferDecoderResult<IReadonlyUTF8EncodedStringBuffer> = smtp$EHLO_KEYWORD$BufferDecoder(buffer, index);
    if (result.state === 'done') {
      keyword = result.value;
      index = result.index;
    } else {
      return result;
    }
  }

  // params
  const params: IUTF8EncodedStringBuffer[] = [];
  while (buffer[index] === CHAR_SPACE) {
    index++;
    // param
    const result: IBufferDecoderResult<IReadonlyUTF8EncodedStringBuffer> = smtp$EHLO_PARAM$BufferDecoder(buffer, index);
    if (result.state === 'done') {
      params.push(result.value);
      index = result.index;
    } else {
      return result;
    }
  }

  return createBufferDecoderResultDone<ISMTP$EHLO_OK_RSP$PacketLine>(
    {
      keyword,
      params,
    },
    index,
  );
}

/* EHLO_KEYWORD */

function smtp$EHLO_KEYWORD$BufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<IReadonlyUTF8EncodedStringBuffer> {
  return smtpStringBufferDecoder(
    isSMTP$EHLO_KEYWORD$Char,
    buffer,
    index,
  );
}

function isSMTP$EHLO_KEYWORD$Char(
  byte: u8,
): boolean {
  return isAlphaNumericChar(byte)
    || (byte === CHAR_MINUS);
}

/* EHLO_PARAM */

function smtp$EHLO_PARAM$BufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<IReadonlyUTF8EncodedStringBuffer> {
  const result: IBufferDecoderResult<IReadonlyUTF8EncodedStringBuffer> = smtpStringBufferDecoder(
    isSMTP$EHLO_PARAM$Char,
    buffer,
    index,
  );

  if (result.state === 'done') {
    if (result.value.length === 0) {
      return createBufferDecoderResultError(new Error(`Param can't be empty`));
    } else {
      return result;
    }
  } else {
    return result;
  }
}

function isSMTP$EHLO_PARAM$Char(
  byte: u8,
): boolean {
  return ((33 <= byte) && (byte <= 126));
}

