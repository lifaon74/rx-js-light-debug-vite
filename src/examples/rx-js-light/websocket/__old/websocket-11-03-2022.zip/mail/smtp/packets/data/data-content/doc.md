https://www.ietf.org/rfc/rfc2822.txt
