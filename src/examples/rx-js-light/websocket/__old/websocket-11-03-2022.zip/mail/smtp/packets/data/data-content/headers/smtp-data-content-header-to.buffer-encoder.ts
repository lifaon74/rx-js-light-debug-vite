import { u32 } from '@lifaon/number-types';
import { IUTF8EncodedStringBuffer, stringToUTF8EncodedString } from '@lifaon/rx-js-light';
import { ensureUint8ArrayHasEnoughSpace } from '../../../../../../array-buffer/ensure-uint8-array-has-enough-space';
import { CHAR_E } from '../../../../../../chars/alpha/uppercase/E.constant';
import { CHAR_COLON } from '../../../../../../chars/colon.constant';
import { CHAR_D } from '../../../../../../chars/alpha/uppercase/D.constant';
import { CHAR_T } from '../../../../../../chars/alpha/uppercase/T.constant';
import { CHAR_CR } from '../../../../../../chars/CR.constant';
import { CHAR_A } from '../../../../../../chars/alpha/uppercase/A.constant';
import { CHAR_LF } from '../../../../../../chars/LF.constant';
import { CHAR_SPACE } from '../../../../../../chars/space.constant';
import { EmailContact } from '../../../../../classes/email-contact/email-contact.class';
import { EmailAddress } from '../../../../../classes/email-address/email-address.class';

export function smtpDataContentHeader$To$BufferEncoder(
  to: ArrayLike<IUTF8EncodedStringBuffer>,
  key: IUTF8EncodedStringBuffer, // To, Cc, Bcc, etc...
  buffer: Uint8Array,
  index: u32,
): u32 {
  // TODO continue here
  const dateBuffer: IUTF8EncodedStringBuffer = stringToUTF8EncodedString(date.toString());

  ensureUint8ArrayHasEnoughSpace(
    buffer,
    index,
    (
      6 // "Date:" SP
      + dateBuffer.length
      + 2 // CRLF
    ),
  );

  buffer[index++] = CHAR_D;
  buffer[index++] = CHAR_A;
  buffer[index++] = CHAR_T;
  buffer[index++] = CHAR_E;
  buffer[index++] = CHAR_COLON;
  buffer[index++] = CHAR_SPACE;

  buffer.set(dateBuffer, index);
  index += dateBuffer.length;

  buffer[index++] = CHAR_CR;
  buffer[index++] = CHAR_LF;

  return index;
}

export function smtpDataContentHeader$AddressList$BufferEncoder(
  addressList: ArrayLike<EmailContact | EmailAddress>,
  buffer: Uint8Array,
  index: u32,
): u32 {
  // TODO continue here

  return index;
}
