import { u32, u8 } from '@lifaon/number-types';
import { IBufferDecoderResult } from '../../../encoding/types/buffer-decoder/result/buffer-decoder-result.type';
import { IReadonlyUTF8EncodedStringBuffer } from '@lifaon/rx-js-light';
import { smtpStringBufferDecoder } from './smtp-string.buffer-decoder';

export function smtp$TextString$BufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<IReadonlyUTF8EncodedStringBuffer> {
  return smtpStringBufferDecoder(
    isSMTP$TextString$Char,
    buffer,
    index,
  );
}

function isSMTP$TextString$Char(
  byte: u8,
): boolean {
  return (byte === 9)
    || ((32 <= byte) && (byte <= 126));
}


