import { u32 } from '@lifaon/number-types';
import { CHAR_CR } from '../../../../../../chars/CR.constant';
import { CHAR_LF } from '../../../../../../chars/LF.constant';
import { encodeUint8ArrayToBase64 } from '../../../../../../array-buffer/base64/encode-uint8-array-to-base64';
import { ensureUint8ArrayHasEnoughSpace } from '../../../../../../array-buffer/ensure-uint8-array-has-enough-space';
import { ISMTP$AUTH_LOGIN_PASSWORD_RESPONSE$Packet } from './smtp-auth-login-password-response-packet.type';


export function smtp$AUTH_LOGIN_PASSWORD_RESPONSE$PacketBufferEncoder(
  {
    password,
  }: ISMTP$AUTH_LOGIN_PASSWORD_RESPONSE$Packet,
  buffer: Uint8Array,
  index: u32,
): u32 {
  const base64Password: Uint8Array = encodeUint8ArrayToBase64(password);

  ensureUint8ArrayHasEnoughSpace(
    buffer,
    index,
    (
      base64Password.length
      + 2 // CRLF
    ),
  );

  buffer.set(base64Password, index);
  index += base64Password.length;

  buffer[index++] = CHAR_CR;
  buffer[index++] = CHAR_LF;

  return index;
}
