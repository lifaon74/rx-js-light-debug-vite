import { IUTF8EncodedStringBuffer } from '@lifaon/rx-js-light';

export interface ISMTP$AUT_LOGINH$Packet {
  username?: IUTF8EncodedStringBuffer;
}
