import { u32, u8 } from '@lifaon/number-types';
import { IBufferDecoderResult } from '../../../encoding/types/buffer-decoder/result/buffer-decoder-result.type';
import { IReadonlyUTF8EncodedStringBuffer } from '@lifaon/rx-js-light';
import {
  BUFFER_DECODER_RESULT_NOT_ENOUGH_DATA,
} from '../../../encoding/types/buffer-decoder/result/not-enough-data/buffer-decoder-result-not-enough-data.constant';
import {
  createBufferDecoderResultDone,
} from '../../../encoding/types/buffer-decoder/result/done/create-buffer-decoder-result-done';

export interface IIsAllowedCharFunction {
  (
    byte: u8,
  ): boolean;
}

export function smtpStringBufferDecoder(
  isAllowedChar: IIsAllowedCharFunction,
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<IReadonlyUTF8EncodedStringBuffer> {
  const start: number = index;
  while (index < buffer.length) {
    const byte: u8 = buffer[index];
    if (isAllowedChar(byte)) {
      index++;
    } else {
      return createBufferDecoderResultDone<IReadonlyUTF8EncodedStringBuffer>(
        buffer.subarray(start, index),
        index,
      );
    }
  }
  return BUFFER_DECODER_RESULT_NOT_ENOUGH_DATA;
}
