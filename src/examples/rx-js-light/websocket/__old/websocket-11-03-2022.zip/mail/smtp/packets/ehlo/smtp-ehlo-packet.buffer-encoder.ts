import { u32 } from '@lifaon/number-types';
import { ISMTP$EHLO$Packet } from './smtp-ehlo-packet.type';
import { CHAR_E } from '../../../../chars/alpha/uppercase/E.constant';
import { CHAR_H } from '../../../../chars/alpha/uppercase/H.constant';
import { CHAR_L } from '../../../../chars/alpha/uppercase/L.constant';
import { CHAR_O } from '../../../../chars/alpha/uppercase/O.constant';
import { CHAR_SPACE } from '../../../../chars/space.constant';
import { CHAR_CR } from '../../../../chars/CR.constant';
import { CHAR_LF } from '../../../../chars/LF.constant';
import { ensureUint8ArrayHasEnoughSpace } from '../../../../array-buffer/ensure-uint8-array-has-enough-space';

// https://datatracker.ietf.org/doc/html/rfc5321#section-4.1.1.1

export function smtp$EHLO$PacketBufferEncoder(
  {
    hostname,
  }: ISMTP$EHLO$Packet,
  buffer: Uint8Array,
  index: u32,
): u32 {
  ensureUint8ArrayHasEnoughSpace(
    buffer,
    index,
    (
      5 // "EHLO" SP
      + hostname.length
      + 2 // CRLF
    ),
  );

  buffer[index++] = CHAR_E;
  buffer[index++] = CHAR_H;
  buffer[index++] = CHAR_L;
  buffer[index++] = CHAR_O;

  buffer[index++] = CHAR_SPACE;

  buffer.set(hostname, index);
  index += hostname.length;

  buffer[index++] = CHAR_CR;
  buffer[index++] = CHAR_LF;

  return index;
}
