import { IUTF8EncodedStringBuffer } from '@lifaon/rx-js-light';

export interface ISMTP$AUTH_OK_RSP$Packet {
  version: IUTF8EncodedStringBuffer;
  text: IUTF8EncodedStringBuffer;
}


