import { ISMTP$AUTH_OK_RSP$Packet } from './smtp-auth-ok-rsp-packet.type';
import { CHAR_3 } from '../../../../../chars/digits/3.constant';
import { u32, u8 } from '@lifaon/number-types';
import { CHAR_2 } from '../../../../../chars/digits/2.constant';
import { CHAR_5 } from '../../../../../chars/digits/5.constant';
import { CHAR_SPACE } from '../../../../../chars/space.constant';
import { IBufferDecoderResult } from '../../../../../encoding/types/buffer-decoder/result/buffer-decoder-result.type';
import {
  createBufferDecoderResultError,
} from '../../../../../encoding/types/buffer-decoder/result/error/create-buffer-decoder-result-error';
import { createExpectedByteError } from '../../../../../errors/expected-byte/expected-byte-error';
import {
  createBufferDecoderResultDone,
} from '../../../../../encoding/types/buffer-decoder/result/done/create-buffer-decoder-result-done';
import { isNumericChar } from '../../../../../chars/is/is-numeric-char';
import { CHAR_DOT } from '../../../../../chars/dot.constant';
import { IReadonlyUTF8EncodedStringBuffer } from '../../../../../../../../../../rx-js-light/dist';
import { smtpStringBufferDecoder } from '../../../shared/smtp-string.buffer-decoder';
import { CHAR_CR } from '../../../../../chars/CR.constant';
import { CHAR_LF } from '../../../../../chars/LF.constant';

// https://www.rfc-editor.org/rfc/rfc4954.txt

export function smtp$AUTH_OK_RSP$PacketBufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<ISMTP$AUTH_OK_RSP$Packet> {

  // code
  {
    const result: IBufferDecoderResult<void> = smtp$AUTH_OK_RSP_CODE$BufferDecoder(buffer, index);
    if (result.state === 'done') {
      index = result.index;
    } else {
      return result;
    }
  }

  // version
  let version: IReadonlyUTF8EncodedStringBuffer;
  {
    const result: IBufferDecoderResult<IReadonlyUTF8EncodedStringBuffer> = smtp$AUTH_OK_RSP_VERSION$BufferDecoder(buffer, index);
    if (result.state === 'done') {
      version = result.value;
      index = result.index;
    } else {
      return result;
    }
  }


  // text
  let text: IReadonlyUTF8EncodedStringBuffer;
  if (buffer[index] === CHAR_SPACE) {
    const result: IBufferDecoderResult<IReadonlyUTF8EncodedStringBuffer> = smtp$AUTH_OK_RSP_TEXT$BufferDecoder(buffer, index + 1);
    if (result.state === 'done') {
      text = result.value;
      index = result.index;
    } else {
      return result;
    }
  } else {
    text = new Uint8Array();
  }

  // \r\n
  {
    if (buffer[index] === CHAR_CR) {
      index++;
    } else {
      return createBufferDecoderResultError(createExpectedByteError(CHAR_CR, buffer[index]));
    }

    if (buffer[index] === CHAR_LF) {
      index++;
    } else {
      return createBufferDecoderResultError(createExpectedByteError(CHAR_LF, buffer[index]));
    }
  }

  return createBufferDecoderResultDone<ISMTP$AUTH_OK_RSP$Packet>(
    {
      version,
      text,
    },
    index,
  );
}

/*---------------------*/

/* AUTH_OK_RSP_CODE*/

function smtp$AUTH_OK_RSP_CODE$BufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<void> {

  if (buffer[index] === CHAR_2) {
    index++;
  } else {
    return createBufferDecoderResultError(createExpectedByteError(CHAR_2, buffer[index]));
  }

  if (buffer[index] === CHAR_3) {
    index++;
  } else {
    return createBufferDecoderResultError(createExpectedByteError(CHAR_3, buffer[index]));
  }

  if (buffer[index] === CHAR_5) {
    index++;
  } else {
    return createBufferDecoderResultError(createExpectedByteError(CHAR_5, buffer[index]));
  }

  if (buffer[index] === CHAR_SPACE) {
    index++;
  } else {
    return createBufferDecoderResultError(createExpectedByteError(CHAR_SPACE, buffer[index]));
  }

  return createBufferDecoderResultDone<void>(
    void 0,
    index,
  );
}

/* AUTH_OK_RSP_VERSION */

function smtp$AUTH_OK_RSP_VERSION$BufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<IReadonlyUTF8EncodedStringBuffer> {
  return smtpStringBufferDecoder(
    isSMTP$AUTH_OK_RSP_VERSION$Char,
    buffer,
    index,
  );
}

function isSMTP$AUTH_OK_RSP_VERSION$Char(
  byte: u8,
): boolean {
  return isNumericChar(byte)
    || (byte === CHAR_DOT);
}


/* AUTH_OK_RSP_TEXT */

function smtp$AUTH_OK_RSP_TEXT$BufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<IReadonlyUTF8EncodedStringBuffer> {
  return smtpStringBufferDecoder(
    isSMTP$AUTH_OK_RSP_TEXT$Char,
    buffer,
    index,
  );
}

function isSMTP$AUTH_OK_RSP_TEXT$Char(
  byte: u8,
): boolean {
  return (byte !== CHAR_CR)
    && (byte !== CHAR_LF);
}


