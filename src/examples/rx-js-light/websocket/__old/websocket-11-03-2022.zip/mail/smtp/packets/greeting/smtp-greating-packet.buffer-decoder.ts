import { ISMTP$GREETING$Packet } from './smtp-greating-packet.type';
import { u32 } from '@lifaon/number-types';
import { CHAR_2 } from '../../../../chars/digits/2.constant';
import { CHAR_0 } from '../../../../chars/digits/0.constant';
import { CHAR_SPACE } from '../../../../chars/space.constant';
import { CHAR_LF } from '../../../../chars/LF.constant';
import { IBufferDecoderResult } from '../../../../encoding/types/buffer-decoder/result/buffer-decoder-result.type';
import {
  createBufferDecoderResultError,
} from '../../../../encoding/types/buffer-decoder/result/error/create-buffer-decoder-result-error';
import {
  createExpectedByteError, createExpectedOrBytesError,
} from '../../../../errors/expected-byte/expected-byte-error';
import { CHAR_MINUS } from '../../../../chars/minus.constant';
import { smtp$Hostname$BufferDecoder } from '../../shared/smtp-hostname.buffer-decoder';
import { IReadonlyUTF8EncodedStringBuffer } from '@lifaon/rx-js-light';
import {
  createBufferDecoderResultDone,
} from '../../../../encoding/types/buffer-decoder/result/done/create-buffer-decoder-result-done';
import { CHAR_CR } from '../../../../chars/CR.constant';
import { smtp$TextString$BufferDecoder } from '../../shared/smtp-textstring.buffer-decoder';

// https://datatracker.ietf.org/doc/html/rfc5321#section-4.2


export function smtp$GREETING$PacketBufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<ISMTP$GREETING$Packet> {

  // code
  let hasNextLine: boolean;
  {
    const result: IBufferDecoderResult<boolean> = smtp$GREETING_CODE$BufferDecoder(buffer, index);
    if (result.state === 'done') {
      hasNextLine = result.value;
      index = result.index;
    } else {
      return result;
    }
  }

  // TODO support hasNextLine

  // hostname
  let hostname: IReadonlyUTF8EncodedStringBuffer;
  {
    const result: IBufferDecoderResult<IReadonlyUTF8EncodedStringBuffer> = smtp$Hostname$BufferDecoder(buffer, index);
    if (result.state === 'done') {
      hostname = result.value;
      index = result.index;
    } else {
      return result;
    }
  }


  // text
  let text: IReadonlyUTF8EncodedStringBuffer;
  if (buffer[index] === CHAR_SPACE) {
    const result: IBufferDecoderResult<IReadonlyUTF8EncodedStringBuffer> = smtp$TextString$BufferDecoder(buffer, index + 1);
    if (result.state === 'done') {
      text = result.value;
      index = result.index;
    } else {
      return result;
    }
  } else {
    text = new Uint8Array();
  }

  // \r\n
  {
    if (buffer[index] === CHAR_CR) {
      index++;
    } else {
      return createBufferDecoderResultError(createExpectedByteError(CHAR_CR, buffer[index]));
    }

    if (buffer[index] === CHAR_LF) {
      index++;
    } else {
      return createBufferDecoderResultError(createExpectedByteError(CHAR_LF, buffer[index]));
    }
  }

  return createBufferDecoderResultDone<ISMTP$GREETING$Packet>(
    {
      hostname,
      text,
    },
    index,
  );
}

/*---------------------*/

function smtp$GREETING_CODE$BufferDecoder(
  buffer: Uint8Array,
  index: u32,
): IBufferDecoderResult<boolean> {

  if (buffer[index] === CHAR_2) {
    index++;
  } else {
    return createBufferDecoderResultError(createExpectedByteError(CHAR_2, buffer[index]));
  }

  if (buffer[index] === CHAR_2) {
    index++;
  } else {
    return createBufferDecoderResultError(createExpectedByteError(CHAR_2, buffer[index]));
  }

  if (buffer[index] === CHAR_0) {
    index++;
  } else {
    return createBufferDecoderResultError(createExpectedByteError(CHAR_0, buffer[index]));
  }

  if (
    (buffer[index] === CHAR_SPACE)
    || (buffer[index] === CHAR_MINUS)
  ) {
    return createBufferDecoderResultDone<boolean>(
      (buffer[index] === CHAR_MINUS),
      index,
    );
  } else {
    return createBufferDecoderResultError(createExpectedOrBytesError([CHAR_SPACE, CHAR_MINUS], buffer[index]));
  }
}
