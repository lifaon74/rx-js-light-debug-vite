import { IUTF8EncodedStringBuffer } from '@lifaon/rx-js-light';


export interface ISMTP$EHLO_OK_RSP$Packet {
  hostname: IUTF8EncodedStringBuffer;
  greet: IUTF8EncodedStringBuffer;
  lines: ISMTP$EHLO_OK_RSP$PacketLine[];
}


export interface ISMTP$EHLO_OK_RSP$PacketLine {
  keyword: IUTF8EncodedStringBuffer;
  params: IUTF8EncodedStringBuffer[];
}
