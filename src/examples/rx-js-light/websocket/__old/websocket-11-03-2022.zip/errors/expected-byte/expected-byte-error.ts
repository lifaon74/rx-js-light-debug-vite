import { u8 } from '@lifaon/number-types';

function u8ToHex(
  value: u8,
): string {
  return `0x${value.toString(16).padStart(2, '0')}`;
}

function u8ToString(
  value: u8,
): string {
  return `'${String.fromCharCode(value)}' (${u8ToHex(value)})`;
}

export function createExpectedByteError(
  expected: u8,
  found: u8,
): Error {
  return new Error(`Expected ${u8ToString(expected)}, found ${u8ToString(found)}`);
}

export function createExpectedOrBytesError(
  expected: readonly u8[],
  found: u8,
): Error {
  return new Error(`Expected ${expected.map(u8ToString).join(' or ')}, found ${u8ToString(found)}`);
}
