import { ISize } from '../../../../../../misc/types/size/size.type';

export function getElementSizeFromRect(
  rect: DOMRectReadOnly,
): ISize {
  return rect;
}
