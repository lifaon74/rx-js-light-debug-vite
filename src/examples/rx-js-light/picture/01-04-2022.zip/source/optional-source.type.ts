export type IOptionalSource = string | undefined;
